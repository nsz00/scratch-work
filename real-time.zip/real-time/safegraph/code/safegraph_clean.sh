#!/bin/bash
#SBATCH --ntasks-per-node=1
#SBATCH --nodes=1
#SBATCH --job-name=safegraph_clean
#SBATCH --mem-per-cpu=100G
#SBATCH --time=04-00:00:00

cd `pathf $SLURM_SUBMIT_DIR` 
/opt/anaconda3/bin/python dask1.py > out.txt
