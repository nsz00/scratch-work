import pandas as pd
from datetime import date, timedelta, datetime
from functools import reduce
import numpy as np
import sys
import os
from glob import glob
from ast import literal_eval

#Set file paths
git_path = 'PATH/safegraph'
data_path  = 'PATH/safegraph'

######################## A) SOCIAL DISTANCING METRICS ########################
print("A) Social Distancing Metrics")


##### 1) Import Census Data and FIPS Codes  ################

# Import state/county names and zero pad their FIPS codes
fips_df = pd.read_csv(data_path + '/safegraph_open_census_data/metadata/cbg_fips_codes.csv', usecols=['state', 'county', 'state_fips', 'county_fips'])
fips_dict = {'col_name': ['state_fips', 'county_fips', 'census_block_fips'], 'pad': [2,3,12]}
for fips in range(0,(len(fips_dict['col_name']) - 1)):
    fips_df[fips_dict['col_name'][fips]] = fips_df[fips_dict['col_name'][fips]].astype(str)
    fips_df[fips_dict['col_name'][fips]] = fips_df[fips_dict['col_name'][fips]].str.zfill(fips_dict['pad'][fips])

# Import census tract population data and extract state/county FIPS codes
census_df = pd.read_csv(data_path + '/safegraph_open_census_data/data/cbg_b01.csv', usecols=['B01003e1','census_block_group'])
census_df.rename(columns={'B01003e1':'totpop_est', 'census_block_group': fips_dict['col_name'][2]}, inplace=True)
census_df[fips_dict['col_name'][2]] = census_df[fips_dict['col_name'][2]].astype(str)
census_df[fips_dict['col_name'][2]] = census_df[fips_dict['col_name'][2]].str.zfill(fips_dict['pad'][2])
census_df['state_fips'] = census_df[fips_dict['col_name'][2]].str[:2]
census_df['county_fips'] = census_df[fips_dict['col_name'][2]].str[2:5]

# Merge state/county names with census data by FIPS code
fips_census = pd.merge(fips_df, census_df, on=fips_dict['col_name'][0:(len(fips_dict['col_name']) - 1)], how='inner')

# Calculate census tract population as a percent of state population
fips_census['percent_state'] = fips_census['totpop_est']*100/fips_census.groupby('state')['totpop_est'].transform('sum')
fips_census['origin_census_block_group'] = fips_census['census_block_fips'].astype(str).astype(int)

##### 2) Import Social Distancing Data ################
print("1. Importing Social Distancing Data")

# Start dask cluster
from dask_jobqueue import SLURMCluster
cluster = SLURMCluster(cores=1, memory="10gb",death_timeout=500,local_directory='PATH/safegraph/slurm/', walltime='05:00:00')
cluster.scale(300)
from dask.distributed import Client, progress

client = Client(cluster)
client.get_versions(check=True)
from dask import dataframe as ddf
from dask import compute as comp


# Import social distancing data
safegraph_raw = ddf.read_csv(data_path + '/social-distancing/v2/*/*/*/*.csv.gz', compression="gzip",
                             dtype={'date_range_start': 'str',
                                    'candidate_device_count': 'object',
                                    'completely_home_device_count': 'int',
                                    'delivery_behavior_devices': 'int',
                                    'device_count': 'int','distance_traveled_from_home': 'float64'},
                             usecols=lambda x: ('bucket' not in x) and ('mean' not in x))
safegraph_raw = safegraph_raw.persist()
progress(safegraph_raw)  
 
# Merge social distancing data with census population data by census block
safegraph_raw = ddf.merge(safegraph_raw, fips_census, on='origin_census_block_group', how='inner')

##### 3) Calculate Social Distancing Metrics ################
print("2. Calculating Social Distancing Metrics")

# Create date variable
safegraph_raw['date'] = ddf.to_datetime(safegraph_raw.date_range_start,utc=True).dt.date

# Calculate social distancing metrics by state and date
safegraph_raw_us = safegraph_raw
percent_sd_names = ['completely_home_device_count', 'part_time_work_behavior_devices', 'full_time_work_behavior_devices', 'delivery_behavior_devices']
sd_names = ['median_home_dwell_time', 'median_non_home_dwell_time', 'median_percentage_time_home', 'distance_traveled_from_home']
agg_percent_sd_names = ['percent_completely_home_device', 'percent_part_time_work_behavior_devices', 'percent_full_time_work_behavior_devices', 'percent_delivery_behavior_devices']
agg_sd_names = ['avg_median_home_dwell_time','avg_median_non_home_dwell_time','avg_median_percentage_time_home', 'avg_distance_traveled_from_home']
for name in range(len(percent_sd_names)):
    safegraph_raw[agg_percent_sd_names[name]] = (safegraph_raw[percent_sd_names[name]]/safegraph_raw.device_count)*safegraph_raw.totpop_est
    temp_df = safegraph_raw.groupby(['state_fips', 'state', 'date']).agg({agg_percent_sd_names[name]: ['sum'], 'totpop_est': ['sum']})
    temp = temp_df[temp_df.columns[0]]/temp_df[temp_df.columns[1]]
    temp_c = temp.compute()
    temp_c = pd.DataFrame(temp_c, columns = [agg_percent_sd_names[name]])
    if name == 0:
        sd_0_c = temp_c
    elif name == 1:
        sd_1_c = temp_c
    elif name == 2:
        sd_2_c = temp_c
    elif name == 3:
        sd_3_c = temp_c
for name in range(len(sd_names)):
    safegraph_raw[agg_sd_names[name]] = (safegraph_raw[sd_names[name]])*safegraph_raw.totpop_est
    temp_df = safegraph_raw.groupby(['state_fips', 'state', 'date']).agg({agg_sd_names[name]: ['sum'], 'totpop_est': ['sum']})
    temp = temp_df[temp_df.columns[0]]/temp_df[temp_df.columns[1]]
    temp_c = temp.compute()
    temp_c = pd.DataFrame(temp_c, columns = [agg_sd_names[name]])
    if name == 0:
        sd_4_c = temp_c
    elif name == 1:
        sd_5_c = temp_c
    elif name == 2:
        sd_6_c = temp_c
    elif name == 3:
        sd_7_c = temp_c

sd_data_frames = [sd_0_c, sd_1_c, sd_2_c, sd_3_c, sd_4_c, sd_5_c, sd_6_c, sd_7_c]
sd_pop_df_new = reduce(lambda  left,right: pd.merge(left,right,left_index=True, right_index=True), sd_data_frames)

##### 4) State-Level and National Aggregation  ################

# Aggregate statistics for entire US
for name in range(len(percent_sd_names)):
    safegraph_raw_us[agg_percent_sd_names[name]] = (safegraph_raw_us[percent_sd_names[name]]/safegraph_raw_us.device_count)*safegraph_raw_us.totpop_est
    temp_df = safegraph_raw_us.groupby(['date']).agg({agg_percent_sd_names[name]: ['sum'], 'totpop_est': ['sum']})
    temp = temp_df[temp_df.columns[0]]/temp_df[temp_df.columns[1]]
    temp_c = temp.compute()
    temp_c = pd.DataFrame(temp_c, columns = [agg_percent_sd_names[name]])
    if name == 0:
        sd_0_c = temp_c
    elif name == 1:
        sd_1_c = temp_c
    elif name == 2:
        sd_2_c = temp_c
    elif name == 3:
        sd_3_c = temp_c
for name in range(len(sd_names)):
    safegraph_raw_us[agg_sd_names[name]] = (safegraph_raw_us[sd_names[name]])*safegraph_raw_us.totpop_est
    temp_df = safegraph_raw_us.groupby(['date']).agg({agg_sd_names[name]: ['sum'], 'totpop_est': ['sum']})
    temp = temp_df[temp_df.columns[0]]/temp_df[temp_df.columns[1]]
    temp_c = temp.compute()
    temp_c = pd.DataFrame(temp_c, columns = [agg_sd_names[name]])
    if name == 0:
        sd_4_c = temp_c
    elif name == 1:
        sd_5_c = temp_c
    elif name == 2:
        sd_6_c = temp_c
    elif name == 3:
        sd_7_c = temp_c

sd_data_frames = [sd_0_c, sd_1_c, sd_2_c, sd_3_c, sd_4_c, sd_5_c, sd_6_c, sd_7_c]
sd_pop_df_new_us = reduce(lambda  left,right: pd.merge(left,right,left_index=True, right_index=True), sd_data_frames)

# Add aggregate US to panel
sd_pop_df_new_us['state'] = 'US'
sd_pop_df_new_us['state_fips'] = '00'
sd_pop_df_new_us = sd_pop_df_new_us.set_index(['state_fips', 'state'], append = True)
sd_pop_df_new_us = sd_pop_df_new_us.reset_index()
sd_pop_df_new = sd_pop_df_new.reset_index()
sd_pop_df_new = sd_pop_df_new.append(sd_pop_df_new_us).reset_index()


##### 5) Smoothing - 7 day rolling average  ################

# To account for weekly seasonality, construct 7-day rolling averages of each state-level social distancing variable
#sd_pop_df_new = sd_pop_df_new.reset_index()
sd_pop_df_new = sd_pop_df_new.sort_values(['state_fips', 'state', 'date']).reset_index(drop=True)
sd_pop_df_new['group_num_sd'] = sd_pop_df_new.groupby(['state_fips', 'state']).ngroup()
sd_pop_df_roll = sd_pop_df_new
for smooth_var in range(0,len(agg_sd_names)):
    smooth_var_new = agg_sd_names[smooth_var] + '_smooth'
    sd_pop_df_roll[smooth_var_new] = sd_pop_df_roll.groupby(['group_num_sd'])[agg_sd_names[smooth_var]].transform(lambda x: x.rolling(window=7, center=False).mean())
for smooth_var in range(0,len(agg_percent_sd_names)):
    smooth_var_new = agg_percent_sd_names[smooth_var] + '_smooth'
    sd_pop_df_roll[smooth_var_new] = sd_pop_df_roll.groupby(['group_num_sd'])[agg_percent_sd_names[smooth_var]].transform(lambda x: x.rolling(window=7, center=False).mean())

# Drop unnecessary variables
sd_pop_df_roll = sd_pop_df_roll.drop(columns=['group_num_sd'])

##### 6) Compute Year-Over-Year Daily Log Change ################

# Take the daily year-over-year log difference
sd_pop_df_roll['date_offset'] = (sd_pop_df_roll.date - pd.DateOffset(years=1)).apply(lambda x: x.date())

def log_change(x, sd_var):
    x_off_date = x['date_offset']
    x_state = x['state']
    x_df_offset = sd_pop_df_roll[(sd_pop_df_roll['state'] == x_state) & (sd_pop_df_roll['date'] == x_off_date)].reset_index(drop=True)
    if x_df_offset.empty == True:
        log_output = np.nan
    else:
        x_val_offset = x_df_offset.loc[0, sd_var]
        log_output = np.log(x[sd_var]/x_val_offset)
    return log_output

for smooth_var in range(0,len(agg_sd_names)):
    smooth_var_new = agg_sd_names[smooth_var] + '_smooth'
    smooth_var_new_log = smooth_var_new + '_log'
    sd_pop_df_roll[smooth_var_new_log] = sd_pop_df_roll.apply(lambda x: log_change(x, smooth_var_new), axis = 1)

for smooth_var in range(0,len(agg_percent_sd_names)):
    smooth_var_new = agg_percent_sd_names[smooth_var] + '_smooth'
    smooth_var_new_log = smooth_var_new + '_log'
    sd_pop_df_roll[smooth_var_new_log] = sd_pop_df_roll.apply(lambda x: log_change(x, smooth_var_new), axis = 1)

# Drop unnecessary variables
sd_pop_df_roll = sd_pop_df_roll.drop(columns=['date_offset', 'index'])

##### 7) Export SafeGraph Social Distancing Data  ################
# Export social distancing data
sd_pop_df_roll.to_csv('./final/sd_safegraph.csv', index = False)



######################## B) POINT OF INTEREST (POI) VISITS  ########################
print("B) Point of Interest Visits")

##### 1) Import SafeGraph core panel of POI's ################
#Note: Safegraph updates its core places monthly and recommends using the most recent core panel. Safegraph explicitly states not to use a different core panel for each month. The panel does not include closed firms. 
core_df = ddf.read_csv(data_path + '/core/2020/07/core_poi-part*.csv.gz', compression="gzip",
                       usecols=['safegraph_place_id', 'top_category','sub_category','naics_code', 'category_tags', 'region'])
core_df = core_df.persist()
progress(core_df)
core_df = core_df.compute()
client.restart()

##### 2) Import and Clean SafeGraph POI Visits ################
# Starting in July 2020, Safegraph began delivering their POI data through a different file structure. For this reason, we must import pre-July and post-July POI data separately. 

# Import and Clean POI Visit Data (Post 06/24/2020)
print("1. Import and clean post-July POI data") 
main = ddf.read_csv(data_path + '/weekly_patterns-delivery/weekly/patterns/2020/*/*/*/*.csv.gz', compression="gzip", 
                    converters={'visits_by_day': lambda x: list(map(int,literal_eval(x)))},
                    usecols=['safegraph_place_id', 'date_range_start','region','visits_by_day'])
main = main.persist()
progress(main)
# Merge in POI core panel
safegraph_visit = ddf.merge(main, core_df, on=['safegraph_place_id', 'region'], how='inner')
safegraph_visit['date'] = ddf.to_datetime(safegraph_visit.date_range_start,utc=True).dt.date
# Separate the post-July visits array into distinct series for each day of the week
safegraph_visit['visit_0'] = safegraph_visit.visits_by_day.apply(lambda x: x[0], meta=('visit_0', float))
safegraph_visit['visit_1'] = safegraph_visit.visits_by_day.apply(lambda x: x[1], meta=('visit_1', float))
safegraph_visit['visit_2'] = safegraph_visit.visits_by_day.apply(lambda x: x[2], meta=('visit_2', float))
safegraph_visit['visit_3'] = safegraph_visit.visits_by_day.apply(lambda x: x[3], meta=('visit_3', float))
safegraph_visit['visit_4'] = safegraph_visit.visits_by_day.apply(lambda x: x[4], meta=('visit_4', float))
safegraph_visit['visit_5'] = safegraph_visit.visits_by_day.apply(lambda x: x[5], meta=('visit_5', float))
safegraph_visit['visit_6'] = safegraph_visit.visits_by_day.apply(lambda x: x[6], meta=('visit_6', float))
# Sum visits by state-industry-date tuple
temp_visit_df = safegraph_visit.groupby(['region', 'top_category', 'date']).agg({'visit_0': ['sum'],'visit_1': ['sum'],'visit_2': ['sum'],'visit_3': ['sum'],'visit_4': ['sum'],'visit_5': ['sum'], 'visit_6': ['sum']})
post_visits = temp_visit_df.compute()
client.restart()


# Import and Clean POI Visit Data (Pre 06/24/2020)
print("2. Import and clean pre-July POI data") 

def load(filename):
    df = pd.read_csv(filename,
                     converters={'visits_by_day': lambda x: list(map(int,literal_eval(x)))},
                     usecols=['safegraph_place_id', 'date_range_start','region','visits_by_day'])

    return df

filenames = glob(data_path + '/weekly_patterns/v2/main-file/*.csv.gz')
from dask.delayed import delayed
dfs = [delayed(load)(fn) for fn in filenames]
df = ddf.from_delayed(dfs)
main = df.persist()
progress(main)
# Merge in POI core panel
safegraph_visit = ddf.merge(main, core_df, on=['safegraph_place_id', 'region'], how='inner')
safegraph_visit['date'] = ddf.to_datetime(safegraph_visit.date_range_start,utc=True).dt.date
# Separate the post-July visits array into distinct series for each day of the week
safegraph_visit['visit_0'] = safegraph_visit.visits_by_day.apply(lambda x: x[0], meta=('visit_0', float))
safegraph_visit['visit_1'] = safegraph_visit.visits_by_day.apply(lambda x: x[1], meta=('visit_1', float))
safegraph_visit['visit_2'] = safegraph_visit.visits_by_day.apply(lambda x: x[2], meta=('visit_2', float))
safegraph_visit['visit_3'] = safegraph_visit.visits_by_day.apply(lambda x: x[3], meta=('visit_3', float))
safegraph_visit['visit_4'] = safegraph_visit.visits_by_day.apply(lambda x: x[4], meta=('visit_4', float))
safegraph_visit['visit_5'] = safegraph_visit.visits_by_day.apply(lambda x: x[5], meta=('visit_5', float))
safegraph_visit['visit_6'] = safegraph_visit.visits_by_day.apply(lambda x: x[6], meta=('visit_6', float))
# Sum visits by state-industry-date tuple
temp_visit_df = safegraph_visit.groupby(['region', 'top_category', 'date']).agg({'visit_0': ['sum'],'visit_1': ['sum'],'visit_2': ['sum'],'visit_3': ['sum'],'visit_4': ['sum'],'visit_5': ['sum'], 'visit_6': ['sum']})
pre_visits = temp_visit_df.compute()

# Append all POI Visit Data
print("3. Append all POI data") 

poi_df = post_visits
poi_df = poi_df.append(pre_visits)
poi_df.columns = poi_df.columns.droplevel(1)
poi_df = poi_df.reset_index()

##### 3) Convert POI Visit Data From Weekly to Daily ###############
print("4. Start converting POI data to daily frequency")

# For each weekly observation, list of all daily dates during that week
def day_to_list(start):
    return [start + timedelta(days=i) for i in range(7)]
poi_df['date_list'] = poi_df.apply(lambda x: day_to_list(x.date), axis=1)

# For each weekly observation, set the variable date_n and visit_n to the nth day of the week's date and visits, respectively (n ranges from 0 to 6, corresponding to the 7 days of the week)
for n in range(0, 7):
    poi_df['date_{}'.format(n)] = poi_df.date_list.apply(lambda x: x[n])

# Expand the dataset so that each weekly observation appears 7 times
poi_df_full = pd.concat([poi_df]*7, ignore_index=False)

# Set variable 'index_count' equal to a distinct value for each week
poi_df_full['index_count'] = poi_df_full.groupby(poi_df_full.index).cumcount()+1

# Reshape the dataset so that each row represents a day, not week
def reshape(x_index, xnum0, xnum1, xnum2, xnum3, xnum4, xnum5, xnum6):
    x_val = [xnum0, xnum1, xnum2, xnum3, xnum4, xnum5, xnum6]
    adjust_index = x_index - 1
    return  x_val[adjust_index]
poi_df_full['poi_date'] = poi_df_full.apply(lambda x: reshape(x.index_count, x.date_0, x.date_1, x.date_2, x.date_3, x.date_4, x.date_5, x.date_6), axis = 1)
poi_df_full['poi_visit'] = poi_df_full.apply(lambda x: reshape(x.index_count, x.visit_0, x.visit_1, x.visit_2, x.visit_3, x.visit_4, x.visit_5, x.visit_6), axis = 1)
poi_df_full['poi_visit'] = pd.to_numeric(poi_df_full.poi_visit)
poi_df_full = poi_df_full.reset_index(drop = True) 

##### 4) State-Level and National Aggregation  ################

# Aggregate total visits by industry, state, and day
poi_groups = poi_df_full.groupby(['region', 'top_category','poi_date'])['poi_visit'].sum().reset_index() 

# Calculate daily visits for the entire US and add US to panel
poi_us = poi_groups.groupby(['top_category','poi_date'])['poi_visit'].sum().reset_index() 
poi_us['region'] = 'US'
poi_groups_us = poi_groups.append(poi_us).reset_index()


##### 5) Normalization  ################

# Import Normalization Files
files = [glob(data_path + '/weekly_patterns/v2/normalization-stats/*-normalization-stats.csv'), glob(data_path + '/weekly_patterns-delivery/weekly/normalization_stats/*/*/*/*/normalization_stats.csv')]
normalization = pd.concat([pd.read_csv(f) for n in files for f in n])

# In preparation for merging, add date variable to normalization dataset
normalization['poi_date'] = normalization.apply(lambda x:datetime.strptime("{0} {1} {2} 00:00:00".format(x['year'],x['month'], x['day']), "%Y %m %d %H:%M:%S").date(),axis=1)

# Merge normalization dataset with mobility dataset
poi_df_norm = poi_groups_us.merge(normalization, on='poi_date', how='inner')

# Normalize visits by panel size (number of devices seen)
poi_df_norm['norm_visits'] = poi_df_norm.poi_visit/poi_df_norm.total_devices_seen

##### 6) Smoothing - 7 day rolling average  ################

# To account for the strong weekly seasonality, take a seven day moving average
poi_df_norm_temp = poi_df_norm.sort_values(['region', 'top_category', 'poi_date']).reset_index(drop=True)
poi_df_norm_temp['group_num'] = poi_df_norm_temp.groupby(['region', 'top_category']).ngroup()
poi_df_norm_temp['smooth_norm_visit'] = poi_df_norm_temp.groupby(['group_num'])['norm_visits'].transform(lambda x: x.rolling(window=7, center=False).mean())


##### 7) Standardization  ################

# Calculate the median value between the 2nd and 3rd Wednesday of January. The dates used for 2019 and 2020 are [2019-01-09, 2019-01-16) and [2020-01-08, 2020-01-15), respectively. 
# In their own visualizations, Safegraph makes the strong assumption that foot-traffic in early January == 1 for both 2019 and 2020. We follow this convention but allow for the specification of an offset factor (adjust_factor) in the case that one has strong priors regarding the absolute difference of foot-traffic between 2019 and 2020. 
year_clean = {2019: {'median_start_date': 'date(2019,1,9)', 'median_end_date': 'date(2019,1,16)', 'adjust_factor': 0}, 2020: {'median_start_date': 'date(2020,1,8)', 'median_end_date': 'date(2020,1,15)', 'adjust_factor': 0}}

# For each state-industry pair, subset our normalized visit dataset to only observations occurring between our specified standardization dates


for select in range(0,len(year_clean)):
    year_val = list(year_clean.keys())[select] 
    if select == 0:
        date_string = 'poi_df_norm_temp.poi_date.between({}, {})'.format(year_clean[year_val]['median_start_date'], year_clean[year_val]['median_end_date'])
    else:
        date_string = date_string + ' | ' + 'poi_df_norm_temp.poi_date.between({}, {})'.format(year_clean[year_val]['median_start_date'], year_clean[year_val]['median_end_date'])
exec_date_string = 'selected_dates = poi_df_norm_temp[{}].reset_index(drop=True)'.format(date_string)
exec(exec_date_string) 

# Calculate median normalized visits for each state-industry pair or observations occurring during the specified dates
median_df = selected_dates.groupby(['group_num', 'year'])['norm_visits'].median().reset_index()
median_df.rename(columns={'norm_visits':'median_val'}, inplace=True)

# To standardize our foot-traffic data, divide normalized visits by its corresponding median
poi_df_median = poi_df_norm_temp.merge(median_df, on=['group_num', 'year'], how='inner')
poi_df_median['smooth_norm_stand_visit'] = poi_df_median.smooth_norm_visit/poi_df_median.median_val

# Add offset factor to specify absolute difference between Janaury 2019 and 2020
def year_adjust(year, val):
    adjust = year_clean[year]['adjust_factor']
    return val + adjust
poi_df_median['smooth_norm_stand_adjust_visit'] = poi_df_median.apply(lambda x: year_adjust(x.year, x.smooth_norm_stand_visit), axis=1)

##### 8) Compute Year-Over-Year Daily Log Change ################

# Take daily year-over-year log difference
poi_df_median['date_offset'] = (poi_df_median.poi_date - pd.DateOffset(years=1)).apply(lambda x: x.date())
poi_df_median_temp = poi_df_median[['region', 'top_category', 'poi_date', 'smooth_norm_stand_adjust_visit']]
poi_df_median_temp.rename(columns = {'poi_date':'date_offset', 'smooth_norm_stand_adjust_visit':'poi_old_visit'}, inplace = True) 
poi_df_median = poi_df_median.merge(poi_df_median_temp, how = 'left', on = ['region', 'top_category', 'date_offset'])
poi_df_median['smooth_norm_stand_adjust_visit_log'] = np.log(poi_df_median.smooth_norm_stand_adjust_visit) - np.log(poi_df_median.poi_old_visit)

# Drop unnecessary variables
poi_df_median = poi_df_median.drop(columns=['date_offset', 'median_val', 'group_num'])

##### 9) Export SafeGraph POI Visits Data  ################
# Export POI visits data
poi_df_median.to_csv('./final/visits_safegraph.csv')

# Print if execution successful
print("safegraph_clean.py complete!")
