import pandas as pd
import numpy as np
from ast import literal_eval
import sys
import os
from dask_jobqueue import SLURMCluster
from dask.distributed import Client, progress
from dask import dataframe as ddf
from datetime import date, timedelta, datetime

#Set file paths
data_path  = 'PATH/safegraph'

#Set dask parameters
cluster = SLURMCluster(cores=1, memory="10gb",death_timeout=200,local_directory='PATH/safegraph/slurm/')
cluster.scale(300)
client = Client(cluster)
client.get_versions(check=True)


#Starting in July, Safegraph switched its visits data to a different folder structure where each week include four separate csv files. Pre-July, there is only 1 csv file per week.  Despite the fact that it uses four csv files instead of one, the data format appears the same within each of the four csv files to the pre-July csv files. Dask works for these files from July onwards.
print("Loading post-July data via dask")
main = ddf.read_csv(data_path + '/weekly_patterns-delivery/weekly/patterns/2020/*/*/*/*.csv.gz', compression="gzip", 
                    converters={'visits_by_day': lambda x: list(map(int,literal_eval(x)))},
                    usecols=['safegraph_place_id', 'date_range_start','region','visits_by_day'])
main = main.persist()
progress(main)
temp = main.compute()
print(temp.head())
 

#For the pre-July data, pandas works but takes a bit! 
print("Loading pre-July data via pandas")
main_pandas = pd.read_csv(data_path + '/weekly_patterns/v2/main-file/2019-01-07-weekly-patterns.csv.gz',
                          converters={'visits_by_day': lambda x: list(map(int,literal_eval(x)))},
                          usecols=['safegraph_place_id', 'date_range_start','region','visits_by_day'])
print(main_pandas.head())


#However, dask does not work for the pre-July data (not even just 1 week). Confusion!?!
print("Loading pre-July data via dask")
main = ddf.read_csv(data_path + '/weekly_patterns/v2/main-file/2019-01-07-weekly-patterns.csv.gz', compression="gzip", 
                    converters={'visits_by_day': lambda x: list(map(int,literal_eval(x)))},
                    usecols=['safegraph_place_id', 'date_range_start','region','visits_by_day'], blocksize = 32e6)
main = main.persist()
progress(main)
temp = main.compute()
print(temp.head())


#It looks like dask read_csv fails if a gzip file is too large because gzip files can't be partitioned (https://stackoverflow.com/questions/43347936/open-large-files-from-s3). There are 2 solutions: 1) unzip the safegraph files or 2) import the data via pd.read_csv and a loop. The following code demonstrates solution (2) for just January 2020 data. It takes a while but at least it produces the desired output. 
print("Looping pre-July data via pandas")

core_df = ddf.read_csv(data_path + '/core/2020/04/core_poi-part*.csv',
                       usecols=['safegraph_place_id', 'top_category','sub_category','naics_code', 'category_tags', 'region'])
core_df = core_df.persist()
progress(core_df)
core_df = core_df.compute()

main = pd.read_csv(data_path + '/weekly_patterns/v2/main-file/2019-01-07-weekly-patterns.csv.gz',
                          converters={'visits_by_day': lambda x: list(map(int,literal_eval(x)))},
                          usecols=['safegraph_place_id', 'date_range_start','region','visits_by_day'])
files = ['/weekly_patterns/v2/main-file/2019-01-14-weekly-patterns.csv.gz', '/weekly_patterns/v2/main-file/2019-01-21-weekly-patterns.csv.gz', '/weekly_patterns/v2/main-file/2019-01-28-weekly-patterns.csv.gz', '/weekly_patterns/v2/main-file/2019-02-04-weekly-patterns.csv.gz']
for f in files:
    print(f)
    f_temp = pd.read_csv(data_path + f,
                         converters={'visits_by_day': lambda x: list(map(int,literal_eval(x)))},
                         usecols=['safegraph_place_id', 'date_range_start','region','visits_by_day'])  
    main = main.append(f_temp)

safegraph_raw = ddf.merge(main, core_df, on=['safegraph_place_id', 'region'], how='inner')
safegraph_raw['date'] = pd.to_datetime(safegraph_raw.date_range_start, format="%Y-%m-%d").apply(lambda x: x.date())
safegraph_raw['visit_0'] = safegraph_raw.visits_by_day.apply(lambda x: x[0])
safegraph_raw['visit_1'] = safegraph_raw.visits_by_day.apply(lambda x: x[1])
safegraph_raw['visit_2'] = safegraph_raw.visits_by_day.apply(lambda x: x[2])
safegraph_raw['visit_3'] = safegraph_raw.visits_by_day.apply(lambda x: x[3])
safegraph_raw['visit_4'] = safegraph_raw.visits_by_day.apply(lambda x: x[4])
safegraph_raw['visit_5'] = safegraph_raw.visits_by_day.apply(lambda x: x[5])
safegraph_raw['visit_6'] = safegraph_raw.visits_by_day.apply(lambda x: x[6])
temp_df = safegraph_raw.groupby(['region', 'top_category', 'date']).agg({'visit_0': ['sum'],'visit_1': ['sum'],'visit_2': ['sum'],'visit_3': ['sum'],'visit_4': ['sum'],'visit_5': ['sum'], 'visit_6': ['sum']})
print(temp_df.head())
