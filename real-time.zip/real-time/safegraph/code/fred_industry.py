from datetime import date, timedelta, datetime
from functools import reduce
import numpy as np
import sys
import os
from glob import glob
from ast import literal_eval
from pandas_datareader import get_data_fred
import pandas as pd 

naics2word = {11: {'industry': 'Agriculture, Forestry, Fishing and Hunting', 'fred_pgdp': 'VAPGDPAFH'}, 
              21: {'industry': 'Mining, Quarrying, and Oil and Gas Extraction', 'fred_pgdp': 'VAPGDPM'}, 
              22: {'industry': 'Utilities', 'fred_pgdp': 'VAPGDPU'}, 
              23: {'industry': 'Construction', 'fred_pgdp': 'VAPGDPC'}, 
              31: {'industry': 'Manufacturing', 'fred_pgdp': 'VAPGDPMA'}, 
              32: {'industry': 'Manufacturing', 'fred_pgdp': 'VAPGDPMA'}, 
              33: {'industry': 'Manufacturing', 'fred_pgdp': 'VAPGDPMA'}, 
              42: {'industry': 'Wholesale Trade', 'fred_pgdp': 'VAPGDPW'}, 
              44: {'industry': 'Retail Trade', 'fred_pgdp': 'VAPGDPR'}, 
              45: {'industry': 'Retail Trade', 'fred_pgdp': 'VAPGDPR'}, 
              48: {'industry': 'Transportation and Warehousing', 'fred_pgdp': 'VAPGDPT'}, 
              49: {'industry': 'Transportation and Warehousing', 'fred_pgdp': 'VAPGDPT'}, 
              51: {'industry': 'Information', 'fred_pgdp': 'VAPGDPI'}, 
              52: {'industry': 'Finance and Insurance', 'fred_pgdp': 'VAPGDPFI'}, 
              53: {'industry': 'Real Estate and Rental and Leasing', 'fred_pgdp': 'VAPGDPRL'}, 
              54: {'industry': 'Professional, Scientific, and Technical Services', 'fred_pgdp': 'VAPGDPPST'}, 
              55: {'industry': 'Management of Companies and Enterprises', 'fred_pgdp': 'VAPGDPMCE'}, 
              56: {'industry': 'Administrative and Support and Waste Management and Remediation Services', 
'fred_pgdp': 'VAPGDPAWMS'}, 
              61: {'industry': 'Educational Services', 'fred_pgdp': 'VAPGDPES'}, 
              62: {'industry': 'Health Care and Social Assistance', 'fred_pgdp': 'VAPGDPHCSA'}, 
              71: {'industry': 'Arts, Entertainment, and Recreation', 'fred_pgdp': 'VAPGDPAER'}, 
              72: {'industry': 'Accommodation and Food Services', 'fred_pgdp': 'VAPGDPAF'}, 
              81: {'industry': 'Other Services (except Public Administration)', 'fred_pgdp': 'VAPGDPOSEG'}, 
              92: {'industry': 'Public Administration', 'fred_pgdp': 'VAPGDPG'}}
fred_industry_list = [naics2word[industry]['fred_pgdp'] for industry in [11,21,22,23,31,42,44,48,51,52,53,54,55,56,61,62,71,72,81,92]]
industry_gdp = get_data_fred(fred_industry_list, datetime.strptime('2019-01-01','%Y-%m-%d'), datetime.strptime('2019-12-31','%Y-%m-%d'))
industry_mean = industry_gdp.mean()
industry_mean = industry_mean.reset_index()
industry_mean = industry_mean.rename(columns={'index': 'fred_pgdp', 0:'pgdp'})
industry_mean['industry'] = np.array([naics2word[naics]['industry'] for naics in [11,21,22,23,31,42,44,48,51,52,53,54,55,56,61,62,71,72,81,92]])

