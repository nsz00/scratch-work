safegraph = pd.read_csv('../safegraph/final/visits_safegraph_agg.csv')
fig, ax = plt.subplots()
safegraph = safegraph[(safegraph['year'] == 2020)] 
safegraph.reset_index(drop=True, inplace = True)
safegraph['date'] = safegraph.month.apply(lambda x: '{0:0>2}'.format(x)).map(str) + '-' + safegraph.day.apply(lambda x: '{0:0>2}'.format(x)).map(str) + '-' + safegraph.year.map(str)
safegraph['date'] = [datetime.datetime.strptime(d,"%m-%d-%Y").date() for d in safegraph.date]
states = ['CA','TX', 'GA','DC']
for area in states:
    temp_data = safegraph[(safegraph['region'] == area)] 
    temp_data.reset_index(drop=True, inplace =True)
    #temp_data['temp'] = (temp_data.visitrestaurants7 - temp_data.visitrestaurants7[31])/temp_data.visitrestaurants7[31]
    temp_data['temp'] = temp_data.poi_visit 
    ax.plot('date', 'temp', data=temp_data.iloc[31:,:])
ax.set(ylabel='Foot-Traffic Relative to 2019', title = 'Visits to Restaurants')
f = lambda x: datetime.datetime.strptime(d,"%m-%d-%Y").date()
months = mdates.MonthLocator()
ax.xaxis.set_major_locator(months)
ax.xaxis.set_minor_locator(mdates.MonthLocator(bymonthday=15))
ax.xaxis.set_major_formatter(ticker.NullFormatter())
ax.xaxis.set_minor_formatter(mdates.DateFormatter('%b'))
for tick in ax.xaxis.get_minor_ticks():
    tick.tick1line.set_markersize(0)
    tick.tick2line.set_markersize(0)
    tick.label1.set_horizontalalignment('center')
for tick in ax.xaxis.get_major_ticks():
    tick.tick1line.set_markersize(0)
plt.legend(states, loc="bottom left", frameon=False)
plt.ylim([-2.2, .8])
fig.savefig("./figures/test_fig.pdf")
