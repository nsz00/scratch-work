import pandas as pd
import sys
import os

file = sys.argv[1]
file_output = sys.argv[2]
df = pd.read_csv (file)
output_string = file_output + '/PATH/temp.csv'
df.to_csv(output_string, index=False)
