import pandas as pd
from datetime import date, timedelta, datetime
import numpy as np
import sys
import os

#Set file paths
git_path = 'PATH/safegraph'
data_path  = 'PATH/safegraph'

################ SOCIAL DISTANCING METRICS ################

##### 1) Import Census Data and FIPS Codes  ################

# Import state/county names and zero pad their FIPS codes
fips_df = pd.read_csv(data_path + '/safegraph_open_census_data/metadata/cbg_fips_codes.csv', usecols=['state', 'county', 'state_fips', 'county_fips'])
fips_dict = {'col_name': ['state_fips', 'county_fips', 'census_block_fips'], 'pad': [2,3,12]}
for fips in range(0,(len(fips_dict['col_name']) - 1)):
    fips_df[fips_dict['col_name'][fips]] = fips_df[fips_dict['col_name'][fips]].astype(str)
    fips_df[fips_dict['col_name'][fips]] = fips_df[fips_dict['col_name'][fips]].str.zfill(fips_dict['pad'][fips])

# Import census tract population data and extract state/county FIPS codes
census_df = pd.read_csv(data_path + '/safegraph_open_census_data/data/cbg_b01.csv', usecols=['B01003e1','census_block_group'])
census_df.rename(columns={'B01003e1':'totpop_est', 'census_block_group': fips_dict['col_name'][2]}, inplace=True)
census_df[fips_dict['col_name'][2]] = census_df[fips_dict['col_name'][2]].astype(str)
census_df[fips_dict['col_name'][2]] = census_df[fips_dict['col_name'][2]].str.zfill(fips_dict['pad'][2])
census_df['state_fips'] = census_df[fips_dict['col_name'][2]].str[:2]
census_df['county_fips'] = census_df[fips_dict['col_name'][2]].str[2:5]

# Merge state/county names with census data by FIPS code
fips_census = pd.merge(fips_df, census_df, on=fips_dict['col_name'][0:(len(fips_dict['col_name']) - 1)], how='inner')

# Calculate census tract population as a percent of state population
fips_census['percent_state'] = fips_census['totpop_est']*100/fips_census.groupby('state')['totpop_est'].transform('sum')
fips_census['origin_census_block_group'] = fips_census['census_block_fips'].astype(str).astype(int)

from dask_jobqueue import SLURMCluster
cluster = SLURMCluster(cores=1, memory="10gb",death_timeout=200,local_directory='PATH/dask/')
cluster.scale(100)
from dask.distributed import Client, progress

client = Client(cluster)
client.get_versions(check=True)
from dask import dataframe as ddf

file_path = "PATH/*/*/*.csv.gz"
safegraph_raw = ddf.read_csv(file_path, compression="gzip",
                             dtype={'date_range_start': 'str',
                                    'candidate_device_count': 'object',
                                    'completely_home_device_count': 'int',
                                    'delivery_behavior_devices': 'object',
                                    'device_count': 'int','distance_traveled_from_home': 'float64'},
                             usecols=lambda x: ('bucket' not in x) and ('mean' not in x))
safegraph_raw = safegraph_raw.persist()
progress(safegraph_raw)   
safegraph_raw = ddf.merge(safegraph_raw, fips_census, on='origin_census_block_group', how='inner')
safegraph_raw['date'] = ddf.to_datetime(safegraph_raw.date_range_start,utc=True)


f1 = lambda x: (x.completely_home_device_count / x.device_count * x.percent_state).sum() / x.percent_state.sum()
f2 = lambda x:  (x.median_home_dwell_time * x.totpop_est).sum() / x.totpop_est.sum()

x = safegraph_raw.groupby(['state_fips','state','date']).apply(f1,meta=('device_share',float)).compute()
print(x.head())
