from datetime import date, timedelta, datetime
from functools import reduce
import numpy as np
import sys
import os
from glob import glob
from ast import literal_eval
from pandas_datareader import get_data_fred
import pandas as pd 

#Set file paths
git_path = 'PATH/safegraph'
data_path  = 'PATH/safegraph'

######################## POINT OF INTEREST (POI) VISITS  ########################
print("A) Point of Interest Visits")

# Start dask cluster
from dask_jobqueue import SLURMCluster
cluster = SLURMCluster(cores=1, memory="10gb",death_timeout=500,local_directory='/PATH/safegraph/slurm/', walltime='05:00:00')
cluster.scale(300)
from dask.distributed import Client, progress

client = Client(cluster)
client.get_versions(check=True)
from dask import dataframe as ddf
from dask import compute as comp

##### 1) Import SafeGraph core panel of POI's ################
#Note: Safegraph updates its core places monthly and recommends using the most recent core panel. Safegraph explicitly states not to use a different core panel for each month. The panel does not include closed firms. 
core_df = ddf.read_csv(data_path + '/core/2020/08/core_poi-part*.csv.gz', compression="gzip",
                       usecols=['safegraph_place_id', 'top_category','sub_category','naics_code', 'category_tags', 'region'])
core_df = core_df.persist()
progress(core_df)
core_df = core_df.compute()
client.restart()

##### 2) Import and Clean SafeGraph POI Visits ################
# Starting in July 2020, Safegraph began delivering their POI data through a different file structure. For this reason, we must import pre-July and post-July POI data separately. 

# Import and Clean POI Visit Data (Post 06/24/2020)
print("1. Import and clean post-July POI data") 

main = ddf.read_csv(data_path + '/weekly_patterns-delivery/weekly/patterns/2020/*/*/*/*.csv.gz', compression="gzip", 
                    converters={'visits_by_day': lambda x: list(map(int,literal_eval(x)))},
                    usecols=['safegraph_place_id', 'date_range_start','region','visits_by_day'], include_path_column=True)

main = main.persist()
progress(main)

# For an unknown reason the Board's repository contains duplicate patterns data for mid/late July. Including this dataset will result in double counts of all visits during this period. As such, drop any observations from the 2020-07-24 release.
main = main[main.path != (data_path + '/weekly_patterns-delivery/weekly/patterns/2020/07/24/03/patterns-part1.csv.gz')]
main = main[main.path != (data_path + '/weekly_patterns-delivery/weekly/patterns/2020/07/24/03/patterns-part2.csv.gz')]
main = main[main.path != (data_path + '/weekly_patterns-delivery/weekly/patterns/2020/07/24/03/patterns-part3.csv.gz')]
main = main[main.path != (data_path + '/weekly_patterns-delivery/weekly/patterns/2020/07/24/03/patterns-part4.csv.gz')]

# Merge in POI core panel
safegraph_visit = ddf.merge(main, core_df, on=['safegraph_place_id', 'region'], how='inner')
safegraph_visit['date'] = ddf.to_datetime(safegraph_visit.date_range_start,utc=True).dt.date

# Separate the post-July visits array into distinct series for each day of the week
safegraph_visit['visit_0'] = safegraph_visit.visits_by_day.apply(lambda x: x[0], meta=('visit_0', float))
safegraph_visit['visit_1'] = safegraph_visit.visits_by_day.apply(lambda x: x[1], meta=('visit_1', float))
safegraph_visit['visit_2'] = safegraph_visit.visits_by_day.apply(lambda x: x[2], meta=('visit_2', float))
safegraph_visit['visit_3'] = safegraph_visit.visits_by_day.apply(lambda x: x[3], meta=('visit_3', float))
safegraph_visit['visit_4'] = safegraph_visit.visits_by_day.apply(lambda x: x[4], meta=('visit_4', float))
safegraph_visit['visit_5'] = safegraph_visit.visits_by_day.apply(lambda x: x[5], meta=('visit_5', float))
safegraph_visit['visit_6'] = safegraph_visit.visits_by_day.apply(lambda x: x[6], meta=('visit_6', float))

# Sum visits by state-2 digit NAICS industry-date tuple
safegraph_visit = safegraph_visit.dropna(how='any', subset=['naics_code'])
safegraph_visit['naics_string'] = safegraph_visit.naics_code.astype(str).str[:2]
safegraph_visit['naics_2'] = safegraph_visit.naics_string.astype(int)
temp_visit_df = safegraph_visit.groupby(['region', 'naics_2', 'date']).agg({'visit_0': ['sum'],'visit_1': ['sum'],'visit_2': ['sum'],'visit_3': ['sum'],'visit_4': ['sum'],'visit_5': ['sum'], 'visit_6': ['sum']})
post_visits = temp_visit_df.compute()
client.restart()


# Import and Clean POI Visit Data (Pre 06/24/2020)
print("2. Import and clean pre-July POI data") 

def load(filename):
    df = pd.read_csv(filename,
                     converters={'visits_by_day': lambda x: list(map(int,literal_eval(x)))},
                     usecols=['safegraph_place_id', 'date_range_start','region','visits_by_day'])
    return df

# For an unknown reason the Board's repository contains duplicate patterns data for mid/late June. Including this dataset will result in double counts of all visits during this period. As such, drop any observations from the 2020-06-15 release.
full_filenames = set(glob(data_path + '/weekly_patterns/v2/main-file/*.csv.gz'))
remove_filenames = set(glob(data_path + '/weekly_patterns/v2/main-file/2020-06-15-weekly-patterns.csv.gz'))
filenames = list(full_filenames.difference(remove_filenames))

from dask.delayed import delayed
dfs = [delayed(load)(fn) for fn in filenames]
df = ddf.from_delayed(dfs)
main = df.persist()
progress(main)

# Merge in POI core panel
safegraph_visit = ddf.merge(main, core_df, on=['safegraph_place_id', 'region'], how='inner')
safegraph_visit['date'] = ddf.to_datetime(safegraph_visit.date_range_start,utc=True).dt.date

# Separate the pre-July visits array into distinct series for each day of the week
safegraph_visit['visit_0'] = safegraph_visit.visits_by_day.apply(lambda x: x[0], meta=('visit_0', float))
safegraph_visit['visit_1'] = safegraph_visit.visits_by_day.apply(lambda x: x[1], meta=('visit_1', float))
safegraph_visit['visit_2'] = safegraph_visit.visits_by_day.apply(lambda x: x[2], meta=('visit_2', float))
safegraph_visit['visit_3'] = safegraph_visit.visits_by_day.apply(lambda x: x[3], meta=('visit_3', float))
safegraph_visit['visit_4'] = safegraph_visit.visits_by_day.apply(lambda x: x[4], meta=('visit_4', float))
safegraph_visit['visit_5'] = safegraph_visit.visits_by_day.apply(lambda x: x[5], meta=('visit_5', float))
safegraph_visit['visit_6'] = safegraph_visit.visits_by_day.apply(lambda x: x[6], meta=('visit_6', float))

# Sum visits by state-2 digit NAICS industry-date tuple
safegraph_visit = safegraph_visit.dropna(how='any', subset=['naics_code'])
safegraph_visit['naics_string'] = safegraph_visit.naics_code.astype(str).str[:2]
safegraph_visit['naics_2'] = safegraph_visit.naics_string.astype(int)
temp_visit_df = safegraph_visit.groupby(['region', 'naics_2', 'date']).agg({'visit_0': ['sum'],'visit_1': ['sum'],'visit_2': ['sum'],'visit_3': ['sum'],'visit_4': ['sum'],'visit_5': ['sum'], 'visit_6': ['sum']})
pre_visits = temp_visit_df.compute()

# Append all POI Visit Data
print("3. Append all POI data") 

poi_df = post_visits
poi_df = poi_df.append(pre_visits)
poi_df.columns = poi_df.columns.droplevel(1)
poi_df = poi_df.reset_index()

# Import and merge in each 2-digit NAICS industry's average share of 2019 GDP from Fred
naics2word = {11: {'industry': 'Agriculture, Forestry, Fishing and Hunting', 'fred_pgdp': 'VAPGDPAFH'}, 
              21: {'industry': 'Mining, Quarrying, and Oil and Gas Extraction', 'fred_pgdp': 'VAPGDPM'}, 
              22: {'industry': 'Utilities', 'fred_pgdp': 'VAPGDPU'}, 
              23: {'industry': 'Construction', 'fred_pgdp': 'VAPGDPC'}, 
              31: {'industry': 'Manufacturing', 'fred_pgdp': 'VAPGDPMA'}, 
              32: {'industry': 'Manufacturing', 'fred_pgdp': 'VAPGDPMA'}, 
              33: {'industry': 'Manufacturing', 'fred_pgdp': 'VAPGDPMA'}, 
              42: {'industry': 'Wholesale Trade', 'fred_pgdp': 'VAPGDPW'}, 
              44: {'industry': 'Retail Trade', 'fred_pgdp': 'VAPGDPR'}, 
              45: {'industry': 'Retail Trade', 'fred_pgdp': 'VAPGDPR'}, 
              48: {'industry': 'Transportation and Warehousing', 'fred_pgdp': 'VAPGDPT'}, 
              49: {'industry': 'Transportation and Warehousing', 'fred_pgdp': 'VAPGDPT'}, 
              51: {'industry': 'Information', 'fred_pgdp': 'VAPGDPI'}, 
              52: {'industry': 'Finance and Insurance', 'fred_pgdp': 'VAPGDPFI'}, 
              53: {'industry': 'Real Estate and Rental and Leasing', 'fred_pgdp': 'VAPGDPRL'}, 
              54: {'industry': 'Professional, Scientific, and Technical Services', 'fred_pgdp': 'VAPGDPPST'}, 
              55: {'industry': 'Management of Companies and Enterprises', 'fred_pgdp': 'VAPGDPMCE'}, 
              56: {'industry': 'Administrative and Support and Waste Management and Remediation Services', 
'fred_pgdp': 'VAPGDPAWMS'}, 
              61: {'industry': 'Educational Services', 'fred_pgdp': 'VAPGDPES'}, 
              62: {'industry': 'Health Care and Social Assistance', 'fred_pgdp': 'VAPGDPHCSA'}, 
              71: {'industry': 'Arts, Entertainment, and Recreation', 'fred_pgdp': 'VAPGDPAER'}, 
              72: {'industry': 'Accommodation and Food Services', 'fred_pgdp': 'VAPGDPAF'}, 
              81: {'industry': 'Other Services (except Public Administration)', 'fred_pgdp': 'VAPGDPOSEG'}, 
              92: {'industry': 'Public Administration', 'fred_pgdp': 'VAPGDPG'}}
fred_industry_list = [naics2word[industry]['fred_pgdp'] for industry in [11,21,22,23,31,42,44,48,51,52,53,54,55,56,61,62,71,72,81,92]]
industry_gdp = get_data_fred(fred_industry_list, datetime.strptime('2019-01-01','%Y-%m-%d'), datetime.strptime('2019-12-31','%Y-%m-%d'))
industry_mean = industry_gdp.mean()
industry_mean = industry_mean.reset_index()
industry_mean = industry_mean.rename(columns={'index': 'fred_pgdp', 0:'pgdp'})
industry_mean['industry'] = np.array([naics2word[naics]['industry'] for naics in [11,21,22,23,31,42,44,48,51,52,53,54,55,56,61,62,71,72,81,92]])
poi_df['industry'] = poi_df.naics_2.apply(lambda x: naics2word[int(x)]['industry'])
poi_df = poi_df.merge(industry_mean, how = 'left', on = ['industry'])

# Aggregate visits by region and date without 2019 GDP industry weights
poi_df_unweight = poi_df.groupby(['region', 'date']).agg({'visit_0': ['sum'],'visit_1': ['sum'],'visit_2': ['sum'],'visit_3': ['sum'],'visit_4': ['sum'],'visit_5': ['sum'], 'visit_6': ['sum']})

# Aggregate visits by region and date with 2019 GDP industry weights
poi_df_weight = poi_df
poi_df_weight['pgdp'] = poi_df_weight['pgdp']/(industry_mean.pgdp.sum())
for n in range(0, 7):
    poi_df_weight['visit_{}'.format(n)] = poi_df_weight['visit_{}'.format(n)] * poi_df_weight['pgdp']
poi_df_weight = poi_df_weight.groupby(['region', 'date']).agg({'visit_0': ['sum'],'visit_1': ['sum'],'visit_2': ['sum'],'visit_3': ['sum'],'visit_4': ['sum'],'visit_5': ['sum'], 'visit_6': ['sum']})
poi_df_unweight['top_category'] = 'unweighted'
poi_df_weight['top_category'] = 'weighted'

# Combine weighted and unweighted datasets
poi_df = poi_df_unweight
poi_df = poi_df.append(poi_df_weight)
poi_df.columns = poi_df.columns.droplevel(1)
poi_df = poi_df.reset_index()

##### 3) Convert POI Visit Data From Weekly to Daily ###############
print("4. Start converting POI data to daily frequency")

# For each weekly observation, list of all daily dates during that week
def day_to_list(start):
    return [start + timedelta(days=i) for i in range(7)]
poi_df['date_list'] = poi_df.apply(lambda x: day_to_list(x.date), axis=1)

# For each weekly observation, set the variable date_n and visit_n to the nth day of the week's date and visits, respectively (n ranges from 0 to 6, corresponding to the 7 days of the week)
for n in range(0, 7):
    poi_df['date_{}'.format(n)] = poi_df.date_list.apply(lambda x: x[n])

# Expand the dataset so that each weekly observation appears 7 times
poi_df_full = pd.concat([poi_df]*7, ignore_index=False)

# Set variable 'index_count' equal to a distinct value for each week
poi_df_full['index_count'] = poi_df_full.groupby(poi_df_full.index).cumcount()+1

# Reshape the dataset so that each row represents a day, not week
def reshape(x_index, xnum0, xnum1, xnum2, xnum3, xnum4, xnum5, xnum6):
    x_val = [xnum0, xnum1, xnum2, xnum3, xnum4, xnum5, xnum6]
    adjust_index = x_index - 1
    return  x_val[adjust_index]
poi_df_full['poi_date'] = poi_df_full.apply(lambda x: reshape(x.index_count, x.date_0, x.date_1, x.date_2, x.date_3, x.date_4, x.date_5, x.date_6), axis = 1)
poi_df_full['poi_visit'] = poi_df_full.apply(lambda x: reshape(x.index_count, x.visit_0, x.visit_1, x.visit_2, x.visit_3, x.visit_4, x.visit_5, x.visit_6), axis = 1)
poi_df_full['poi_visit'] = pd.to_numeric(poi_df_full.poi_visit)
poi_df_full = poi_df_full.reset_index(drop = True) 
poi_df_full = poi_df_full.drop_duplicates(subset=['region', 'top_category', 'poi_date'], keep='first')

##### 4) State-Level and National Aggregation  ################

# Aggregate total visits by industry, state, and day
poi_groups = poi_df_full.groupby(['region', 'top_category','poi_date'])['poi_visit'].sum().reset_index() 

# Calculate daily visits for the entire US and add US to panel
poi_us = poi_groups.groupby(['top_category','poi_date'])['poi_visit'].sum().reset_index() 
poi_us['region'] = 'US'
poi_groups_us = poi_groups.append(poi_us).reset_index()

##### 5) Normalization  ################

# Import Normalization Files
full_files = set(glob(data_path + '/weekly_patterns/v2/normalization-stats/*-normalization-stats.csv') + glob(data_path + '/weekly_patterns-delivery/weekly/normalization_stats/*/*/*/*/normalization_stats.csv'))
alt_list = []
for subdir, dirs, files in os.walk(data_path + '/weekly_patterns-delivery/weekly/normalization_stats/'):
    for file in files:
        filepath = subdir + os.sep + file
        if filepath.endswith(".csv"):
            if datetime.strptime(subdir[87:97], '%Y/%m/%d') > datetime.strptime('2020/08/05', '%Y/%m/%d'):
                alt_list = alt_list + [filepath]
alternate_files = set(alt_list)
files = list(full_files.difference(alternate_files))

# Starting in the second week of August 2020, Safegraph began including normalization statistics 
normalization = pd.concat([pd.read_csv(f) for f in files])
normalization_alt = pd.concat([pd.read_csv(f) for f in list(alternate_files)])
normalization_alt = normalization_alt[normalization_alt.region == 'ALL_STATES']
normalization_alt = normalization_alt.drop(columns=['region'])
normalization = normalization.append(normalization_alt).reset_index()

# In preparation for merging, add date variable to normalization dataset
normalization['poi_date'] = normalization.apply(lambda x:datetime.strptime("{0} {1} {2} 00:00:00".format(x['year'],x['month'], x['day']), "%Y %m %d %H:%M:%S").date(),axis=1)

# Merge normalization dataset with mobility dataset
poi_df_norm = poi_groups_us.merge(normalization, on='poi_date', how='inner')

# Normalize visits by panel size (number of devices seen)
poi_df_norm['norm_visits'] = poi_df_norm.poi_visit/poi_df_norm.total_devices_seen

##### 6) Smoothing - 7 day rolling average  ################

# To account for the strong weekly seasonality, take a seven day moving average
poi_df_norm_temp = poi_df_norm.sort_values(['region', 'top_category', 'poi_date']).reset_index(drop=True)
poi_df_norm_temp['group_num'] = poi_df_norm_temp.groupby(['region', 'top_category']).ngroup()
poi_df_norm_temp['smooth_norm_visit'] = poi_df_norm_temp.groupby(['group_num'])['norm_visits'].transform(lambda x: x.rolling(window=7, center=False).mean())


##### 7) Standardization  ################

# Calculate the median value between the 2nd and 3rd Wednesday of January. The dates used for 2019 and 2020 are [2019-01-09, 2019-01-16) and [2020-01-08, 2020-01-15), respectively. 
# In their own visualizations, Safegraph makes the strong assumption that foot-traffic in early January == 1 for both 2019 and 2020. We follow this convention but allow for the specification of an offset factor (adjust_factor) in the case that one has strong priors regarding the absolute difference of foot-traffic between 2019 and 2020. 
year_clean = {2019: {'median_start_date': 'date(2019,1,9)', 'median_end_date': 'date(2019,1,16)', 'adjust_factor': 0}, 2020: {'median_start_date': 'date(2020,1,8)', 'median_end_date': 'date(2020,1,15)', 'adjust_factor': 0}}

# For each state-industry pair, subset our normalized visit dataset to only observations occurring between our specified standardization dates
for select in range(0,len(year_clean)):
    year_val = list(year_clean.keys())[select] 
    if select == 0:
        date_string = 'poi_df_norm_temp.poi_date.between({}, {})'.format(year_clean[year_val]['median_start_date'], year_clean[year_val]['median_end_date'])
    else:
        date_string = date_string + ' | ' + 'poi_df_norm_temp.poi_date.between({}, {})'.format(year_clean[year_val]['median_start_date'], year_clean[year_val]['median_end_date'])
exec_date_string = 'selected_dates = poi_df_norm_temp[{}].reset_index(drop=True)'.format(date_string)
exec(exec_date_string) 

# Calculate median normalized visits for each state-industry pair or observations occurring during the specified dates
median_df = selected_dates.groupby(['group_num', 'year'])['norm_visits'].median().reset_index()
median_df.rename(columns={'norm_visits':'median_val'}, inplace=True)

# To standardize our foot-traffic data, divide normalized visits by its corresponding median
poi_df_median = poi_df_norm_temp.merge(median_df, on=['group_num', 'year'], how='inner')
poi_df_median['smooth_norm_stand_visit'] = poi_df_median.smooth_norm_visit/poi_df_median.median_val

# Add offset factor to specify absolute difference between Janaury 2019 and 2020
def year_adjust(year, val):
    adjust = year_clean[year]['adjust_factor']
    return val + adjust
poi_df_median['smooth_norm_stand_adjust_visit'] = poi_df_median.apply(lambda x: year_adjust(x.year, x.smooth_norm_stand_visit), axis=1)

##### 8) Compute Year-Over-Year Daily Log Change ################

# Take daily year-over-year log difference
poi_df_median['date_offset'] = (poi_df_median.poi_date - pd.DateOffset(years=1)).apply(lambda x: x.date())
poi_df_median_temp = poi_df_median[['region', 'top_category', 'poi_date', 'smooth_norm_stand_adjust_visit']]
poi_df_median_temp.rename(columns = {'poi_date':'date_offset', 'smooth_norm_stand_adjust_visit':'poi_old_visit'}, inplace = True) 
poi_df_median = poi_df_median.merge(poi_df_median_temp, how = 'left', on = ['region', 'top_category', 'date_offset'])
poi_df_median['smooth_norm_stand_adjust_visit_log'] = np.log(poi_df_median.smooth_norm_stand_adjust_visit) - np.log(poi_df_median.poi_old_visit)

# Drop unnecessary variables
poi_df_median = poi_df_median.drop(columns=['date_offset', 'median_val', 'group_num'])

##### 9) Export SafeGraph POI Visits Data  ################
# Export POI visits data
poi_df_median.to_csv('./final/visits_safegraph_agg.csv')

# Print if execution successful
print("safegraph_clean.py complete!")
