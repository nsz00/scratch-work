from pandas_datareader import get_data_fred
import datetime
import pandas as pd
import math
from functools import reduce

def replicate_fred_state_data(fred_series, states, start, end, freq = 'D'):
    fred_state_list = [state + fred_series for state in states]
    replicateADS_states = get_data_fred(fred_state_list, datetime.datetime.strptime(start,'%Y-%m-%d'), datetime.datetime.strptime(end,'%Y-%m-%d'))
    replicateADS_states = replicateADS_states.dropna(how='all')

    # For monthly (M), quarterly (Q), and annual (A) series, assign the series value to the last day of the month, quarter, and year, respectively
    if freq == 'M':
        replicateADS_states.index = [d + pd.tseries.offsets.MonthEnd(n=0) 
                                     for d in replicateADS_states.index]
    elif freq == 'Q':
        replicateADS_states.index = [d + pd.tseries.offsets.QuarterEnd(n=0) 
                                     for d in replicateADS_states.index]
    elif freq == 'A':
        replicateADS_states.index = [d + pd.tseries.offsets.YearEnd(n=0) 
                                     for d in replicateADS_states.index]

    ix = pd.date_range(start=datetime.datetime.strptime(start,'%Y-%m-%d'), end=datetime.datetime.strptime(end,'%Y-%m-%d'), freq='D')
    replicateADS_states = replicateADS_states.reindex(ix)
    replicateADS_states = replicateADS_states.asfreq('D')
    
    replicateADS_states_lead = replicateADS_states.shift(1)
    for ADS_df in (replicateADS_states, replicateADS_states_lead):
        ADS_orig = ADS_df
        ADS_df.columns = ADS_df.columns.str.replace(fred_series, '')
        ADS_df = ADS_df.reset_index()
        ADS_df = ADS_df.rename(columns={'index': 'DATE'})
        ADS_df = pd.melt(ADS_df, id_vars ='DATE', value_vars = states)
        if ADS_orig.equals(replicateADS_states): 
            ADS_0 = ADS_df.rename(columns={'value': fred_series + '0', 'variable': 'STATE'})
        else:
            ADS_1 = ADS_df.rename(columns={'value': fred_series + '1', 'variable': 'STATE'})
    replicateADS_states_all = pd.merge(ADS_0, ADS_1, how='outer', on=['DATE', 'STATE'])
    return replicateADS_states_all
    

def replicate_ADS_state_data(start='1939-01-01', end=str(datetime.datetime.date(datetime.datetime.now()))):
    # State-level Fred Series: weekly initial claims, monthly non-farm payrolls, quarterly nominal GDP (begins 2005), annual nominal GDP (begins 1997 and equals the arithmetic mean of quarterly nominal GDP)
    series = ['ICLAIMS','NAN', 'NQGSP', 'NGSP']
    states = ["AL", "MO", "AK", "MT", "AZ", "NE", "AR", "NV", "CA", "NH", "CO", "NJ", "CT", "NM", "DE", "NY", "DC", "NC", "FL", "ND", "GA", "OH", "HI", "OK", "ID", "OR", "IL", "PA", "IN", "RI", "IA", "SC", "KS", "SD", "KY", "TN", "LA", "TX", "ME", "UT", "MD", "VT", "MA", "VA", "MI", "WA", "MN", "WV", "MS", "WI", "WY"]

    iclaims = replicate_fred_state_data(series[0], states, start=start, end=end)
    nonfarm = replicate_fred_state_data(series[1], states, start=start, end=end, freq = 'M')
    gdp_q = replicate_fred_state_data(series[2], states, start=start, end=end, freq = 'Q')
    gdp_a = replicate_fred_state_data(series[3], states, start=start, end=end, freq = 'A')

    # Since quarterly nominal GDP begins in 2005, construct a nominal GDP series, NAQGSP, which equals NGSP until 2005 and then NQGSP thereafter.  
    gdp_aq = pd.merge(gdp_q, gdp_a, how='outer', on=['DATE', 'STATE'])
    gdp_aq['NAQGSP0'] = gdp_aq.apply(lambda x: x['NGSP0'] if math.isnan(x['NQGSP0']) else x['NQGSP0'], axis=1)
    gdp_aq['NAQGSP1'] = gdp_aq.apply(lambda x: x['NGSP1'] if math.isnan(x['NQGSP1']) else x['NQGSP1'], axis=1)
    
    # Deflate all nominal GDP series by the US aggregate GDP implicit price deflator 
    deflator = get_data_fred('USAGDPDEFQISMEI', start = start, end = end)
    deflator = deflator.dropna(how='all')
    deflator.index = [d + pd.tseries.offsets.QuarterEnd(n=0) 
                      for d in deflator.index]
    ix = pd.date_range(start=datetime.datetime.strptime(start,'%Y-%m-%d'), end=datetime.datetime.strptime(end,'%Y-%m-%d'), freq='D')
    deflator = deflator.reindex(ix)
    deflator = deflator.asfreq('D')
    deflator = deflator.rename(columns={'USAGDPDEFQISMEI': 'DEFLATOR0'})
    deflator['DEFLATOR1'] = deflator.DEFLATOR0.shift(1)
    deflator = deflator.reset_index()
    deflator = deflator.rename(columns={'index': 'DATE'})
    gdp_aq_deflator = pd.merge(gdp_aq, deflator, how='left', on=['DATE'])
    for def_var in ['NQGSP0', 'NQGSP1', 'NAQGSP0', 'NAQGSP1']:
        def_var_new = 'R' + def_var[1:] 
        if def_var[-1] == '0':
            gdp_aq_deflator[def_var_new] = gdp_aq_deflator[def_var]/gdp_aq_deflator['DEFLATOR0']
        else:
            gdp_aq_deflator[def_var_new] = gdp_aq_deflator[def_var]/gdp_aq_deflator['DEFLATOR1']
    rgdp = gdp_aq_deflator[['STATE', 'DATE', 'RQGSP0', 'RQGSP1', 'RAQGSP0', 'RAQGSP1']]
    state_data = reduce(lambda  left,right: pd.merge(left,right, how="outer", on = ['STATE', 'DATE']), [iclaims, nonfarm, rgdp])
    state_data = state_data.rename(columns={'NAN0': 'PAYROLL0', 'NAN1': 'PAYROLL1'})
    return state_data

ADS_states = replicate_ADS_state_data()   
git_path = ./state_level'
ADS_states.to_csv(git_path + '/final/state_level_fred.csv', index = False)
