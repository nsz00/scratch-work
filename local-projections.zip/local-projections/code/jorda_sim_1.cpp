#include <boost/random.hpp>
#include <Eigen/Dense>
#include <Eigen/Cholesky>
#include <iomanip>
#include <estimation/data>
#include <estimation/regression>
#include <PATH/src/impulse_response/irf.hpp>
#include <monte_carlo.hpp>
#include <percent_value.hpp>
#include <math.h>
#include <cmath>

int main(){

  //Import Jorda data
  csv_import reader("notes/jorda-data.csv");
  std::vector<std::vector<std::string> > data_vec = reader.get_data();

  //Store Jorda data in Eigen matrix
  int num_vars = 6;
  int num_obs = 494;
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> jorda_data(num_obs,num_vars); 
  int i = 0;
  int j = 0;
  for(std::vector<std::string> vec : data_vec){
    for(std::string data : vec){  
      jorda_data(i,j) = atof(data.c_str());
      j = j + 1;
    }
    j = 0;
    i = i + 1;
  }
  
  //Initialize shock
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> jorda_shock(num_vars, 1);
  jorda_shock << 0, 0, 0, .5, 0, 0;

  Eigen::MatrixXd D(num_vars, num_vars);

  D <<  0.16,  0.  ,  0.  ,  0.  ,  0.  ,  0.  ,
       -0.01,  0.14,  0.  ,  0.  ,  0.  ,  0.  ,
        0.21,  0.21,  1.9 ,  0.  ,  0.  ,  0.  ,
        0.05, -0.02,  0.1 ,  0.47,  0.  ,  0.  ,
       -0.  , -0.  , -0.  , -0.01,  0.01,  0.  ,
        0.02,  0.  ,  0.  , -0.04,  0.02,  0.27;
  //jorda_shock  = D * jorda_shock; 

  //Calculate VAR(12) contemporaneous correlation matrix and coefficient matrix of data
  estimation::impulse_response::irf jorda_irf_12(jorda_data, 12, jorda_shock);
 // jorda_irf_12.a_0.setIdentity();  
  std::cout << jorda_irf_12.a_0  << std::endl;
  
  //Run a Monte Carlo simulation of the Jorda data using the contemporaneous
  //correlation and coefficient matricies from the VAR(12); initialize the
  //simulation using first 12 observations from the Jorda data; create 500
  //series of 494 observations each
  int series_num = 500;
  int initial_obs = 12;
  estimation::monte_carlo::monte_carlo jorda_mc1(jorda_data, 494, series_num, initial_obs, jorda_irf_12.a_0, jorda_irf_12.varmodel.beta);

  //Calculate a VAR(12), VAR(2), linear projections impulse response with h=24 from each series
  int h_num = 24;
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> jorda_mc1_irf_var12(h_num, series_num*num_vars);
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> jorda_mc1_irf_var2(h_num, series_num*num_vars);
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> jorda_mc1_irf_lp2(h_num, series_num*num_vars);
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> temp_mc_data(num_obs + initial_obs, num_vars);

  for(int nrep = 0; nrep < series_num; nrep++){
    std::cout << "iteration " << nrep << " [" 
              << std::string(int(float(nrep) / float(series_num) * 20.0)+1,'=') 
              << std::string(20 - int(float(nrep) / float(series_num) * 20.0)+1,' ') 
              << "]\r" << std::flush;
    temp_mc_data = jorda_mc1.mc_output.block(0,nrep*num_vars,num_obs + initial_obs, num_vars);
    estimation::impulse_response::irf jorda_irf_12(temp_mc_data, 12, jorda_shock);
    estimation::impulse_response::irf jorda_irf_2(temp_mc_data, 2, jorda_shock);
    jorda_mc1_irf_var12.block(0,nrep*num_vars,h_num,num_vars) = jorda_irf_12.irf_var(h_num);
    jorda_mc1_irf_var12.block(0,nrep*num_vars,h_num,num_vars) = jorda_mc1_irf_var12.block(0,nrep*num_vars,h_num,num_vars)*0.5/jorda_irf_12.irf_var(h_num)(0,3);
    jorda_mc1_irf_var2.block(0,nrep*num_vars,h_num,num_vars) = jorda_irf_2.irf_var(h_num);
    jorda_mc1_irf_var2.block(0,nrep*num_vars,h_num,num_vars) = jorda_mc1_irf_var2.block(0,nrep*num_vars,h_num,num_vars)*0.5/jorda_irf_2.irf_var(h_num)(0,3);
    //jorda_mc1_irf_var2.block(0,nrep*num_vars,h_num,num_vars) = jorda_irf_2.irf_var(h_num);
    jorda_mc1_irf_lp2.block(0,nrep*num_vars,h_num,num_vars) = jorda_irf_2.irf_lp(h_num,jorda_mc1_irf_var12.block(0,nrep*num_vars,1,num_vars));
  }  
  //Compute mean impulse response at each horizon for VAR(12), VAR(2), and linear projections
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> temp_irf_data_var12(h_num, series_num);
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> temp_irf_data_var2(h_num, series_num);
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> temp_irf_data_lp2(h_num, series_num);
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> jorda_var12_irf(h_num, num_vars);
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> jorda_var2_irf(h_num, num_vars);
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> jorda_lp2_irf(h_num, num_vars);
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> jorda_var12_irf_5percent(h_num, num_vars);
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> jorda_var12_irf_95percent(h_num, num_vars);
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> jorda_var12_irf_sd(h_num, num_vars);
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> jorda_var12_irf_p2sd(h_num, num_vars);
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> jorda_var12_irf_n2sd(h_num, num_vars);
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> temp_irf_data_var12_meandiff(h_num, series_num);

  for(int w = 0; w < num_vars; w++){
    for(int k = 0; k < series_num; k++){
      temp_irf_data_var12.col(k) = jorda_mc1_irf_var12.col(k*num_vars+w);
      temp_irf_data_var2.col(k) = jorda_mc1_irf_var2.col(k*num_vars+w);
      temp_irf_data_lp2.col(k) = jorda_mc1_irf_lp2.col(k*num_vars+w);
    }
    
    //Calculate mean impulse response
    jorda_var12_irf.col(w) = temp_irf_data_var12.rowwise().mean();
    jorda_var2_irf.col(w) = temp_irf_data_var2.rowwise().mean();
    jorda_lp2_irf.col(w) = temp_irf_data_lp2.rowwise().mean();
    
    //Calculate standard deviation of VAR(12) IRF
    for(int k = 0; k < series_num; k ++){
      for(int h = 0; h < h_num; h++){
	  temp_irf_data_var12_meandiff(h,k) = pow(temp_irf_data_var12(h,k) - jorda_var12_irf(h,w), 2.0);
	  }
     }
    jorda_var12_irf_sd.col(w) = temp_irf_data_var12_meandiff.rowwise().sum();
for(int hor = 0; hor < h_num; hor++){
  jorda_var12_irf_sd(hor,w) = sqrt(jorda_var12_irf_sd(hor,w));
    }

    //Caluclate 5% and 95% VAR(12) impulse response Monte Carlo simulation values
    jorda_var12_irf_5percent.col(w) = estimation::monte_carlo::percent_value(temp_irf_data_var12, .05);
    jorda_var12_irf_95percent.col(w) = estimation::monte_carlo::percent_value(temp_irf_data_var12, .95);
  
  }
    //Calculate two standard error bands
  jorda_var12_irf_sd = jorda_var12_irf_sd*(1/sqrt((double)series_num));
  for(int i = 0; i < h_num; i++){
    for(int j = 0; j < num_vars; j++){
      jorda_var12_irf_p2sd(i,j) = jorda_var12_irf(i,j) + (2.0*jorda_var12_irf_sd(i,j));
      jorda_var12_irf_n2sd(i,j) = jorda_var12_irf(i,j) - (2.0*jorda_var12_irf_sd(i,j));
    }
  }

  //Export impulse responses to csv files
  csv_exporter sim1_varirf_12("./local-projections/sim1_varirf_12.csv", jorda_var12_irf, ",");
  sim1_varirf_12.storeEigen();
  csv_exporter sim1_varirf_12_5percent("./local-projections/sim1_varirf_12_5percent.csv", jorda_var12_irf_5percent, ",");
  sim1_varirf_12_5percent.storeEigen();
  csv_exporter sim1_varirf_12_95percent("./local-projections/sim1_varirf_12_95percent.csv", jorda_var12_irf_95percent, ",");
  sim1_varirf_12_95percent.storeEigen();
  csv_exporter sim1_varirf_12_sd_u("./local-projections/sim1_varirf_12_sd_u.csv", jorda_var12_irf_p2sd, ",");
  sim1_varirf_12_sd_u.storeEigen();
  csv_exporter sim1_varirf_12_sd_l("./local-projections/sim1_varirf_12_sd_l.csv", jorda_var12_irf_n2sd, ",");
  sim1_varirf_12_sd_l.storeEigen();
  csv_exporter sim1_varirf_2("./local-projections/sim1_varirf_2.csv", jorda_var2_irf, ",");
  sim1_varirf_2.storeEigen();
  csv_exporter sim1_lpirf_2("./local-projections/sim1_lpirf_2.csv", jorda_lp2_irf, ",");
  sim1_lpirf_2.storeEigen();   

}
