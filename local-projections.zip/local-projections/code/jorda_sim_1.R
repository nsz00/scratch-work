library(reshape2)
library(Rmisc)
library(ggplot2)
library(gbm)
library(grid)

#Import Jorda simulation 1 data
lp_data <- read.csv("sim1_lpirf_2.csv", header = FALSE)[,1:6]
var_data_2 <- read.csv("sim1_varirf_2.csv", header = FALSE)[,1:6]
var_data_12 <- read.csv("sim1_varirf_12.csv", header = FALSE)[,1:6]
var_data_5p <- read.csv("sim1_varirf_12_sd_l.csv", header = FALSE)[,1:6]
var_data_95p <- read.csv("sim1_varirf_12_sd_u.csv", header = FALSE)[,1:6]

var_name <- c("EM", "P", "PCOM", "FF", "NBRX", "M2")
labs <- c("VAR(12)", "VAR(2)", "LP(2)", "SE-U", "SE-L")



for(var in 1:6){
  assign("LP", lp_data[,var])
  assign("VAR_12", var_data_12[,var])
  assign("VAR_2", var_data_2[,var])
  assign("p_5", var_data_5p[,var])
  assign("p_95", var_data_95p[,var])
  assign(paste0(var_name[var], "_df"), cbind(VAR_12, VAR_2, LP, p_5, p_95))
  assign(paste0(var_name[var], "_df"), melt(eval(parse(text = paste0(var_name[var], "_df"))), measure.vars = c("LP", "VAR_12", "VAR_2", "p_5", "p_95")))
  
  assign(paste0("p", var), ggplot(eval(parse(text = paste0(var_name[var], "_df"))), aes(x = Var1, y = value)) + 
           geom_line(aes(color = Var2, linetype = Var2), size = 1) +
           scale_linetype_manual(values=c("solid", "dashed", "dotdash", "dotted", "dotted"), labels = labs, name = NULL) + 
           scale_color_manual(values = c("#56B4E9", "#E69F00", "#009E73", "#999999", "#999999"), labels = labs, name = NULL) + 
           theme_classic() + 
           scale_x_continuous("", breaks = seq(1, 24, 1), labels = c("", 2, "", 4, "", 6, "", 8, "", 10, "", 12, "", 14,"", 16, "", 18, "", 20, "", 22, "", 24), limits = c(0, 24), expand = c(0,0)) +
           ylab("") +
           ggtitle(paste0("Response of ", var_name[var])) + 
           theme(legend.position = "bottom", plot.title = element_text(hjust = 0.5, size=10), legend.margin=margin(t=-.5, r=0, b=0, l=0, unit="cm"), legend.key.width = unit(.6,"cm"), legend.text = element_text(size=(6))))  
  eval(parse(text =paste0("p", var)))
}


pdf(
  "sim1.pdf",
  width = 8.5,
  height = 11,
  family = "Helvetica", 
)
grid.arrange(p1, p2, p3, p4, p5, p6, nrow = 3, vp=viewport(width=.9, height=0.9), top = "Figure 1. Impulse Responses to a Shock in FF. Lag Length 2")
dev.off()
