#ifndef ESTIMATION_PERCENT_VALUE_HPP
#define ESTIMATION_PERCENT_VALUE_HPP
#include <Eigen/Dense>
#include <Eigen/Sparse>
#include <boost/random.hpp>
#include <cmath>
#include <algorithm>

namespace estimation {
namespace monte_carlo {

  /** Computes n-percent value for each row (or column) or a matrix.
   *
   * \param mx_value data
   * \param percent desired n% value
   * \param by_row calculate n% value by row (if false, calculate by column)
   *
   */
  Eigen::Matrix<double, Eigen::Dynamic,1> percent_value(Eigen::Matrix<double, Eigen::Dynamic, Eigen::Dynamic> mx_value, float percent, bool by_row = true){
    int row = mx_value.rows();
    int col = mx_value.cols();
    int percent_val;
    int rounded_val;
    Eigen::VectorXd values_c(row);
    Eigen::VectorXd values_r(col);
    Eigen::Matrix<double, Eigen::Dynamic,1> percent_output_r(row,1);
    Eigen::Matrix<double, Eigen::Dynamic,1> percent_output_c(col,1);
    if(by_row == true){
      rounded_val = round(percent*col) - 1;
      percent_val = std::max(rounded_val, 0);
      for(int i = 0; i < row; i++){
	values_r = mx_value.row(i);
	std::sort(values_r.data(),values_r.data()+values_r.size()); 
	percent_output_r(i, 0) = values_r(percent_val);
      }
      return percent_output_r;
    } else {
     rounded_val = round(percent*row) - 1;
     percent_val = std::max(rounded_val, 0);
     for(int j = 0; j < col; j++){
       values_c = mx_value.col(j);
       std::sort(values_c.data(),values_c.data()+values_c.size()); 
       percent_output_c(j, 0) = values_c(percent_val);
      }
     return percent_output_c;
    }
  }
}
}
#endif
