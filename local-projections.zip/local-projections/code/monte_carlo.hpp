#ifndef ESTIMATION_MONTE_CARLO_1_HPP
#define ESTIMATION_MONTE_CARLO_1_HPP
#include <Eigen/Dense>
#include <Eigen/Sparse>
#include <boost/random.hpp>

namespace estimation {
namespace monte_carlo {
/** Monte Carlo Simulation.
 */
class monte_carlo {
private:
  int T;
  int nx;
  int s;
  int p;
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> mc_input;
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> beta;
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> corr;
  Eigen::Matrix<double, Eigen::Dynamic, Eigen::Dynamic> ymc;
  Eigen::Matrix<double, 1, Eigen::Dynamic> xmc;
public:
  /** Monte Carlo simulated data.
   */
  Eigen::Matrix<double, Eigen::Dynamic, Eigen::Dynamic> mc_output;
  
  monte_carlo() { }
  /** Constructor for monte_carlo simulation.
   *
   * \param data data input
   * \param length number of observations to be simulated
   * \param series number of series to simulate
   * \param lag number of original observations used to initialize simulation
   * \param contemp_corr_mx contemporaneous correlation matrix
   * \param coef_mx coefficient matrix
   * 
   */
  monte_carlo(const Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic>& data, int length, int series, int lag, const Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic>& contemp_corr_mx, const Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic>& coef_mx ){
    
    //Initialize private variables
    nx = data.cols();
    mc_input.resize(data.rows(), nx);
    mc_input = data;
    T = length;
    s = series;
    p = lag;
    corr.resize(contemp_corr_mx.rows(), contemp_corr_mx.cols());
    beta.resize(coef_mx.rows(), coef_mx.cols());
    corr = contemp_corr_mx;
    beta = coef_mx; 
    mc_output.resize(T+p,nx*s);

    //Create a matrix of random normal residuals
    boost::random::mt19937 rng(123456); 
    boost::random::normal_distribution<>normal01(0.0, 1.0);
    Eigen::Matrix<double, Eigen::Dynamic, Eigen::Dynamic> all_residuals(T,nx*series);
    for (int i = 0; i < T; i++){
      for (int j = 0; j < nx*series; j++) {
	all_residuals(i,j) = normal01(rng);
      }
    }
    Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> residuals(T,nx);
    Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> umc(T, corr.rows());

 for(int nrep = 0; nrep < s; nrep++){

   //Assign residuals
   residuals = all_residuals.block(0,nx*nrep,T,nx);

    //Calculate errors of covariance structure
    umc = residuals*corr.inverse();
    
    //Generate Monte Carlo simulated data of length T + p
    ymc.resize(p + T, nx);
    ymc.block(0,0,p,nx) = mc_input.block(0,0,p,nx);
    ymc.block(p,0,T,nx) = Eigen::MatrixXd::Zero(T,nx);
    xmc.resize(1,(nx*p)+1);
    xmc(0,0) = 1;
    for(int i = 0; i < T; i++){
      for(int j = 0; j < p; j++){
	xmc.block(0,j*nx + 1,1,nx) = ymc.row(p + i - (j+1));
      }
      ymc.row(p + i) = xmc*beta;
      for(int j = 0; j < nx; j++){
      ymc(p + i, j) += umc(i,j);
      }
    }
   //Store simulated series data
   mc_output.block(0,nrep*nx,T+p, nx) = ymc;
 }
  }
};
}
}
#endif
