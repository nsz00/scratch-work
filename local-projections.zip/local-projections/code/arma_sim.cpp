#include <boost/random.hpp>
#include <Eigen/Dense>
#include <algorithm>

//g++ arma_sim.cpp -o arma -I/PATH/include -I/PATH/unsupported
//Simulate ARMA function
Eigen::VectorXd simulate_arma(const Eigen::VectorXd shocks, int T, 
                              double mu,
                               Eigen::VectorXd& phi, 
                               Eigen::VectorXd& theta,
                               double theta0=1) {

  int nar = phi.size();
  int nma = theta.size();
  
  Eigen::MatrixXd TT;
  TT.resize(std::max(nar, 1) + nma,std::max(nar, 1) + nma);
  TT.setZero();
  Eigen::MatrixXd RR(std::max(nar, 1) + nma,1);
  RR.setZero();
  RR(0,0) = theta0;
  
  if(nar > 0){
    TT.block(0,0,1,nar) = phi.transpose();
    if(nar > 1){
      Eigen::MatrixXd I_nar(nar+nma, nar+nma);
      TT.block(1,0, nar-1, nar+nma) = I_nar.setIdentity().block(0,0,nar-1,nar+nma); 
    }
  }
  
  if(nma > 0){
    TT.block(0,std::max(nar,1),1,nma) = theta.transpose();
    RR(std::max(nar,1),0) = 1.0;
    if(nma > 1){
      Eigen::MatrixXd I_nma(nma, nma);
      TT.block(std::max(nar,1) + 1,std::max(nar,1),nma-1,nma) = I_nma.setIdentity().block(0, 0, nma - 1, nma);
    }
  }
  
  Eigen::MatrixXd xi(std::max(nar, 1)+nma, T + 1);
  xi.setZero();
  if(nar > 0){
    xi(0,0) = mu;
    for(int t = 1; t <= T; t++){
      xi.col(t) = TT*xi.col(t-1) + RR*shocks(t - 1);
    }
  }else{
    Eigen::MatrixXd c(std::max(nar,1) + nma,1);
    c.setZero();
    c(0,0) = mu;
    for(int t = 1; t <= T; t++){
      xi.col(t) = c + TT*xi.col(t-1) + RR*shocks(t - 1);
    }
  }
  Eigen::VectorXd arma(T + 1);
  arma = xi.row(0).transpose();
  return arma.tail(T);
}

int main(){
  int T = 20;
  Eigen::VectorXd eps(T);
  boost::random::mt19937 rng(1234); 
  boost::random::normal_distribution<>normal01(0.0, 1.0);
  for (int i = 0; i < T; i++){
  	eps(i) = normal01(rng);
  }

  Eigen::VectorXd phiex(0);
  Eigen::VectorXd thetaex(0);
  
  std::cout << "\n" << "Here are the simulated values" << simulate_arma(eps,T,0,phiex,thetaex) << "\n";
}
