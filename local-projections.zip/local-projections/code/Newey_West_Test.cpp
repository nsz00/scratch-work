
#include <Eigen/Dense>
#include <Eigen/Sparse>
#include <iostream>
namespace estimation {
namespace regression {
/** Ordinary-least-squared model.
 */
class ols {
private:
  int T;
  int nx;
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> x;
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> g;
  Eigen::Matrix<double,Eigen::Dynamic,1> y;
public:
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> invxprimex;
  /** Regression coefficients.
   */
  Eigen::Matrix<double,Eigen::Dynamic,1> beta;
  /** Regression errors.
   */
  Eigen::Matrix<double,Eigen::Dynamic,1> eps;
  ols() { }
  /** Constructor for ols model.
   *
   * \param ydata dependent data
   * \param xdata exogenous data
   * \param addconstant should a constant be added to the exogenous data?
   */
  ols(const Eigen::Matrix<double,Eigen::Dynamic,1>& ydata, const Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic>& xdata, bool addconstant = true, bool sparseinverse = false) {
    T = xdata.rows();
    nx = xdata.cols();
    if (addconstant) {
      nx += 1;
    }
    x.resize(T,nx);
    if (addconstant) {
      for (int i=0;i<T;i++) {
	x(i,0) = 1.0;
      }
      x.block(0,1,T,nx-1) = xdata;
    } else {
      x = xdata;
    }
    y.resize(T);
    y = ydata;
    invxprimex.resize(nx,nx);
    if (sparseinverse) {
      Eigen::SparseMatrix<double> xpx(nx,nx);
      invxprimex = x.transpose() * x;
      for (int i = 0; i<nx; i++) {
	for (int j=0; j<nx; j++) {
	  if (abs(invxprimex(i,j)) > 0.00000001) {
	    xpx.insert(i,j) = invxprimex(i,j);
	  }
	}
      }
      Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> I_nx(nx,nx);
      I_nx.setIdentity();
      xpx.makeCompressed();
      Eigen::SimplicialLLT<Eigen::SparseMatrix<double>> solverxpx;
      solverxpx.compute(xpx);
      invxprimex = solverxpx.solve(I_nx);
    } else {
      invxprimex = (x.transpose() * x).inverse();
    }
    beta.resize(nx);
    beta = invxprimex * x.transpose() * y;
    eps.resize(T);
    eps = y - x * beta;
  }

  /** Computes variance/covariance matrix for beta with homoskedastic standard errors.
   */
/*  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> cov() {    
    Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> cov_mx(nx,nx);
    cov_mx =(eps.transpose()*eps)*invxprimex*(double(1)/(T-nx));
    return cov_mx;
  }
*/

  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> cov(int lags) {
    Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> I_T(T,T);
    I_T.setIdentity();
    I_T =(eps.transpose()*eps)*I_T*(double(1)/(T-nx));
    if(lags > 0){
	Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> mat_lag(T, T);
	Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> mat_lag_t(T,T);
      for (int i=1;i<=lags;i++) {
	Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> identity_mx(T - i, T- i);
	identity_mx.setIdentity();
	mat_lag.topRightCorner(T - i, T - i) = identity_mx;
	mat_lag_t = mat_lag.transpose();
	mat_lag = mat_lag_t+mat_lag;
	I_T +=(eps.transpose()*eps)*mat_lag*(double(1)/(T-nx))*(1.0-((double)i)/((double)lags+1.0));
      }
     }
    return  invxprimex * x.transpose() * I_T * x * invxprimex;
  }



  /** Computes Newey-West standard errors.
   *
   * \param lags number of lags to use.
   */
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> hac(int lags) {
    Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> S(nx,nx);
    if (g.rows() < T) {
      g.resize(T,nx);
      for (int j=0;j<x.cols();j++) {
	g.col(j) = x.col(j).array() * eps.array();
      }
    }
    S = g.transpose() * g;
    for (int i=1;i<=lags;i++) {
      S += g.block(i,0,T-i,nx).transpose()*g.block(0,0,T-i,nx)*2.0*(1.0-((double)i)/((double)lags+1.0));
    }
    return  invxprimex * S * invxprimex;
  }
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> hac_tester(int lags) {
    Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> S(nx,nx);
    if (g.rows() < T) {
      g.resize(T,nx);
      for (int j=0;j<x.cols();j++) {
	g.col(j) = x.col(j).array() * eps.array();
      }
    }
    S = g.transpose() * g;
    for (int i=1;i<=lags;i++) {
      S += ((g.block(i,0,T-i,nx).transpose()*g.block(0,0,T-i,nx)) + (g.block(0,0, T-i, nx).transpose()*g.block(i,0,T-i,nx)))*(1.0-((double)i)/((double)lags+1.0));
    }
    return  invxprimex * S * invxprimex;
  }

};
}
}

  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> lag(const Eigen::Matrix<double,Eigen::Dynamic,double,Eigen::Dynamic>& data, int lags, int max_lags) {
    if(lags > max_lags){
      std::cout << "Error: Desired lag must be less than or equal to maximum number of lags." << "\n";
    } else if(lags < 0 | max_lags < 0) {
      std::cout << "Error: Desired lag and maximum number of lags cannot be negative." << "\n";
    } else {
      int T = data.rows();
      int nx = data.cols();
      return data.block(max_lags - lags, 0, T-max_lags,nx);
    }
  }

Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> x_build(const Eigen::Matrix<double,Eigen::Dynamic,double,Eigen::Dynamic>& data, int max_lags) {
    int T = data.rows();
    int nx = data.cols();
    Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> x_data(T-max_lags, nx*(max_lags));
    for (int i=1;i<=max_lags;i++) {
     x_data.block(0,i*nx,T-max_lags,nx)<< lag(data, i, max_lags);
    }
    return x_data;
  }


Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> y_build(const Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic>& data, int max_lags) {
    return lag(data,0,max_lags);
  }


#include <Eigen/Dense>
#include <Eigen/Sparse>
#include <iostream>
#include <estimation/regression/sur>
namespace estimation {
namespace regression {
/** Vector Autoregression model.
 */
class var {
  /** Constructor for var model
   *
   * \param var_data dataset 
   * \param p number of lags
   * \param addconstant should a constant be added to the exogenous data?  
   */
var(const eigen::matrix<double,eigen::dynamic,eigen::dynamic>& var_data, int p, bool var_addconstant = true){
  sur(y_build(var_data, p), x_build(var_data, p), var_addconstant);  
}
};
}}
int main(){
  
int T {10};
Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> x(T,1);
Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> y(T,1);
Eigen::Matrix<int,Eigen::Dynamic,Eigen::Dynamic> g(T,1);
for (int i=0;i<T;i++) {
 x(i,0) = (double) i;
 y(i,0) = (double) (i*i);
}
estimation::regression::ols model(y,x,true);
std::cout << "This is the coefficient matrix" << "\n" << model.beta << "\n";
std::cout << "This is the error matrix" << "\n" << model.eps << "\n";
model.hac_tester(1);
std::cout << "Here" << model.hac_tester(1);
std::cout << "Here is our homoskedastic variance covariance matrix" << "\n" << model.cov(4) << "\n";
std::cout << "Here is the lagged matrix" <<  lag(x, 1, 5) << "\n";





}
