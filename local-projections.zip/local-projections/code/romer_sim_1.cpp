#include <estimation/src/data_import/csv_import.hpp>
#include <estimation/regression>
#include <estimation/src/toolchain/lag.hpp>
#include <Eigen/Dense>
#include <string>

int main(){
  //Import Romer data
  csv_import romer_reader("./local-projections/romer_data.csv");
  std::vector<std::vector<std::string> > data_vec = romer_reader.get_data();
  int col = 4;

  //Store Romer data in Eigen matrix
  //Determine the number of non-missing observations
  int available = 1;
  int obs = 0;
  int count = 0;
  std::string full_romer[2689*4]; 
  for(std::vector<std::string> vec : data_vec){
    for(std::string data : vec){ 
      if(data == ""){
	available = 0;
      }
      full_romer[count] = data;
      count = count + 1;
    }
      obs = obs + available;
      available = 1;
  }


  //Import GDP/shock data and determine row number of non-missing data
  Eigen::Matrix<double,Eigen::Dynamic,1> available_data(obs,1);
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> romer_data(obs,2); 
  int i = 0;
  int j = 0;
  available = 1;
  count = 0;
  for(std::vector<std::string> vec : data_vec){
    for(std::string data : vec){ 
      if(data == ""){
	available = 0;
      }
    }
    if(available == 1){
      available_data(count, 0) = i;
      for(std::string data : vec){
	if(j == 2 | j == 3){
	  romer_data(count,j - 2) = atof(data.c_str());
	}
	j = j + 1;
      }
      count = count + 1;
    }
    available = 1;
    j = 0;
    i = i + 1;
  }
  
  //Create time and country groups
  Eigen::Matrix<double,Eigen::Dynamic, Eigen::Dynamic> romer_groups(obs,2);
  romer_groups.setZero();
  int k;
  std::string group;
  int obs_num;
  int obs_num_w;
  int num_groups = 2;
  for(int g = 0; g < num_groups; g++){ 
    k = 0;
    for(int i = 0; i < obs; i++){
      obs_num = available_data(i,0);
      if(romer_groups(i,g) == 0){
	k = k + 1;
	romer_groups(i,g) = k;
	group = full_romer[obs_num*col + g];
	for(int w = 1; w < obs - i; w++){
	  if(romer_groups(i + w, g) == 0){
	    obs_num_w = available_data(i + w, 0);
	    if(group == full_romer[obs_num_w*col+g]){
	      romer_groups(i+w,g) = k;
	    }
	  }
	}
      }
    }
  }
  
  //Prepare the Romer data for regression
  int max_country =  romer_groups.col(0).maxCoeff();
  Eigen::Matrix<double, Eigen::Dynamic,Eigen::Dynamic> temp_romer_data;
  Eigen::Matrix<double, Eigen::Dynamic,Eigen::Dynamic> temp_romer_x1;
  Eigen::Matrix<double, Eigen::Dynamic,Eigen::Dynamic> temp_romer_x2;
  Eigen::Matrix<double, Eigen::Dynamic,Eigen::Dynamic> temp_romer_y;
  Eigen::Matrix<double, Eigen::Dynamic,Eigen::Dynamic> temp_romer_groups;
  Eigen::Matrix<double, Eigen::Dynamic,Eigen::Dynamic> temp_full_data;
  Eigen::Matrix<double, Eigen::Dynamic,Eigen::Dynamic> romer_full_data;
  Eigen::Matrix<double, Eigen::Dynamic,Eigen::Dynamic> romer_data_final;
  Eigen::Matrix<int, Eigen::Dynamic, Eigen::Dynamic> romer_groups_final;
  Eigen::Matrix<double, Eigen::Dynamic,Eigen::Dynamic> romer_results(11,2);
  int num_lags = 4;
  int state_count;
  int full_data_count;
  for(int h = 0; h < 11; h++){
    std::cout << "Calculating local projections for h = " << h << "\n";
    full_data_count = 0;
    romer_full_data.resize(obs, (col - 2)*num_lags + col);
    for(int state = 1; state < max_country + 1; state++){
      state_count = 0;
      for(int i = 0; i < obs; i++){
	if(romer_groups(i,0) == state){
	  state_count = state_count + 1;
	}
      }
      temp_romer_data.resize(state_count,col);
      state_count = 0;
      for(int i = 0; i < obs; i++){
	if(romer_groups(i,0) == state){
	  temp_romer_data.block(state_count,0, 1, 2) = romer_data.row(i);
	  temp_romer_data.block(state_count,2, 1, 2) = romer_groups.row(i);
	  state_count = state_count + 1;
	}
      }
      
      temp_romer_y.resize(state_count - (num_lags + h), col);
      temp_romer_y = estimation::toolchain::y_build(temp_romer_data, num_lags + h);
      temp_romer_x2.resize(state_count - (num_lags + h),(col - 2)*num_lags + 1);
      temp_romer_x1.resize(state_count - num_lags, num_lags);
      temp_romer_x1 = estimation::toolchain::x_build(temp_romer_data.block(0,0, state_count, 1), 4);
      temp_romer_x2.block(0, 0, state_count - (num_lags + h), 1) = temp_romer_data.block(num_lags, 1, state_count - (num_lags + h), 1);
      temp_romer_groups.resize(state_count - (num_lags + h), 2);
      temp_romer_groups = temp_romer_data.block(num_lags, 2, state_count - (num_lags + h), 2);
      temp_romer_x2.block(0, 1, state_count - (num_lags + h), num_lags)= temp_romer_x1.block(0, 0, state_count - (num_lags + h), num_lags);
      temp_romer_x1 = estimation::toolchain::x_build(temp_romer_data.block(0,1, state_count, 1), 4);
      temp_romer_x2.block(0, col + 1, state_count - (num_lags + h), num_lags)= temp_romer_x1.block(0, 0, state_count - (num_lags + h), num_lags);


      temp_full_data.resize(state_count - (num_lags + h), (col - 2)*num_lags + col);
      temp_full_data.block(0, 0, state_count - (num_lags + h), 1) = temp_romer_y.block(0,0, state_count - (num_lags + h), 1);
      temp_full_data.block(0, 1, state_count - (num_lags + h), num_lags*(col - 2) + 1) = temp_romer_x2;
      temp_full_data.block(0, (col -2)*(num_lags + 1), state_count - (num_lags + h), 2) = temp_romer_groups;
      romer_full_data.block(full_data_count, 0, state_count - (num_lags + h),(col - 2)*num_lags + col) = temp_full_data;
      full_data_count = full_data_count + state_count - (num_lags + h);
    }

    romer_data_final.resize(full_data_count, (col - 2)*num_lags + col);
    romer_data_final = romer_full_data.block(0, 0, full_data_count, (col - 2)*num_lags + col);
    romer_groups_final.resize(full_data_count, 2);
    romer_groups_final = romer_data_final.block(0,(col - 2)*num_lags + 1, full_data_count, 2).template cast <int>();

    //Estimate panel regression at horizon h
    estimation::regression::panel romer_panel(romer_data_final.col(0), romer_data_final.block(0,1,full_data_count, (col - 2)*num_lags + 1), romer_groups_final);
    romer_results(h,0) = romer_panel.beta[0];
}
  
  std::cout << "Here is the impulse response:" << romer_results;
}
