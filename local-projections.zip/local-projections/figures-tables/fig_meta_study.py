from figures import plt, colors
import os
import pandas as pd
import numpy as np


#Import meta-study data
google_scholar = pd.read_csv('../meta-study/literature-review.csv', encoding='cp1252', header = 1)

#Only keep papers the use local projections
google_scholar_df = google_scholar[google_scholar['Uses Local Projections'] == "Yes"].loc[:,['Paper', 'Minimum Number of Time Periods', 'Maximum Number of Time Periods', '"Rough Estimate" of Time Periods', '"Rough Estimate" of Time Periods (Primary Sample)']]

#Create "Best Available Estimate" variable
google_scholar_df['Best Available Estimate'] = google_scholar_df['"Rough Estimate" of Time Periods'] 
google_scholar_df['Best Available Estimate'] = google_scholar_df['Best Available Estimate'].mask(pd.isnull, google_scholar_df['"Rough Estimate" of Time Periods (Primary Sample)'])
google_scholar_df['Best Available Estimate'] = google_scholar_df['Best Available Estimate'].mask(pd.isnull, google_scholar_df['Maximum Number of Time Periods'])
google_scholar_df['Best Available Estimate'] = google_scholar_df['Best Available Estimate'].mask(pd.isnull, google_scholar_df['Minimum Number of Time Periods'])

#Plot histograms
num_bins = 30
fig, ax = plt.subplots(3, 2)
fig.suptitle('Histograms of T in top 100 Google Scholar papers')

#Minimum
ax = plt.subplot(3, 2, 1)
ax.hist(google_scholar_df['Minimum Number of Time Periods'], num_bins)
ax.set_xlabel('T')
ax.set_ylabel('Papers')
ax.set_title(r'Minimum', size = 11)
ax.axvline(494, ymax = .9,  color = 'orange',  linestyle='dashed')
ax.annotate(r"Jordà (2005)",  ha='center',  xy =(494,14.5), size = 9)

#Maximum
ax = plt.subplot(3, 2, 2)
ax.hist(google_scholar_df['Maximum Number of Time Periods'], num_bins)
ax.set_xlabel('T')
ax.set_ylabel('Papers')
ax.set_title(r'Maximum', size = 11)
ax.axvline(494, color = 'orange',  linestyle='dashed')

#Rough Estimate
ax = plt.subplot(3, 2, 3)
ax.hist(google_scholar_df['"Rough Estimate" of Time Periods'], num_bins)
ax.set_xlabel('T')
ax.set_ylabel('Papers')
ax.set_title(r'Rough Estimate', size = 11)
ax.axvline(494, color = 'orange',  linestyle='dashed')

#Primary Rough Estimate
ax = plt.subplot(3, 2, 4)
ax.hist(google_scholar_df['"Rough Estimate" of Time Periods (Primary Sample)'], num_bins)
ax.set_xlabel('T')
ax.set_ylabel('Papers')
ax.set_title(r'Primary Rough Estimate', size = 11)
ax.axvline(494, color = 'orange',  linestyle='dashed')

#Best Available Estimate
ax = plt.subplot(3, 2, 5)
ax.hist(google_scholar_df['Best Available Estimate'], num_bins)
ax.set_xlabel('T')
ax.set_ylabel('Papers')
ax.set_title(r'Best Available Measure', size = 11)
ax.axvline(494, color = 'orange',  linestyle='dashed')

#Remove extra plot
plt.subplot(3,2,6).remove()

#Create output and 508 directories if they don't exist
if not os.path.exists('output'):
    os.makedirs('output') 
if not os.path.exists('508'):
    os.makedirs('508')

#Export figure as pdf
fig.set_size_inches(8, 11)
fig.tight_layout()
fig.subplots_adjust(top=0.93)
plt.savefig("output/fig_meta-study.pdf")


#Create 508 of histograms
#Min
min_data = list(plt.hist(google_scholar_df['Minimum Number of Time Periods'], num_bins))
min_508 = {'Min Bin Lower Bound': min_data[1][0:len(min_data[1]) -1], 'Min Bin Upper Bound': min_data[1][1:len(min_data[1])], 'Min Bin Count': min_data[0]}
min_df = pd.DataFrame(min_508, columns = ['Min Bin Lower Bound', 'Min Bin Upper Bound', 'Min Bin Count'])
#Max
max_data = list(plt.hist(google_scholar_df['Maximum Number of Time Periods'], num_bins))
max_508 = {'Max Bin Lower Bound': max_data[1][0:len(max_data[1]) -1], 'Max Bin Upper Bound': max_data[1][1:len(max_data[1])], 'Max Bin Count': max_data[0]}
max_df = pd.DataFrame(max_508, columns = ['Max Bin Lower Bound', 'Max Bin Upper Bound', 'Max Bin Count'])
#Rough Estimate
rough_data = list(plt.hist(google_scholar_df['"Rough Estimate" of Time Periods'], num_bins))
rough_508 = {'Rough Estimate Bin Lower Bound': rough_data[1][0:len(rough_data[1]) -1], 'Rough Estimate Bin Upper Bound': rough_data[1][1:len(rough_data[1])], 'Rough Estimate Bin Count': rough_data[0]}
rough_df = pd.DataFrame(rough_508, columns = ['Rough Estimate Bin Lower Bound', 'Rough Estimate Bin Upper Bound', 'Rough Estimate Bin Count'])
#Primary Rough Estimate
primary_data = list(plt.hist(google_scholar_df['"Rough Estimate" of Time Periods (Primary Sample)'], num_bins))
primary_508 = {'Primary Rough Estimate Bin Lower Bound': primary_data[1][0:len(primary_data[1]) -1], 'Primary Rough Estimate Bin Upper Bound': primary_data[1][1:len(primary_data[1])], 'Primary Rough Estimate Bin Count': primary_data[0]}
primary_df = pd.DataFrame(primary_508, columns = ['Primary Rough Estimate Bin Lower Bound', 'Primary Rough Estimate Bin Upper Bound', 'Primary Rough Estimate Bin Count'])
#Best Available Measure
best_data = list(plt.hist(google_scholar_df['Best Available Estimate'], num_bins))
best_508 = {'Best Available Measure Bin Lower Bound': best_data[1][0:len(best_data[1]) -1], 'Best Available Measure Bin Upper Bound': best_data[1][1:len(best_data[1])], 'Best Available Measure Bin Count': best_data[0]}
best_df = pd.DataFrame(best_508, columns = ['Best Available Measure Bin Lower Bound', 'Best Available Measure Bin Upper Bound', 'Best Available Measure Bin Count'])
#Join 508 dataframes
df_508 = pd.concat([min_df, max_df, rough_df, primary_df, best_df], axis=1)
df_508.to_csv(r'508/508_meta-study.csv', index = False)

#Create separate plot for Best Available Estimate histogram
fig, ba = plt.subplots()
ba.hist(google_scholar_df['Best Available Estimate'], num_bins)
ba.set_xlabel('T')
ba.set_ylabel('Papers')
ba.set_title(r' ', size = 11)
ba.axvline(494,ymax = .9,  color = 'orange',  linestyle='dashed')
ba.annotate(r"Jordà (2005)",  ha='center',  xy =(494,17.5), size = 9)

#Export Best Available Estimate figure as pdf
fig.set_size_inches(4, 11/3)
fig.tight_layout()
plt.savefig("output/fig_meta-study_best.pdf")

#Create 508 for Best Available Estimate histogram
best_df.to_csv(r'508/508_meta-study_best.csv', index = False)
