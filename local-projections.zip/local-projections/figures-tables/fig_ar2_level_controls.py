from figures import plt, colors
import os
import pandas as pd
import numpy as np
from fig_function import hj_plot, hj_508, nohj_panel, hj_508_panel

#Plot AR(2) level ouput (without HJ approximation)
hj_plot('ar2_level_controls','ar2_level_controls_rho99', T = [50, 100, 500], no_hj = True, ymax = 1.6, ar2 = True)
nohj_panel(['ar2_level_controls'], 'ar2_level_controls', T = [50, 100, 500], rho = [.99, .95, .9], no_hj_sub_plot_title_font = 20, figx = 15.5, figy = 20, ymax = 1.6, no_hj_sub_plot_font = 12, ar2 = [True])
#Create 508 
hj_508('ar2_level_controls', 'ar2_level_controls_rho99', T = [50, 100, 500], no_hj = True, ar2 = True)
hj_508_panel('ar2_level_controls', 'ar2_level_controls', T = [50, 100, 500], rho = [.99, .95, .9], no_hj = True, ar2 = True)
