from figures import plt, colors
import os
import pandas as pd
import numpy as np
from fig_function import hj_plot, hj_508, hj_plot_panel, hj_508_panel

#Appendix Version: Plot AR(1) level output with controls 
#Note: If you have just created new monte carlo output and want to see the results (without worrying about precise label placement), set new = 1
new = 0
if new == 1:
    hj_plot_panel('ar1_level_controls', T = [50,100,500], h = 10, rho = [.99, .95, .90], bootstrap = False, ymin = 0, ymax = 1.2)
else: 
    hj_plot_panel('ar1_level_controls', T = [50,100,500], adjust = [1,-1,-3,-2,3.5,-1.5,2.5,.8], h = 10, rho = [.99, .95, .90], bootstrap = False, ymin = 0, ymax = 1.2)


#Create 508
hj_508_panel('ar1_level_controls', T = [50,100, 500], h = 10, rho = [.99, .95, .90], bootstrap = False)

