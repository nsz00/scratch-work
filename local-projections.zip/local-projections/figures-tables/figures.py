import matplotlib.pyplot as plt


# some default settings
plt.style.use('seaborn-white')
plt.matplotlib.rcParams['xtick.top'] = False
plt.matplotlib.rcParams['ytick.right'] = False
plt.matplotlib.rcParams['axes.spines.right'] = False 
plt.matplotlib.rcParams['axes.spines.top'] = False
plt.matplotlib.rcParams['font.sans-serif'] = "Fira Code"
plt.matplotlib.rcParams['text.usetex'] = False
plt.matplotlib.rcParams['lines.linewidth'] = 2


colors = plt.rcParams['axes.prop_cycle'].by_key()['color']
