from figures import plt, colors
import os
import pandas as pd
import numpy as np
import math

#LP HJ Plot Function 
'''
Arguments: 
- filename  = filename of output txt file (do not include "_output.txt")
- T = array of the desired sample sizes
- adjust = an array of size 8*length(T) that adjusts line labels relative to their default position (For each sample, the first four elements control the xy-coordinates for the exact theta's arrow and label, respectively. Similarly, the final four elements adjust the xy-coordinates for the HJ/bootstrap theta approximation's arrow and label, respectively.)
- h = horizon
- rho = desired value of rho 
- bootstrap = displays the bootstrap approximation instead of the HJ approximation if True
- ymin = set minimum for y-axis
- ymax = set maximum for y-axis
- label = labels lines if True
- xaxis = labels x-axis if True
- yaxis = labels y-axis if True
- sub_plot = creates a figure that is sub-plot of a greater "master" plot
- ax_plot = the name of the "master" plot if sub_plot is True
'''
def hj_plot(filename, outfilename, T = [50, 100], adjust = [0,0,0,0,0,0,0,0], h = 10, rho = .99, bootstrap = False, ymin = 0, ymax = 1.05, label = True, xaxis = True, yaxis = True, sub_plot = False, ax_plot = plt.subplots(), no_hj = False, no_hj_sub_plot_font = 16, no_hj_sub_plot_title_font = 20, ar2 = False):
    #Import output data
    sim_df = pd.read_csv('../simulations/{}_output.txt'.format(filename), header = None, delim_whitespace =True )
    if bootstrap == True:
        sim_bstrap_df = pd.read_csv('../simulations/{}_bootstrap_output.txt'.format(filename), header = None, delim_whitespace = True) 
    else:
        if no_hj == False: 
            sim_hj_df = pd.read_csv('../simulations/{}_hj_output.txt'.format(filename), header = None, delim_whitespace = True)
        
    #Set "master" plot
    if sub_plot == False:
        fig, ax = plt.subplots()
    else:
        ax = ax_plot

    #Truth
    if ar2 == False:
        truth = pd.DataFrame(data = rho**np.arange(0,h + 1))
    else:
        truth = sim_df[(sim_df.iloc[:,1] == rho)& (sim_df.iloc[:,2] < (h + 1))].iloc[0:h+1,16].reset_index(drop = True) 
    ax.plot(truth, color='black')
    if label == True:
        if no_hj == False:
            ax.annotate(r"$\mathbf{\theta}$", xy =(h+0.1,truth.values[h]), va="center")
        else: 
            if sub_plot == True:
                ax.annotate(r"True $\mathbf{\theta}$", xy =(h+0.1,truth.values[h]), size = no_hj_sub_plot_font, va="center")
            else:
                ax.annotate(r"True $\mathbf{\theta}$", xy =(h+0.1,truth.values[h]), va="center")

    #Subset data for give rho/T's and plot 
    sim_df_rho = sim_df[(sim_df.iloc[:,1] == rho)& (sim_df.iloc[:,2] < (h + 1))]
    if bootstrap == True:
        sim_bstrap_df_rho = sim_bstrap_df[(sim_bstrap_df.iloc[:,1] == rho) & (sim_bstrap_df.iloc[:,2] < (h + 1))]
    else:
        if no_hj == False: 
            sim_hj_df_rho = sim_hj_df[(sim_hj_df.iloc[:,1] == rho) & (sim_hj_df.iloc[:,2] < (h + 1))]

    #If no adjustment is specified, set adjustment equal to zero for all coordiantes 
    if (label == True) & (adjust == [0,0,0,0,0,0,0,0]):
        adjust = np.zeros(8*len(T))

    #Plot the exact theta and HJ/bootstrap approximation of theta for each sample size
    for t in range(len(T)):
        if T[t] == 50:
            color_list = ['dodgerblue', 'dodgerblue', 'mediumturquoise', 'cornflowerblue']
        if T[t] == 100:
            color_list = ['orangered', 'orangered', 'coral', 'darkorange']
        if T[t] == 500:
            color_list = ['darkgreen', 'darkgreen', 'springgreen', 'green']
        if T[t] == 200:
            color_list = ['indigo', 'indigo', 'darkviolet', 'purple']
        exact = sim_df_rho[sim_df_rho.iloc[:,0] == T[t]].iloc[:,3].reset_index(drop = True)
        if no_hj == False:
            ax.plot(exact, color=color_list[0])
        else:
            line_list = ['dashed', 'dotted', 'dashdot']
            ax.plot(exact, color=color_list[0], linestyle = line_list[t])
        if label == True:
            set_x = math.ceil(t*h/len(T) + h/(len(T)*2))
            adjust_factor = (ymax - ymin)/h
            if no_hj == False:
                ax.annotate(r"$\mathbf{E} [\hat{\theta}_{LS}]$" "\n exact, Monte Carlo", xy=(set_x + adjust[t*8 + 0], exact.values[set_x] + adjust_factor*adjust[t*8 + 1]), xytext=(set_x + adjust[t*8 + 2], exact.values[set_x] + adjust_factor*adjust[t*8 + 3] - (ymax - ymin)*.18), arrowprops=dict(facecolor=color_list[0], color = color_list[0], arrowstyle='-|>'), ha='center', va = 'center', color= color_list[0])
        if bootstrap == True:
             boot = sim_bstrap_df_rho[sim_bstrap_df_rho.iloc[:,0] == T[t]].iloc[:,3].reset_index(drop = True)
             ax.plot(boot, color = color_list[2], linestyle= 'dotted')
             if label == True:
                avg = (exact.values[h] + boot.values[h])/2
                if sub_plot == False:
                    ax.annotate(r"Bootstrap" "\n approximation", xy=(set_x + adjust[t*8 + 4], boot.values[set_x] + adjust_factor*adjust[t*8 + 5]), xytext=(set_x + adjust[t*8 + 6], boot.values[set_x] + adjust_factor*adjust[t*8 + 7] + (ymax - ymin)*.1), arrowprops=dict(facecolor=color_list[2], color = color_list[2], arrowstyle='-|>', ls = 'dotted'), ha='center', va = 'center', color= color_list[2])
                else:
                    ax.annotate(r"Bootstrap" "\n approx", xy=(set_x + adjust[t*8 + 4], boot.values[set_x] + adjust_factor*adjust[t*8 + 5]), xytext=(set_x + adjust[t*8 + 6], boot.values[set_x] + adjust_factor*adjust[t*8 + 7] + (ymax - ymin)*.1), arrowprops=dict(facecolor=color_list[2], color = color_list[2], arrowstyle='-|>', ls = 'dotted'), ha='center', va = 'center', color= color_list[2])
        else :
            if no_hj == False:
                approx = sim_hj_df_rho[sim_hj_df_rho.iloc[:,0] == T[t]].iloc[:,3].reset_index(drop = True)
                ax.plot(approx, color= color_list[1], linestyle='dashed', dashes=(5, 6))
                if label == True:
                    avg = (exact.values[h] + approx.values[h])/2
                    if sub_plot == False:
                        ax.annotate(r"$\mathbf{E} [\hat{\theta}_{BC}]$" "\n exact, Monte Carlo", xy=(set_x + adjust[t*8 + 4], approx.values[set_x] + adjust_factor*adjust[t*8 + 5]), xytext=(set_x + adjust[t*8 + 6], approx.values[set_x] + adjust_factor*adjust[t*8 + 7] + (ymax - ymin)*.1), arrowprops=dict(facecolor=color_list[1], color = color_list[1], arrowstyle='-|>', ls = 'dashed'), ha='center',va = 'center', color= color_list[1])
                    else:
                        ax.annotate(r"$\mathbf{E} [\hat{\theta}_{BC}]$" "\n exact, Monte Carlo", xy=(set_x + adjust[t*8 + 4], approx.values[set_x] + adjust_factor*adjust[t*8 + 5]), xytext=(set_x + adjust[t*8 + 6], approx.values[set_x] + adjust_factor*adjust[t*8 + 7] + (ymax - ymin)*.1), arrowprops=dict(facecolor=color_list[1], color = color_list[1], arrowstyle='-|>', ls = 'dashed'), ha='center', va = 'center',  color= color_list[1])
        if no_hj == False:
            if (label == True) & (sub_plot == False) :
                ax.annotate(r"$\mathbf{T= %s}$" % (T[t]), xy =(h+0.1,exact.values[h]-0.01), color = color_list[1], va = 'center')
                ax.annotate(r"$\mathbf{T= %s}$" % (T[t]), xy =(h+0.1,approx.values[h]-0.01), color = color_list[1], va = 'center')
        else:
            if label == True:
                if sub_plot == True:
                    ax.annotate(r"$\mathbf{E} [\hat{\theta}_{LS}]$ $T= %s$" "\n Monte Carlo" % (T[t]), xy =(h+0.1,exact.values[h]-0.01), color = color_list[1], size=no_hj_sub_plot_font, va="center")
                else:
                    ax.annotate(r"$\mathbf{E} [\hat{\theta}_{LS}]$ $T= %s$" "\n Monte Carlo" % (T[t]), xy =(h+0.1,exact.values[h]-0.01), color = color_list[1], va="center")
            if sub_plot == True:
                ax.title.set_text(r"$\rho = %s$" % (rho))
                ax.title.set_fontsize(no_hj_sub_plot_title_font)
    
    #Set limits and label lines
    ax.set_ylim(ymin, ymax)
    ax.tick_params(axis='x', which='both', bottom=xaxis, top=False, labelbottom=xaxis)
    ax.tick_params(axis='y', which='both', left=yaxis, right=False, labelleft=yaxis)

    if no_hj == True:
        if sub_plot == True:
            plt.subplots_adjust(top = .95, right=.85)
        else:
            plt.subplots_adjust(right = .85)
    #If the figure is not a subplot, create pdf; otherwise, return figure
    if sub_plot == False:
        #Create output directory if it doesn't exist
        if not os.path.exists('output'):
            os.makedirs('output') 

        #Export figure as pdf
        if bootstrap == False:
            if no_hj == False:
                plt.savefig("output/fig_{}.pdf".format(outfilename))
            else: 
                plt.savefig("output/fig_{}_nohj.pdf".format(outfilename))
        else:
            if no_hj == False:
                plt.savefig("output/fig_{}_bootstrap.pdf".format(outfilename))
            else:
                plt.savefig("output/fig_{}_bootstrap_nohj.pdf".format(outfilename))
    else:
        return ax

#LP HJ 508 Function
'''
Arguments: 
- filename  = filename of output txt file (do not include "_output.txt")
- T = array of the desired sample sizes
- h = horizon
- rho = desired value of rho 
- bootstrap = displays the bootstrap approximation instead of the HJ approximation if True
- csv = creates csv output if True; otherwise, returns dataframe
- with_horizon = adds horizon column
- with_truth = adds column of theta's true value for a given rho
'''
def hj_508(filename, outfilename, T, h = 10, rho = .99, bootstrap = False, csv = True, with_horizon = True, with_truth = True, no_hj = False, ar2 = False):

    #Import output data
    sim_df = pd.read_csv('../simulations/{}_output.txt'.format(filename), header = None, delim_whitespace =True )
    if bootstrap == True:
        sim_bstrap_df = pd.read_csv('../simulations/{}_bootstrap_output.txt'.format(filename), header = None, delim_whitespace = True) 
    else:
        if no_hj == False:
            sim_hj_df = pd.read_csv('../simulations/{}_hj_output.txt'.format(filename), header = None, delim_whitespace = True)

    #Truth
    if ar2 == False:
        truth = pd.DataFrame(data = rho**np.arange(0,h + 1))
        true = np.array(truth.loc[:,0].values.tolist())
    else:
        truth = sim_df[(sim_df.iloc[:,1] == rho)& (sim_df.iloc[:,2] < (h + 1))].iloc[0:h+1,16].reset_index(drop = True) 
        true= np.array(truth.values.tolist())
    horizon = truth.index.values
        
    #Subset data for give rho/T's and create dataframe 
    sim_df_rho = sim_df[(sim_df.iloc[:,1] == rho)& (sim_df.iloc[:,2] < (h + 1))]
    if bootstrap == True:
        sim_bstrap_df_rho = sim_bstrap_df[(sim_bstrap_df.iloc[:,1] == rho) & (sim_bstrap_df.iloc[:,2] < (h + 1))]
    else:
        if no_hj == False:
            sim_hj_df_rho = sim_hj_df[(sim_hj_df.iloc[:,1] == rho) & (sim_hj_df.iloc[:,2] < (h + 1))]        
    ax_508 = {'Horizon': horizon, 'Truth ({})'.format(rho): true}
    df_508 = pd.DataFrame(ax_508, columns = ['Horizon', 'Truth ({})'.format(rho)]) 
    for t in range(len(T)):
        exact = np.array(sim_df_rho[sim_df_rho.iloc[:,0] == T[t]].iloc[:,3].values.tolist())
        if bootstrap == True:
             boot = np.array(sim_bstrap_df_rho[sim_bstrap_df_rho.iloc[:,0] == T[t]].iloc[:,3].values.tolist())
             ax_508 = {r"Exact {} ({})".format(T[t], rho) : exact, "Bootstrap {} ({})".format(T[t], rho) : boot}
             temp_508 = pd.DataFrame(ax_508, columns = [r"Exact {} ({})".format(T[t], rho), "Bootstrap {} ({})".format(T[t], rho)])
        else :
            if no_hj == False:
                approx = np.array(sim_hj_df_rho[sim_hj_df_rho.iloc[:,0] == T[t]].iloc[:,3].values.tolist())
                ax_508 = {r"Exact {} ({})".format(T[t], rho) : exact, "Approximate {} ({})".format(T[t], rho) : approx}
                temp_508 = pd.DataFrame(ax_508, columns = [r"Exact {} ({})".format(T[t], rho), "Approximate {} ({})".format(T[t], rho)])
            else:
                ax_508 = {r"Exact {} ({})".format(T[t], rho) : exact}
                temp_508 = pd.DataFrame(ax_508, columns = [r"Exact {} ({})".format(T[t], rho)])
        df_508 = pd.concat([df_508, temp_508], axis = 1)
    
    #Remove horizon or truth columns if with_horizon or with_truth arguments are False, respectively
    if with_horizon == False:
        df_508 = df_508.drop(['Horizon'], axis = 1)
    if with_truth == False:
        df_508 = df_508.drop(['Truth ({})'.format(rho)], axis = 1)
    #Either output csv or return dataframe
    if csv == True:
        #Create 508 directory if it doesn't exist
        if not os.path.exists('508'):
            os.makedirs('508')
    
        #Export 508 data
        if bootstrap == False:
            if no_hj == False:
                df_508.to_csv("508/508_{}.csv".format(outfilename), index = False)
            else:
                df_508.to_csv("508/508_{}_nohj.csv".format(outfilename), index = False)
        else:
            if no_hj == False:
                df_508.to_csv("508/508_{}_bootstrap.csv".format(outfilename), index = False)
            else:
                df_508.to_csv("508/508_{}_bootstrap_nohj.csv".format(outfilename), index = False)
    else:
        return df_508

#LP HJ Plot Panel Function
'''
Arguments: 
- filename  = filename of output txt file (do not include "_output.txt")
- T = array of the desired sample sizes
- adjust = an array of size 8 that adjusts line labels relative to their default position for the top right subplot only (For each sample, the first four elements control the xy-coordinates for the exact theta's arrow and label, respectively. Similarly, the final four elements adjust the xy-coordinates for the HJ/bootstrap theta approximation's arrow and label, respectively.)
- h = horizon
- rho = an array of the desired value of rho 
- bootstrap = displays the bootstrap approximation instead of the HJ approximation if True
- ymin = set minimum for y-axis
- ymax = set maximum for y-axis
'''
def hj_plot_panel(filename, T, adjust = [0,0,0,0,0,0,0,0], h = 10, rho = [.99], bootstrap = False, ymin = 0, ymax = 1, no_hj = False, ar2 = False):

    index = 0
    #Create a subplot for every rho and sample size combination
    for i in range(len(rho)):
        for sample in range(len(T)):
            index += 1
            #Set "master" plot
            ax_panel = plt.subplot(len(rho), len(T), index)
            if sample == 0:
                if (i == len(rho) - 1):
                    ax_panel = hj_plot(filename, [T[sample]], rho = rho[i], label = False, xaxis =True, yaxis = True, sub_plot = True, h = h, bootstrap = bootstrap, ymin = ymin, ymax = ymax, ax_plot = ax_panel, no_hj = no_hj, ar2 = ar2)
                    ax_panel.set_xlabel(r'$T = {}$'.format(T[sample])) 
                elif (i == 0):
                    ax_panel = hj_plot(filename, [T[sample]], rho = rho[i], adjust = adjust, label = True, xaxis = False, yaxis = True, sub_plot = True, h = h, bootstrap = bootstrap, ymin = ymin, ymax = ymax, ax_plot = ax_panel, no_hj = no_hj, ar2 = ar2)
                else:
                    ax_panel = hj_plot(filename,[T[sample]], rho = rho[i], label = False, xaxis = False, yaxis = True, sub_plot = True, h = h, bootstrap = bootstrap, ymin = ymin, ymax = ymax, ax_plot = ax_panel, no_hj = no_hj, ar2 = ar2)
                ax_panel.set_ylabel(r'$\rho = {}$'.format(rho[i]))
            elif (sample != 0) & (i == len(rho) - 1):
                ax_panel = hj_plot(filename, [T[sample]], rho = rho[i], label = False, xaxis =True, yaxis = False, sub_plot = True, h = h, bootstrap = bootstrap, ymin = ymin, ymax = ymax, ax_plot = ax_panel, no_hj = no_hj, ar2 = ar2)
                ax_panel.set_xlabel(r'$T = {}$'.format(T[sample])) 
            else:
                ax_panel = hj_plot(filename, [T[sample]], rho = rho[i], label = False, xaxis = False, yaxis = False, sub_plot = True, h = h, bootstrap = bootstrap, ymin = ymin, ymax = ymax, ax_plot = ax_panel, no_hj = no_hj, ar2 = ar2)

    #Create output directory if it doesn't exist
    if not os.path.exists('output'):
        os.makedirs('output') 
    
    #Export figure as pdf
    if bootstrap == False:
        plt.savefig("output/fig_{}_panel.pdf".format(filename))
    else:
        plt.savefig("output/fig_{}_panel_bootstrap.pdf".format(filename))


#LP HJ 508 Panel Function
'''
Arguments: 
- filename  = filename of output txt file (do not include "_output.txt")
- T = array of the desired sample sizes
- h = horizon
- rho = an array of the desired values of rho
- bootstrap = displays the bootstrap approximation instead of the HJ approximation if True
'''
def hj_508_panel(filename, outfilename, T, h = 10, rho = [.99], bootstrap = False, no_hj = False, ar2 = False):
    index = 0
    #Loop through every rho and sample period combination
    for i in range(len(rho)):
        for sample in range(len(T)):
            if (i == 0) & (sample == 0):
               df_508_panel =  hj_508(filename = filename, outfilename = outfilename, T = [T[sample]], h = h,  rho = rho[i], bootstrap = bootstrap, csv = False, no_hj = no_hj, ar2 = ar2)
            elif (sample == 0):
                df_508_panel = pd.concat([df_508_panel, hj_508(filename = filename, outfilename = outfilename, T = [T[sample]], h = h,  rho = rho[i], bootstrap = bootstrap, csv = False, with_truth = True, with_horizon = False, no_hj =no_hj, ar2 = ar2)], axis = 1)
            else:
                df_508_panel = pd.concat([df_508_panel, hj_508(filename = filename, outfilename = outfilename, T = [T[sample]], h = h,  rho = rho[i], bootstrap = bootstrap, csv = False, with_truth = False, with_horizon = False, no_hj = no_hj, ar2 = ar2)], axis = 1)

    #Create 508 directory if it doesn't exist
    if not os.path.exists('508'):
        os.makedirs('508')
    
    #Export 508 data
    if bootstrap == False:
        if no_hj == False:
            df_508_panel.to_csv("508/508_{}_panel.csv".format(outfilename), index = False)
        else:
            df_508_panel.to_csv("508/508_{}_panel_nohj.csv".format(outfilename), index = False)
    else:
        if no_hj == False:
            df_508_panel.to_csv("508/508_{}_panel_bootstrap.csv".format(outfilename), index = False)
        else:
            df_508_panel.to_csv("508/508_{}_panel_bootstrap_nohj.csv".format(outfilename), index = False)

#LP No HJ Panel Function
def nohj_panel(filename, outfilename, T = [50, 100],  h = 10, rho = [.99],  ymin = 0, ymax = 1.05, no_hj_sub_plot_font = 16, no_hj_sub_plot_title_font = 20, figx = 8.5, figy = 11, labelsize = 16, ar2 = False):
    fig, ax_panel = plt.subplots(len(rho)*len(filename))
    for file in range(len(filename)):
        index = 0
        for i in range(len(rho)):
            index += 1
            ax_panel = plt.subplot(len(rho), len(filename), (file + 1) + (index - 1)*len(filename))
            if i == 0:
                ax_panel = hj_plot(filename = filename[file], outfilename = outfilename, T = T, rho = rho[i], h = h,  sub_plot = True,  ax_plot = ax_panel, no_hj = True, ymin = ymin, ymax = ymax, no_hj_sub_plot_font = no_hj_sub_plot_font, no_hj_sub_plot_title_font = no_hj_sub_plot_title_font, ar2 = ar2[file])
            else:
                ax_panel = hj_plot(filename = filename[file], outfilename = outfilename, T = T, rho = rho[i],  h = h, sub_plot = True,  ax_plot = ax_panel, no_hj = True, label = False, ymin = ymin, ymax = ymax, no_hj_sub_plot_font = no_hj_sub_plot_font, no_hj_sub_plot_title_font = no_hj_sub_plot_title_font, ar2 = ar2[file])
            for ticklabel in (ax_panel.get_xticklabels()):
                ticklabel.set_fontsize(labelsize)
            for ticklabel in (ax_panel.get_yticklabels()):
                ticklabel.set_fontsize(labelsize)
            fig.set_size_inches(figx, figy)

    #Create output directory if it doesn't exist
    if not os.path.exists('output'):
        os.makedirs('output') 
    plt.savefig("output/fig_{}_panel_nohj.pdf".format(outfilename))
