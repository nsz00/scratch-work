from figures import plt, colors
import os
import pandas as pd
import numpy as np
from fig_function import hj_plot, hj_508, nohj_panel, hj_508_panel

hj_plot('ar1_level','ar1_level_rho99', T = [50, 100, 200], no_hj = True, ymax = 1.1)
hj_plot('ar1_level_controls','ar1_level_controls_rho99', T = [50, 100, 200], no_hj = True, ymax = 1.1)
hj_plot('ar2_level','ar2_level_rho99', T = [50, 100, 200], no_hj = True, ymax = 1.6, ar2 = True)
hj_plot('ar2_level_controls','ar2_level_controls_rho99', T = [50, 100, 200], no_hj = True, ymax = 1.6, ar2 = True)
