import numpy as np
import os
from figures import plt, colors
from pandas import DataFrame

# truth
truth = 0.99**np.arange(11)

#T = 50
exact = [0.573, 0.549, 0.518, 0.495, 0.464, 0.435, 0.408, 0.379, 0.358, 0.329, 0.303]
approx = [0.576, 0.548, 0.521, 0.493, 0.465, 0.437, 0.409, 0.381, 0.353, 0.325, 0.298]
fig, ax = plt.subplots()
ax.plot(truth, color='black')
ax.plot(exact, color='skyblue')
ax.plot(approx, color='dodgerblue', linestyle='dashed', dashes=(5, 6))

#T = 100
exact = [0.636, 0.611, 0.592, 0.588, 0.565, 0.544, 0.529, 0.516, 0.497, 0.481, 0.458]
approx = [0.634, 0.616, 0.599, 0.582, 0.565, 0.547, 0.530, 0.513, 0.497, 0.480, 0.463]
ax.plot(exact, color='orange')
ax.plot(approx, color='orangered', linestyle='dashed', dashes=(5, 6))

#Set limits and label lines
ax.set_ylim(0,1.05)
ax.annotate(r"$\mathbf{E} [\hat{\beta}_{LS}]$" "\n first-order, analytic", xy=(1.455,.617), xytext=(1.455,.617 + .1), arrowprops=dict(facecolor='orangered', color = 'orangered', arrowstyle='-|>', ls = 'dashed'), ha='center', color = 'orangered')
ax.annotate(r"$\mathbf{E} [\hat{\beta}_{LS}]$" "\n exact, Monte Carlo", xy=(7.85,.51), xytext=(7.85,.51 + .1), arrowprops=dict(facecolor='orange', arrowstyle ="-|>", color = 'orange'), ha='center', color ='orange' )
ax.annotate(r"$\mathbf{E} [\hat{\beta}_{LS}]$" "\n exact, Monte Carlo", xy=(3.14,.485), xytext=(3.14,(.485 - .19)), arrowprops=dict(facecolor='skyblue', arrowstyle = "-|>", color = 'skyblue'), ha='center', color = 'skyblue')
ax.annotate(r"$\mathbf{E} [\hat{\beta}_{LS}]$" "\n first-order, analytic", xy=(8.7,.325), xytext=(8.7,(.325 - .19)), arrowprops=dict(facecolor='dodgerblue', arrowstyle = '-|>', ls = 'dashed', color = 'dodgerblue'), ha='center', color = 'dodgerblue')
ax.annotate(r"$\mathbf{T=50}$", xy =(10.1,.29), color = 'dodgerblue')
ax.annotate(r"$\mathbf{T=100}$", xy =(10.1,.45), color = 'orangered')
ax.annotate(r"$\mathbf{\beta}$", xy =(10.1,truth[10]))

#Create output and 508 directories if they don't exist
if not os.path.exists('output'):
    os.makedirs('output') 
if not os.path.exists('508'):
    os.makedirs('508')

#Export figure as pdf
plt.savefig("output/fig_ar1_population.pdf")

#Create 508 data
ax_508 = {'Horizon': np.arange(11),
        'Truth': truth,
        'Exact_50':[0.573, 0.549, 0.518, 0.495, 0.464, 0.435, 0.408, 0.379, 0.358, 0.329, 0.303],
        'Approx_50':  [0.576, 0.548, 0.521, 0.493, 0.465, 0.437, 0.409, 0.381, 0.353, 0.325, 0.298], 
        'Exact_100': [0.636, 0.611, 0.592, 0.588, 0.565, 0.544, 0.529, 0.516, 0.497, 0.481, 0.458] ,
        'Approx_100': [0.634, 0.616, 0.599, 0.582, 0.565, 0.547, 0.530, 0.513, 0.497, 0.480, 0.463]
        }
df_508 = DataFrame(ax_508, columns = ['Horizon', 'Truth', 'Approx_50', 'Exact_50', 'Approx_100', 'Exact_100'])
df_508.to_csv(r'508/fig_ar1_population.csv', index = False)
