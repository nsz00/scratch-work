from figures import plt, colors
import os
import pandas as pd
import numpy as np
from fig_function import hj_plot, hj_508, nohj_panel, hj_508_panel

#Plot AR(1) level output with controls as well as bootstrap approximation
hj_plot('ar1_level_controls','ar1_level_controls_rho99', T = [50, 100], adjust = [0,0,0,0,0,0,0,.4,0,0,0,-1.5,0,0,0,.75], ymax = 1.2)
hj_plot('ar1_level_controls','ar1_level_controls_rho95', T = [50, 100], adjust = [0,0,0,0,0,0,0,.4,0,0,0,-1.5,0,0,0,.75], ymax = 1.2,rho=0.95)
hj_plot('ar1_level_controls','ar1_level_controls_rho90', T = [50, 100], adjust = [0,0,0,0,0,0,0,.4,0,0,0,-0.75,0,0,0,.75], ymax = 1.2,rho=0.90)
#hj_plot('ar1_level_controls','ar1_level_controls_rho99', T = [50, 100], adjust = [0,0,0,0,0,0,0,.5,0,0,0,-1.5,0,0,0,0], ymax = 1.2, bootstrap = True)

#Create 508
hj_508('ar1_level_controls','ar1_level_controls_rho99', T = [50, 100])
hj_508('ar1_level_controls','ar1_level_controls_rho95', T = [50, 100],rho=0.95)
hj_508('ar1_level_controls','ar1_level_controls_rho90', T = [50, 100],rho=0.90)
#hj_508('ar1_level_controls','ar1_level_controls_rho99', T = [50, 100], bootstrap = True)


#Plot AR(1) level ouput (without HJ approximation)
hj_plot('ar1_level_controls','ar1_level_controls_rho99', T = [50, 100, 200], no_hj = True)
nohj_panel('ar1_level_controls', 'ar1_level_controls', T = [50, 100, 200], rho = [.99, .95, .9], no_hj_sub_plot_font = 16, no_hj_sub_plot_title_font = 20, figx = 15.5, figy = 20)
#Create 508 
hj_508('ar1_level_controls', 'ar1_level_controls_rho99', T = [50, 100, 200], no_hj = True)
hj_508_panel('ar1_level_controls', 'ar1_level_controls', T = [50, 100, 200], rho = [.99, .95, .9], no_hj = True)
