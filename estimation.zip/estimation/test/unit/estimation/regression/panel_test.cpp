#define BOOST_TEST_MODULE PanelTest
#define BOOST_TEST_DYN_LINK
#include <boost/test/unit_test.hpp>

#include <Eigen/Dense>
#include <estimation/regression>


BOOST_AUTO_TEST_CASE( panel_test, * boost::unit_test::tolerance(.0001) )
{
  int T {20};
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> x(T,1);
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> y(T,1);
  Eigen::Matrix<int,Eigen::Dynamic,Eigen::Dynamic> groups(T,2);
  for (int i=0;i<T;i++) {
    x(i,0) = (double) i;
    y(i,0) = (double) (i*i);
    if (i < T/2) {
      groups(i,0) = 1;
    } else {
      groups(i,0) = 2;
    }
    if (i < T/4) {
      groups(i,1) = 1;
    } else {
      groups(i,1) = 2;
    }
  }


  estimation::regression::panel model(y,x,groups);

  BOOST_TEST( model.beta[0] == 25.0976);

  

}

