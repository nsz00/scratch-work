#define BOOST_TEST_MODULE SurTest
#define BOOST_TEST_DYN_LINK
#include <boost/test/unit_test.hpp>

#include <Eigen/Dense>
#include <estimation/regression>
#include <estimation/src/regression/sur.hpp>

/*R Test Code:
library(vars)
library(systemfit)
q = c(0, 1, 2, 3, 4, 5, 6, 7, 8, 9)
y = matrix(data = c(q, q*q*q*q*q), nrow = 10, ncol = 2)
x = matrix(data = c(q*q, q*q*q, q*q*q*q, q*q*q*q*q*q), nrow= 10, ncol = 4)
eqSupply <- y[,1] ~ x[,1] + x[,2] + x[,3] + x[,4] 
eqDemand <- y[,2] ~ x[,1] + x[,2] + x[,3] + x[,4] 
eqSystem <- list( demand = eqDemand, supply = eqSupply ) 
fitols <- systemfit( eqSystem ) 
coef_matrix <- matrix(c(fitols$coefficients[6], fitols$coefficients[7], fitols$coefficients[8], fitols$coefficients[9], fitols$coefficients[10], fitols$coefficients[1], fitols$coefficients[2], fitols$coefficients[3], fitols$coefficients[4], fitols$coefficients[5]), nrow = 5, ncol = 2)
NeweyWest(fitols, lag = 0, prewhite = FALSE)
NeweyWest(fitols, lag = 1, prewhite = FALSE)
*/

BOOST_AUTO_TEST_CASE(sur_test, * boost::unit_test::tolerance(.0001) )
{
  int T {10};

  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> x_matrix(T,4);
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> y_matrix(T,2);
  for (int i=0;i<T;i++) {
    y_matrix(i,0) = (double) i;
    x_matrix(i,0) = (double) (i*i);
    x_matrix(i,1) = (double) (i*i*i);
    x_matrix(i,2) = (double) (i*i*i*i);
    y_matrix(i,1) = (double) (i*i*i*i*i);
    x_matrix(i,3) = (double) (i*i*i*i*i*i);
  }
  estimation::regression::sur sur_model(y_matrix,x_matrix,true);
  Eigen::Matrix<double,5,2> model_beta(5,2);
  model_beta << .2316729,-14.59340279, .6932833, 49.20926555, -.1692449, -35.16996934, .01474080, 9.08296228, -.00003904526, 0.03975493;
  BOOST_TEST(sur_model.beta(0,0) == model_beta(0,0));
  BOOST_TEST(sur_model.beta(1,0) == model_beta(1,0));
  BOOST_TEST(sur_model.beta(2,0) == model_beta(2,0));
  BOOST_TEST(sur_model.beta(3,0) == model_beta(3,0));
  BOOST_TEST(sur_model.beta(4,0) == model_beta(4,0));
  BOOST_TEST(sur_model.beta(0,1) == model_beta(0,1));
  BOOST_TEST(sur_model.beta(1,1) == model_beta(1,1));
  BOOST_TEST(sur_model.beta(2,1) == model_beta(2,1));
  BOOST_TEST(sur_model.beta(3,1) == model_beta(3,1));
  BOOST_TEST(sur_model.beta(4,1) == model_beta(4,1));

//Test hac(0) function: at the momement, we do not check the off-diagonals of the variance-covariance matrix because R produces the incorrect output for them. At a later date, we should add an off-diagonal test.  
  Eigen::Matrix<double, 5,5> model_covarmx1(5,5);
  model_covarmx1 << .03129976, -.01278615, .004211768, -.0004117978, .000001197822, -.01278615, .006953130, -.002444441, .0002500464, -.0000007704116, .004211768, -.00244444, .0008746206, -.00009064066, .0000002842175,  -.0004117978, .0002500464, -.00009064066, .000009487442, -.00000003016109, .000001197822, -.0000007704116, .0000002842175,  -.00000003016109, .00000000009775819;
  Eigen::Matrix<double, 5,5> model_covarmx2(5,5);
  model_covarmx2 << 103.218385044, -47.803562517, 16.396281375, -1.6556858317,.005042273, -47.803562517, 45.970859356, -17.869365876, 1.9564000769, -.006559074, 16.396281375, -17.869365876,  7.143132077, -0.7978070790,.002744241, -1.655685832, 1.956499977, -0.797807079, 0.0904312958, -.0003171953, .005042273, -.006559074, .002744241, -.0003171953, .000001142217;
  Eigen::Matrix<double, 10,10> sur_covar0(10,10);
  sur_covar0 = sur_model.hac(0);
  for (int i=0;i<5;i++) {
    for(int j=0;j<5;j++){
      BOOST_TEST(sur_covar0(i,j) == model_covarmx1(i,j));
      BOOST_TEST(sur_covar0(i+5,j+5) == model_covarmx2(i,j));
    }
  }

//Test hac(1) function: At the momement, we do not check the off-diagonals of the variance-covariance matrix because R produces the incorrect output for them. At a later date, we should add an off-diagonal test.
  Eigen::Matrix<double, 5,5> model1_covarmx1(5,5);
  model1_covarmx1 << 0.0182775576967764, -0.0070539592943958, 0.00228902569712171, -0.000221393737152518, .000000634723845880667, -0.00705395929439504, 0.00485307716234575, -0.00176786308550853, 0.000184659071102793, -.000000581988173051829, 0.00228902569712129, -0.00176786308550853, 0.000659264004332291, -.0000699847294962956, .000000225187343324238, -0.000221393737152452, 0.000184659071102765, -.000069984729496283, .00000751514372756526, -.0000000245514333854001, .000000634723845879434, -.000000581988173050482, .000000225187343323689, -.0000000245514333853434, .0000000000818859960749248;
  Eigen::Matrix<double, 5,5> model1_covarmx2(5,5);
  model1_covarmx2 << 79.567858153218, -34.1262608159785, 11.4952994665351, -1.14467847881819, 0.00341520552035755, -34.1262608159267, 41.5107568665226, -16.3515703275892, 1.79447419236745, -0.0059925211473354, 11.4952994665069, -16.3515703275822, 6.62604340442315, -0.741447519918, 0.00253825350939183, -1.14467847881517, 1.79447419236707, -0.741447519918164, 0.0841340831124141, -0.000293418611245359, 0.00341520552035344, -0.00599252114734215, 0.00253825350939569, -0.000293418611245729, .00000104967636563883;
Eigen::Matrix<double, 10,10> sur_covar1(10,10);
  sur_covar1 = sur_model.hac(1);
  for (int i=0;i<5;i++) {
    for(int j=0;j<5;j++){
      BOOST_TEST(sur_covar1(i,j) == model1_covarmx1(i,j));
      BOOST_TEST(sur_covar1(i+5,j+5) == model1_covarmx2(i,j));
    }
  }

 }




