#define BOOST_TEST_MODULE VarTest
#define BOOST_TEST_DYN_LINK
#include <boost/test/unit_test.hpp>
#include <Eigen/Dense>
#include <estimation/regression>
#include <estimation/src/regression/var.hpp>
#include <cmath>
#include <iostream>
#include <fstream>
#include <vector>
#include <iterator>
#include <string>
#include <algorithm>
#include <boost/algorithm/string.hpp>
#include <stdlib.h>

/*R Test Code:
library(vars)
q = c(0, 1, 2, 3, 4, 5, 6, 7, 8, 9)
y = matrix(data = c(q, q*q, q*q*q), nrow = 10, ncol = 3)
var_test <- VAR(y,1)
result1 <- matrix(var_test$varresult$y1$coefficients)
result2 <- matrix(var_test$varresult$y2$coefficients)
result3 <- matrix(var_test$varresult$y3$coefficients)
result <- cbind(result1, result2, result3)
result <- rbind(result[4,], result[1:3,])
print(result)
*/

/** CSV importer.
 */
class csv_import
{
  /** CSV file name.
   */
  std::string file_name;
  /** CSV delimiter
   */
  std::string delimiter;
 
public:
  /** Constructor for csv importer.
   *
   * \param filename csv filename
   * \param delim delimiter used to separate data
   */
	csv_import(std::string filename, std::string delim = ",") :
			file_name(filename), delimiter(delim)
	{ }
	std::vector<std::vector<std::string> > get_data();
};

  /** Imports and returns csv data.
   */ 
std::vector<std::vector<std::string> > csv_import::get_data()
{
	std::ifstream file(file_name);
 
	std::vector<std::vector<std::string> > data_vec;
 
	std::string line = "";
	while (getline(file, line))
	{
		std::vector<std::string> vec;
		boost::algorithm::split(vec, line, boost::is_any_of(delimiter));
		data_vec.push_back(vec);
	}
	file.close();
 
	return data_vec;
}

BOOST_AUTO_TEST_CASE(var_test, * boost::unit_test::tolerance(.001) )
{
  int T{10};
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> data(T,3);
  for (int j=0;j<T;j++) {
     data(j,0) = j;
     data(j,1) = j*j;
     data(j,2) = j*j*j;
  } 
  estimation::regression::var model(data,1,true);
  Eigen::Matrix<double, 4, 3> var1_beta(4,3);
  var1_beta << 1, 1, 1, 1, 2, 3, -7.337207*pow(10,-17), 1, 3, 5.626905*pow(10,-18), -1.713807*pow(10,-16), 1;
  std::cout<<model.beta(1,0)<<std::endl;
  BOOST_TEST(model.beta(0,0) = var1_beta(0,0));
  BOOST_TEST(model.beta(1,0) = var1_beta(1,0));
  BOOST_TEST(model.beta(2,0) = var1_beta(2,0));
  BOOST_TEST(model.beta(3,0) = var1_beta(3,0));
  BOOST_TEST(model.beta(0,1) = var1_beta(0,1));
  BOOST_TEST(model.beta(1,1) = var1_beta(1,1));
  BOOST_TEST(model.beta(2,1) = var1_beta(2,1));
  BOOST_TEST(model.beta(3,1) = var1_beta(3,1));
  BOOST_TEST(model.beta(0,2) = var1_beta(0,2));
  BOOST_TEST(model.beta(1,2) = var1_beta(1,2));
  BOOST_TEST(model.beta(2,2) = var1_beta(2,2));
  BOOST_TEST(model.beta(3,2) = var1_beta(3,2));

  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> joe_data(188,3); 
  int i = 0;
  int j = 0;
  csv_import reader("examples/regression/sz_2008_joe_data.csv");
  std::vector<std::vector<std::string> > data_vec = reader.get_data();
  for(std::vector<std::string> vec : data_vec)
    {
      for(std::string data : vec)
	{  
	  joe_data(i,j) = atof(data.c_str());
	 j = j + 1;
	}
      j = 0;
      i = i + 1;
    }

  estimation::regression::var joe_model(joe_data,2,true);
  Eigen::Matrix<double, 7, 3> joe_model_beta(7,3);
  Eigen::Matrix<double, 3, 3> joe_model_sigma(3,3);
  joe_model_beta << 0.003998,  0.003047,   0.001735, 
                    1.077397,  0.004865 ,  0.312191, 
                    0.066530,  0.646175,   0.039169,  
                    0.065720 , 0.201143,   1.049072, 
                   -0.177831,  0.063724,  -0.251872, 
                   -0.081748,  0.239567,   0.081544, 
                   -0.131975, -0.173367, -0.146306;
  for (int i=0;i<7;i++) {
    for(int j=0;j<3;j++){
      BOOST_TEST(joe_model.beta(i,j) == joe_model_beta(i,j));
    }
  }

  joe_model_sigma << 5.64922052e-05, -2.94892465e-06,  1.96485963e-05, 
                    -2.94892465e-06,  1.19025193e-04,  1.30442712e-05,
                     1.96485963e-05,  1.30442712e-05,  7.90916102e-05;
        
  // see var.org
  double l = joe_model.loglik(joe_model_beta, joe_model_sigma);
  BOOST_TEST(l == 1847.3367729988058);

}

