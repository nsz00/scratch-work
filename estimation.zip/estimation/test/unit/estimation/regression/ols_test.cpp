#define BOOST_TEST_MODULE OlsTest
#define BOOST_TEST_DYN_LINK
#include <boost/test/unit_test.hpp>

#include <Eigen/Dense>
#include <estimation/regression>
//#include <estimation/src/regression/ols.hpp>

/*R Test Code:
library(sandwich)
library(lmtest)
x <- 0:9
y <- (0:9)^2
print(summary(lm(y~x)))
#Return Newey-West variance-covariance matrix
NeweyWest(lm(y~x), lag = 0, prewhite = FALSE)
NeweyWest(lm(y~x), lag = 1, prewhite = FALSE)
#Return variance-covariance matrix with homoskedasticity
vcovHC(lm(y~x), type = "const")
*/

BOOST_AUTO_TEST_CASE(ols_test, * boost::unit_test::tolerance(.0001) )
{
  int T {10};
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> x(T,1);
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> y(T,1);
  Eigen::Matrix<int,Eigen::Dynamic,Eigen::Dynamic> g(T,1);
  for (int i=0;i<T;i++) {
    x(i,0) = (double) i;
    y(i,0) = (double) (i*i);
  }
  estimation::regression::ols model(y,x,true);

  BOOST_TEST(model.beta[0] ==-12.00000);

  Eigen::Matrix<double, 2, 2> se1(2, 2);
  se1 << 24.523636,-4.276364,-4.276364, 0.950303; 
  Eigen::Matrix<double, 2, 2> model_mx1(2,2);
  model_mx1 = model.hac(0);
  BOOST_TEST(model_mx1(0,0) == se1(0,0));
  BOOST_TEST(model_mx1(0,1) == se1(0,1));
  BOOST_TEST(model_mx1(1,0) == se1(1,0));
  BOOST_TEST(model_mx1(1,1) == se1(1,1));

  Eigen::Matrix<double, 2, 2> se2(2, 2);
  se2 << 31.680000,-5.280000,-5.280000, 1.173333; 
  Eigen::Matrix<double, 2, 2> model_mx2(2,2);
  model_mx2 = model.hac(1);
  BOOST_TEST(model_mx2(0,0) == se2(0,0));
  BOOST_TEST(model_mx2(0,1) == se2(0,1));
  BOOST_TEST(model_mx2(1,0) == se2(1,0));
  BOOST_TEST(model_mx2(1,1) == se2(1,1));


  Eigen::Matrix<double, 2, 2> cov_1(2, 2);
  cov_1 << 22.8, -3.6, -3.6, 0.8; 
  Eigen::Matrix<double, 2, 2> cov_model1(2,2);
  cov_model1 = model.cov();
  BOOST_TEST(cov_model1(0,0) == cov_1(0,0));
  BOOST_TEST(cov_model1(0,1) == cov_1(0,1));
  BOOST_TEST(cov_model1(1,0) == cov_1(1,0));
  BOOST_TEST(cov_model1(1,1) == cov_1(1,1));

}

BOOST_AUTO_TEST_CASE(ols_test_missing, * boost::unit_test::tolerance(.0001) )
{
  int T {10};
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> x(T,1);
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> y(T,1);
  Eigen::Matrix<int,Eigen::Dynamic,Eigen::Dynamic> g(T,1);
  for (int i=0;i<T;i++) {
    x(i,0) = (double) i;
    y(i,0) = (double) (i*i);
  }

  x(2,0) = nan("");
  y(3,0) = nan("");

  estimation::regression::ols model_with_nan(y,x,true);  

  BOOST_TEST(model_with_nan.beta[0] == -9.75);
  BOOST_TEST(model_with_nan.beta[1] ==  8.75);

}


BOOST_AUTO_TEST_CASE(ols_test_illconditioned, * boost::unit_test::tolerance(.0001) )
{

  Eigen::MatrixXd y = estimation::toolchain::read_csv<Eigen::MatrixXd>("test/unit/estimation/regression/ill_YY.txt");
  Eigen::MatrixXd x = estimation::toolchain::read_csv<Eigen::MatrixXd>("test/unit/estimation/regression/ill_XX.txt");
  estimation::regression::ols model(y,x,false);  

  BOOST_TEST(model.beta[0] ==  7.6497379342479075);
  BOOST_TEST(model.beta[9] ==  0.0008083767671043709);

}


BOOST_AUTO_TEST_CASE(ols_test_EWC, *boost::unit_test::tolerance(0.0001) )
{
  int T{40}, B{4};
  Eigen::MatrixXd X(T,1), Y(T,1);

  X << 1.03283736,  1.82211349, -1.04993202, -1.21601306,  0.14913592,
    -0.11629382, -1.05082616, -1.35624682,  0.39681777,  0.48673196,
    -1.78105032, -0.91440089, -0.98392356, -2.16942965, -3.25842153,
    -4.08355849, -2.10436317, -0.43126296, -0.49425933, -0.79757085,
    -1.41106031, -1.84769208, -2.10261831, -1.07923111, -2.14563939,
    -2.69934541, -3.83783739, -4.13146156, -4.24737941, -3.02605478,
    -3.12601592, -3.22069287, -2.52768571, -3.5527211 , -4.61564498,
    -3.25191927, -3.36658993, -3.21544088, -4.46128914, -5.381812;

  Y << -1.78105032, -0.91440089, -0.98392356, -2.16942965, -3.25842153,
    -4.08355849, -2.10436317, -0.43126296, -0.49425933, -0.79757085,
    -1.41106031, -1.84769208, -2.10261831, -1.07923111, -2.14563939,
    -2.69934541, -3.83783739, -4.13146156, -4.24737941, -3.02605478,
    -3.12601592, -3.22069287, -2.52768571, -3.5527211 , -4.61564498,
    -3.25191927, -3.36658993, -3.21544088, -4.46128914, -5.381812  ,
    -4.46119412, -4.82591235, -4.23002843, -4.34043191, -3.77035808,
    -1.7917805 ,  0.3593168 ,  1.73240004,  2.10216   ,  0.51502928;

  estimation::regression::ols model(Y,X);

  Eigen::Matrix<double, 2, 2> truth(2, 2), code(2,2);
  truth << 0.43607007, 0.20665071, 0.20665071, 0.20556561;
  code = model.ewc(B);   

  BOOST_TEST(code(0,0) ==  truth(0,0));
  BOOST_TEST(code(0,1) ==  truth(0,1));
  BOOST_TEST(code(1,1) ==  truth(1,1));


}
