#ifndef ESTIMATION_ESTIMATION_HPP
#define ESTIMATION_ESTIMATION_HPP
#include <estimation/bootstrap>
#include <estimation/toolchain>
#include <estimation/regression>
#include <estimation/impulse_response>
#endif

