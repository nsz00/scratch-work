#ifndef ESTIMATION_IMPULSE_RESPONSE_IRF_HPP
#define ESTIMATION_IMPULSE_RESPONSE_IRF_HPP
#include <Eigen/Dense>
#include <Eigen/Sparse>
namespace estimation {
namespace impulse_response {
/** Impulse Response.
 */
class irf {
private:
  int p;
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> var_data;
  int row;
  int col;
public:
  /** VAR(p) model.
   */
  estimation::regression::var varmodel;
  /** Contemporaneous correlations matrix.
   */
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> a_0;
  /** Structural residual series.
   */
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> e;
  /** Shock
   */
  Eigen::Matrix<double,Eigen::Dynamic,1> shock;

  irf() { }
  /** Constructor for impulse response.
   *
   * \param data data input
   * \param lag  number of lags
   * \param shock_data vector containing shock
   */
  irf(const Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic>& data, int lag, const Eigen::Matrix<double,Eigen::Dynamic,1>& shock_data){

    p = lag;
    var_data = data; 
    row = var_data.rows();
    col = var_data.cols();
    shock = shock_data;

    //Estimate VAR(p)
    estimation::regression::var var_mod(var_data, p, true);
    varmodel = var_mod;

    //Identify the contemporaneous correlations matrix by taking the Cholesky decomposition of the variance-covariance residual matrix
    int a_0_T = varmodel.eps.cols();
    Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> sigma_u(a_0_T, a_0_T);
    sigma_u = varmodel.eps.transpose()*varmodel.eps;
    Eigen::LLT<Eigen::MatrixXd> lltOfsig_u(sigma_u);
    Eigen::MatrixXd L = lltOfsig_u.matrixL();
/*
    Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> I_chol(a_0_T, a_0_T);
    I_chol.setIdentity();
    for(int w = 0; w < L.cols(); w++){
      I_chol(w,w) = L(w,w);
    }*
    a_0 = L.inverse()*I_chol;
*/
    a_0 = L;
    
    //Calculate the structural residual series
    Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> e(varmodel.eps.rows(), a_0_T);
    e = varmodel.eps*a_0;
 
  }

  /** Computes impulse response for VAR(p).
   *
   * \param h horizon
   *
   */
    Eigen::Matrix<double, Eigen::Dynamic,Eigen::Dynamic> irf_var(int h) {
      Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> yf(h + p, col);
      Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> fy(h + p, col);
      yf.setZero();
      fy.setZero();
      fy.row(p) = a_0.col(3);
      yf.row(p) = fy.row(p);
    
      Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> temp_beta(varmodel.beta.rows() - 1, varmodel.beta.cols());
      temp_beta = varmodel.beta.block(1,0, varmodel.beta.rows() - 1, varmodel.beta.cols());
      
      Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> col_vec(p*col, 1); 
      col_vec.setZero();
      Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> yf_block_reverse(p,col);
      
      int count = 1;
      while(count < h){
	yf_block_reverse = yf.block(count, 0, p, col).colwise().reverse();
	for(int w = 0; w < p; w++){ 
	  for(int k = 0; k < col; k++){ 
	    col_vec((w*col) + k, 0) = yf_block_reverse(w,k); 
	  }
	} 
	fy.row(p + count) = col_vec.transpose() * temp_beta;
	yf.row(p + count) = fy.row(p + count);
	count = count + 1; 
      }

      return yf.block(p, 0, yf.rows() - p , col);
    }

  /** Computes impulse response for local projections.
   *
   * \param h horizon
   * \param shock_adjust impulse response shock
   */
    Eigen::Matrix<double, Eigen::Dynamic,Eigen::Dynamic> irf_lp(int h, Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> shock_adjust) {
      Eigen::Matrix<double, Eigen::Dynamic, Eigen::Dynamic> w;
      w = shock_adjust;
      //First row of Var(12) impulse response
      Eigen::Matrix<double, Eigen::Dynamic, Eigen::Dynamic> data_linear;
      data_linear = var_data.block(p, 0, row - p, col);
      Eigen::Matrix<double, Eigen::Dynamic, Eigen::Dynamic> ones(row - p, 1);
      ones.setOnes();
      Eigen::Matrix<double, Eigen::Dynamic, Eigen::Dynamic> x_1(row - p, col*p);
      x_1 = estimation::toolchain::x_build(var_data, p);
      Eigen::Matrix<double, Eigen::Dynamic,Eigen::Dynamic> x(row - p, (col*p) + 1);
      x.block(0,0,x.rows(),1) = ones;
      x.block(0,1,x.rows(), x.cols() - 1) = x_1;

      int vars = col;
      Eigen::Matrix<double, Eigen::Dynamic,Eigen::Dynamic> yf_lp(h+1, vars);
      yf_lp.setZero();
      yf_lp.row(0) = w;

      Eigen::Matrix<double, Eigen::Dynamic,Eigen::Dynamic> yy(data_linear.rows(), data_linear.cols());
      Eigen::Matrix<double, Eigen::Dynamic,Eigen::Dynamic> xx(x.rows(), x.cols()); 
      Eigen::Matrix<double, Eigen::Dynamic,Eigen::Dynamic> gamx((vars*p)+ 1,vars);

      int j = 0;
      while(j < h){
	yy.resize(data_linear.rows() - j, data_linear.cols());
	yy = data_linear.block(j,0, data_linear.rows() - j, data_linear.cols());
	xx.resize(x.rows() - j, x.cols());
	xx = x.block(0, 0, x.rows() - j, x.cols());
	gamx = (xx.transpose()*xx).inverse()*(xx.transpose()*yy);
	yf_lp.row(j+1) = w*gamx.block(1,0,vars, gamx.cols());
	j = j + 1;
      }
      return yf_lp.block(1, 0, h , yf_lp.cols());
    }
};
}
}
#endif
