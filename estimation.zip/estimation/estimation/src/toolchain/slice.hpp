#ifndef ESTIMATION_TOOLCHAIN_SLICE_HPP
#define ESTIMATION_TOOLCHAIN_SLICE_HPP
#include <Eigen/Dense>
#include <vector>

namespace estimation {
  namespace toolchain {

    template <typename T, typename T_1> 
    VectorXd slice(const T& full_vector, const T_1& to_select)
    {

      int n_subset = to_select.size();
 
      VectorXd sliced;
      sliced.resize(n_subset);
      for (int i = 0; i < n_subset; i++) {
        sliced[i] = full_vector[to_select[i]];
      }
 
      return sliced;
    }

    template <typename T, typename T_1> 
    MatrixXd slice_matrix(const T& full_matrix, const T_1& to_select)
    {

      int n_subset = to_select.size();
      
      MatrixXd sliced;
      sliced.resize(n_subset,full_matrix.cols());
      for (int i = 0; i < n_subset; i++) {
        sliced.row(i) = full_matrix.row(to_select[i]);
      }
 
      return sliced;
    }
    // template <typename T, typename T_1> 
    // T slice_bool(const T& full_vector, const T_1& to_select)
    // {

    //   int n_subset = to_select.size();
 
    //   T sliced;
    //   sliced.resize(n_subset);
    //   for (int i = 0; i < n_subset; i++) {
    //     sliced[i] = full_vector[to_select[i]];
    //   }
 
    //   return sliced;
    // }



    // template <typename T> 
    // Eigen::DenseBase<T> slice(const Eigen::DenseBase<T>& full_vector, std::vector<bool>& to_select)
    // {
    //   assert(full_vector.size()==to_select.size());
    //   int n_subset = (Map<Array<bool,Dynamic,1>>(to_select.data())).count();
    //   std::vector<int> to_select_int;
 
    //   for (int i = 0; i < full_vector.size(); i++) {
    //     if (to_select[i]) to_select.push_back(i);
    //   }
    

    //   auto actually_sliced = slice(full_vector, to_select);
    //   return actually_sliced;
    // }


 
  }
}

#endif
// template <typename T> 
// Eigen::Matrix<T, Eigen::Dynamic, Eigen::Dynamic> 
// slice_matrix(const Eigen::Matrix<T, Eigen::Dynamic, Eigen::Dynamic>& full_matrix, 
//                   const Eigen::Matrix<bool, Eigen::Dynamic, 1>& to_subset)
// {
 
//  int j = 0;
//  int n_subset = to_subset.count();
 
//  Eigen::Matrix<T, Eigen::Dynamic, Eigen::Dynamic> subset_matrix(n_subset, full_matrix.cols());
 
//   for (int i = 0; i < full_matrix.rows(); i++) {
//     if (to_subset(i)) {
//       subset_matrix.row(j++) = full_matrix.row(i);
//     }
//   }
 
//   return subset_matrix;
// }
 

