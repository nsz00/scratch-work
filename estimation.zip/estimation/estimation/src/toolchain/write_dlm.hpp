#ifndef ESTIMATION_TOOLCHAIN_WRITE_DLM_HPP
#define ESTIMATION_TOOLCHAIN_WRITE_DLM_HPP

#include <iostream>
#include <fstream>
#include <boost/tokenizer.hpp>

#include <Eigen/Dense>

namespace estimation {
namespace toolchain {
using namespace Eigen;
template<typename M>
void write_dlm (const std::string & path, M x, const std::string & dlm = " ") {
  std::ofstream file(path);
  const static IOFormat CSVFormat(StreamPrecision, DontAlignCols, dlm, "\n");
  file << x.matrix().format(CSVFormat);
}
}
}
#endif
