#ifndef ESTIMATION_TOOLCHAIN_COV_HPP
#define ESTIMATION_TOOLCHAIN_COV_HPP

namespace estimation {
namespace toolchain {
/** Covariance between two vectors.
 * \param v1 an Eigen vector.
 * \param v2 an Eigen vector.
 */
  double cov(const Eigen::Matrix<double,Eigen::Dynamic,1>& v1, const Eigen::Matrix<double,Eigen::Dynamic,1>& v2) {
    double m1 = v1.mean();
    double m2 = v2.mean();
    return ((v1 - Eigen::VectorXd::Ones(v1.size())*m1).transpose() * (v2 - Eigen::VectorXd::Ones(v2.size())*m2))(0,0);
  }
}
}
#endif
