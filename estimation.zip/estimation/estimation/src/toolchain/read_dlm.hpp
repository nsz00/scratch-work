#ifndef ESTIMATION_TOOLCHAIN_READ_DLM_HPP
#define ESTIMATION_TOOLCHAIN_READ_DLM_HPP

#include <iostream>
#include <fstream>
#include <boost/tokenizer.hpp>

#include <Eigen/Dense>

namespace estimation {
namespace toolchain {

using namespace Eigen;
template<typename M>
/** Function to read in delimited file
 * 
 * \param path filepath
 * \param sep delimiter
 * \param skiprows number of rows to skip before importing 
 */
M read_dlm (const std::string & path, const char sep = ' ', int skiprows = 0) {
  std::ifstream indata;
  indata.open(path);
  std::string line;
  std::vector<double> values;
  uint rows = 0;
  while (std::getline(indata, line)) {
    std::stringstream lineStream(line);
    if (rows >= skiprows) {
      std::string cell;
      while (std::getline(lineStream, cell, sep)) {
        if (cell.empty() || cell=="\r") cell="nan";
        values.push_back(std::stod(cell));
      }
    }
    ++rows;
  }
  return Map<const Matrix<typename M::Scalar, M::RowsAtCompileTime, M::ColsAtCompileTime, RowMajor>>(values.data(), rows-skiprows, values.size()/(rows-skiprows));
}

template<typename M>
M read_csv (const std::string & path, const char sep = ' ', int skiprows = 0) {
  std::ifstream indata;
  indata.open(path);
  std::string line;
  std::vector<double> values;
  uint rows = 0;
  while (std::getline(indata, line)) {
    std::stringstream lineStream(line);
    if (rows >= skiprows) {
      std::string cell;
      while (std::getline(lineStream, cell, sep)) {
        if (cell.empty() || cell=="\r") cell="nan";
        values.push_back(std::stod(cell));
      }
    }
    ++rows;
  }
  return Map<const Matrix<typename M::Scalar, M::RowsAtCompileTime, M::ColsAtCompileTime, RowMajor>>(values.data(), rows-skiprows, values.size()/(rows-skiprows));
}

}
}
#endif
