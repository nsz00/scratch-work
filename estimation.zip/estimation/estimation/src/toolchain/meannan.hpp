#ifndef ESTIMATION_TOOLCHAIN_MEANNAN_HPP
#define ESTIMATION_TOOLCHAIN_MEANNAN_HPP

namespace estimation {
namespace toolchain {
/** Calculate mean ignoring NAN's.
 * 
 * \param v data vector
 */
double meannan(const Eigen::Matrix<double,Eigen::Dynamic,1>& v) {
  if (v.array().isNaN().template cast<int>().sum() == v.size()) {
    return std::numeric_limits<double>::quiet_NaN();
  } else {
    double m = 0.0;
    int nnotnan = 0;
    for (int ii=0;ii<v.size();ii++) {
      if (std::isnan(v(ii))) {
      } else {
        nnotnan += 1;
        m = m + v(ii);
      }
    }
    return (m/((double)nnotnan));
  }
}

double varnan(const Eigen::Matrix<double,Eigen::Dynamic,1>& v) {
  if (v.array().isNaN().template cast<int>().sum() == v.size()) {
    return std::numeric_limits<double>::quiet_NaN();
  } else {
    double m = meannan(v);
    double variance = 0.0;
    int nnotnan = 0;
    for (int ii=0; ii<v.size(); ii++) {
      if (!std::isnan(v(ii))) {
        nnotnan += 1;
        variance += (v(ii) - m)*(v(ii) - m);
      }
    }
    return (variance/(double)(nnotnan - 1));
   }
}
  
}
}
#endif
