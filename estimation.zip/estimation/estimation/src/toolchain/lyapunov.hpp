#ifndef ESTIMATION_TOOLCHAIN_LYAPUNOV_HPP
#define ESTIMATION_TOOLCHAIN_LYAPUNOV_HPP

namespace estimation {
namespace toolchain {
/** Computes the solution to a Lyapunov equation using a doubling algorithm.
 *
 * \param A a square Eigen matrix (see extended documentation).
 * \param Q a square Eigen matrix (see extended documentation).
 * \param n number of iterations of doubling algorithm.
 *
 *  A Lyapunov equation takes the form
 * \f[
 * X = A X A^{\prime} + Q.
 * \f]
 * The doubling algorithm notes that the equation can be written as
 * \f[
 * X = \sum_{i=0}^\infty A^{i} Q (A^{\prime})^{i} + \lim_{i\rightarrow \infty} A^{i} X (A^{\prime})^{i}.
 * \f]
 * The infinite sum converges if the largest
 * eigenvalue of \f$ A \f$ is smaller than 1 in absolute value.  To see this, note that
 * there exist matrices \f$ U \f$, \f$ \Lambda \f$, \f$ V \f$ such that
 * \f[
 * A = U \Lambda V
 * \f]
 * where \f$ \Lambda \f$ is a diagonal matrix of the eigenvalues and \f$ U V = I \f$.  Then
 * \f[
 * A^{i} = U \Lambda^{i} V.
 * \f]
 * If the absolute value of the largest eigenvalue is less than one, then 
 * \f$ \Lambda^{i}\rightarrow 0 \f$.  That is, the terms of the sum tend to zero and the limit is zero.
 * This sum can be approximated by setting \f$X=Q\f$ and \f$M=A\f$, and repeating the following
 * steps many times:
 *   - \f$ X=X+M X M^{\prime} \f$
 *   - \f$ M = M M \f$.
 *
 * For a given number of iterations, \f$ n \f$, the algorith approximates \f$ X \f$ with
 * \f$ 2^n \f$ terms of the infinite sum.  
 */
template <typename dataT>
Eigen::Matrix<dataT,Eigen::Dynamic,Eigen::Dynamic> lyapunov_doubling(const Eigen::Matrix<dataT,Eigen::Dynamic,Eigen::Dynamic>& A, const Eigen::Matrix<dataT,Eigen::Dynamic,Eigen::Dynamic>& Q, int n) {
  Eigen::Matrix<dataT,Eigen::Dynamic,Eigen::Dynamic> AA(A.rows(),A.cols());
  Eigen::Matrix<dataT,Eigen::Dynamic,Eigen::Dynamic> X(Q.rows(),Q.cols());
  X = Q;
  AA = A;
  for (int i = 0; i < n; i++) {
    X = AA * X * AA.transpose() + X;
    AA = AA * AA;
  }
  return X;
}

}
}
#endif
