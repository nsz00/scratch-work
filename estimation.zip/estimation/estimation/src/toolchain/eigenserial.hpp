#ifndef ESTIMATION_TOOLCHAIN_EIGENSERIAL_HPP
#define ESTIMATION_TOOLCHAIN_EIGENSERIAL_HPP
#include <boost/mpi.hpp>
#include <Eigen/Dense>
namespace boost {
  namespace serialization {
    template<class archive, class dataT, int nrows, int ncols, int op, int maxrows, int maxcols>
    /** Serialization.
     * 
     * \param ar 
     * \param A
     * \param version
     */
    inline void serialize(archive & ar, Eigen::Matrix<dataT, nrows, ncols, op, maxrows, maxcols>& A, const unsigned int version) {
      int r = A.rows();
      int c = A.cols();
      ar & make_nvp("rows", r);
      ar & make_nvp("cols", c);    
      A.resize(r, c);     
      for(int i = 0; i < r; i++) {
	for(int j = 0; j < c; j++) {
	  ar & make_nvp("coeff", A(i,j));
	}
      }
    }
  }
}

#endif
