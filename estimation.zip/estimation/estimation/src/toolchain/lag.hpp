#ifndef ESTIMATION_TOOLCHAIN_LAG_HPP
#define ESTIMATION_TOOLCHAIN_LAG_HPP

namespace estimation {
namespace toolchain {
/** Lags a given matrix
 * \param data a Eigen matrix to lag.
 * \param lag the desired lag.
 * \param max_lag the maximum desired lag.
 */
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> lag(const Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic>& data, int lag, int max_lag) {
      int T = data.rows();
      int nx = data.cols();
      return data.block(max_lag - lag, 0, T-max_lag,nx);
  }

/** Column binds the lagged matricies of a given matrix to form the right-hand-side of a VAR(max_lag) model.
 * \param data a Eigen matrix whose lagged matricies we would like to column bind.
 * \param max_lag the maximum desired lag.
 */
Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> x_build(const Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic>& data, int max_lag) {
    int T = data.rows();
    int nx = data.cols();
    Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> x_data(T-max_lag, nx*(max_lag));
    for (int i=1;i<=max_lag;i++) {
      x_data.block(0,(i - 1)*nx,T-max_lag,nx)<< lag(data, i, max_lag);
    }
    return x_data;
  }

/** Outputs the left-hand-side of a VAR(max_lag) model.
 * \param data an Eigen matrix.
 * \param max_lag the maximum desired lag.
 */
Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> y_build(const Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic>& data, int max_lag) {
    return lag(data,0,max_lag);
  }

}
}
#endif
