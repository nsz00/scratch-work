#ifndef ESTIMATION_REGRESSION_HJLP_HPP
#define ESTIMATION_REGRESSION_HJLP_HPP
#include <Eigen/Dense>
#include <Eigen/Sparse>
#include <estimation/toolchain>
namespace estimation {
namespace regression {
/** univariate local projection with HJ bias correction.
 */
class hjlp {
public:
  int T;
  int maxh;
  int ncontrols;
  bool constant;
  Eigen::Matrix<double,Eigen::Dynamic,1> shock;
  Eigen::Matrix<double,Eigen::Dynamic,1> y;
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> controls;
  Eigen::Matrix<double,Eigen::Dynamic,1> alpha_ols;
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> beta_ols;
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> beta_hj;
  hjlp() { }
  /** Constructor for hjlp model.
   *
   * \param ydata dependent data
   * \param shockdata exogenous data
   * \param maxhdata longest horizon of local projection
   * \param niter number of iterations for bias correction
   */
  hjlp(const Eigen::Matrix<double,Eigen::Dynamic,1>& ydata, 
       const Eigen::Matrix<double,Eigen::Dynamic,1>& shockdata, 
       int maxhdata, int niter = 1, bool addconstant=true, bool preremovelineartrend=false) {
    T = ydata.rows();
    ncontrols = 0;
    maxh = maxhdata;
    constant = addconstant;
    beta_ols.resize(maxh+1,1);
    alpha_ols.resize(maxh+1);
    beta_hj.resize(maxh+1,1);
    y.resize(T);
    y = ydata;
    shock.resize(T);
    shock = shockdata;
    for (int h=0;h<=maxh;h++) {
      Eigen::Matrix<double,Eigen::Dynamic,1> YY(T-h);
      Eigen::Matrix<double,Eigen::Dynamic,1> XX(T-h);
      XX = shock.segment(0,T-h);
      YY = y.segment(h,T-h);
      estimation::regression::ols lph(YY,XX,constant,false,preremovelineartrend);
      if (constant) alpha_ols(h) = lph.beta(0);
      beta_ols(h) = lph.beta(int(constant));
    }
    
    /* Do the HJ bias correction */
    beta_hj = beta_ols;
    Eigen::Matrix<double,Eigen::Dynamic,1> beta_hj_updated(maxh+1);
    for (int iter=0;iter<niter;iter++) {
      for (int h=0;h<=maxh;h++) {
        beta_hj_updated(h) = beta_ols(h);
        for (int j=1;j<=(maxh-h);j++) {
          beta_hj_updated(h) = beta_hj_updated(h) + 1.0/((double)(T-h-1))/((double)(T-h))*((double)(T-h-j))*beta_hj(h+j);
        }
        for (int j=1;j<=std::min(h,T-h);j++) {
          beta_hj_updated(h) = beta_hj_updated(h) + 1.0/((double)(T-h-1))/((double)(T-h))*((double)(T-h-j))*beta_hj(h-j);
        }
      }
      beta_hj = beta_hj_updated;
    }
  }

  hjlp(const Eigen::Matrix<double,Eigen::Dynamic,1>& ydata, 
       const Eigen::Matrix<double,Eigen::Dynamic,1>& shockdata, 
       const Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic>& controlsdata, 
       int maxhdata, 
       int niter=1,
       bool addconstant=true,
       bool preremovelineartrend=false) {
    T = ydata.rows();
    ncontrols = controlsdata.cols();
    maxh = maxhdata;
    constant = addconstant;
    Eigen::Matrix<double,Eigen::Dynamic,1> lps(maxh+1);
    Eigen::Matrix<double,Eigen::Dynamic,1> lps_bc(maxh+1);
    alpha_ols.resize(maxh+1);
    beta_ols.resize(maxh+1,1);
    beta_hj.resize(maxh+1,1+ncontrols);
    y.resize(T);
    controls.resize(T,ncontrols);
    controls = controlsdata;
    y = ydata;
    shock.resize(T);
    shock = shockdata;
    Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> rhs(T,1+ncontrols);
    rhs.col(0) = shock;
    rhs.block(0,1,T,ncontrols) = controls;
    for (int h=0;h<=maxh;h++) {
      Eigen::Matrix<double,Eigen::Dynamic,1> YY(T-h);
      Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> XX(T-h,1+ncontrols);
      XX.col(0) = shock.segment(0,T-h);
      XX.block(0,1,T-h,ncontrols) = controls.block(0,0,T-h,ncontrols);
      YY = y.segment(h,T-h);
      estimation::regression::ols lph(YY,XX,addconstant,false,preremovelineartrend);
      if (addconstant) alpha_ols(h) = lph.beta(0);
      lps(h,0) = lph.beta(int(constant));
      beta_hj.row(h) = lph.beta.segment(int(constant),1+ncontrols);
    }
    beta_ols.col(0) = lps;
    /* Do the HJ bias correction */
    lps_bc = lps;
    Eigen::Matrix<double,Eigen::Dynamic,1> lps_updated(maxh+1);
    Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> cmeanzero(controlsdata.rows(),controlsdata.cols());
    cmeanzero = controlsdata;
    for (int i=0; i<ncontrols; i++) {
      cmeanzero.col(i) = controlsdata.col(i) - Eigen::MatrixXd::Ones(cmeanzero.rows(),1)*controlsdata.col(i).mean();
    }
    Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> zprimezinv(ncontrols,ncontrols);
    zprimezinv = (cmeanzero.transpose() * cmeanzero / ((double)controlsdata.rows())).inverse();
    Eigen::Matrix<double,Eigen::Dynamic,1> gg(maxh+1);
    for (int h=0;h<=maxh;h++) {
      Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> zmuprimez(ncontrols,ncontrols);
      zmuprimez = cmeanzero.block(0,0,controlsdata.rows()-h-1,ncontrols).transpose() * cmeanzero.block(h+1,0,controlsdata.rows()-h-1,ncontrols) / ((double)controlsdata.rows()-h-1);
      gg(h) = (zprimezinv * zmuprimez).trace() + 1.0;
    }
    for (int iter=0;iter<niter;iter++) {
      lps_updated(0,0) = lps(0,0);
      for (int h=1;h<=maxh;h++) {
        lps_updated(h,0) = lps(h,0) + (lps_bc.col(0).segment(0,h).array() * gg.col(0).segment(0,h).reverse().array()).matrix().col(0).sum()/((double)(T-h));
      }
      lps_bc = lps_updated;
    }
    beta_hj.col(0) = lps_updated;
  }

  /** Computes Newey-West standard errors.
   *
   * \param lags number of lags to use.
   */
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> hac(int h, int lags) {
    Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> S(int(constant)+1+ncontrols,int(constant)+1+ncontrols);
    Eigen::Matrix<double,Eigen::Dynamic,1> YY(T-h);
    Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> XX(T-h,int(constant)+1+ncontrols);

    if (constant) { 
      for (int j=0;j<(T-h);j++) {
        XX(j,0) = 1.0;
      }
    }
    XX.col(int(constant)) = shock.segment(0,T-h);
    if (ncontrols > 0) {
      XX.block(0,1+int(constant),T-h,ncontrols) = controls.block(0,0,T-h,ncontrols);
    }
    YY = y.segment(h,T-h);
    Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> g(T-h,1+int(constant)+ncontrols);
    Eigen::Matrix<double,Eigen::Dynamic,1> eps(T-h);
    Eigen::Matrix<double,Eigen::Dynamic,1> betahat(1+int(constant)+ncontrols);
    if (constant) betahat(0) = alpha_ols(h);
    betahat.segment(int(constant),1+ncontrols) = beta_hj.row(h);
    eps = YY - XX * betahat;
    for (int j=0;j<XX.cols();j++) {
      g.col(j) = XX.col(j).array() * eps.array();
    }
    S = g.transpose() * g;
    for (int i=1;i<=lags;i++) {
      S += ((g.block(i,0,T-h-i,1+int(constant)+ncontrols).transpose()*g.block(0,0,T-h-i,1+int(constant)+ncontrols)) 
            + (g.block(0,0, T-h-i, 1+int(constant)+ncontrols).transpose()*g.block(i,0,T-h-i,1+int(constant)+ncontrols)))*(1.0-((double)i)/((double)lags+1.0));
    }
    Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> invxprimex(1+int(constant)+ncontrols,1+int(constant)+ncontrols);
    invxprimex = (XX.transpose() * XX).inverse();
    return  invxprimex * S * invxprimex;
  }


  /* Computes Equally-Weighted-Cosine Standard Errors
   *
   * \param h horizon of LP
   * \param B number of cosine terms to include
   *          rule of thumb = floor(0.41 * T^(2/3))
   */
  Eigen::Matrix<double, Eigen::Dynamic, Eigen::Dynamic> ewc(int h, int B) {
    Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> Lambda(1+int(constant)+ncontrols,1), Omega(1+int(constant)+ncontrols,1+int(constant)+ncontrols);
    Eigen::Matrix<double,Eigen::Dynamic,1> YY(T-h);
    Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> XX(T-h,1+int(constant)+ncontrols);
    if (constant) { 
      for (int j=0;j<(T-h);j++) {
        XX(j,0) = 1.0;
      }
    }
    XX.col(int(constant)) = shock.segment(0,T-h);
    if (ncontrols > 0) {
      XX.block(0,1+int(constant),T-h,ncontrols) = controls.block(0,0,T-h,ncontrols);
    }
    YY = y.segment(h,T-h);

    Eigen::Matrix<double,Eigen::Dynamic,1> eps(T-h);
    Eigen::Matrix<double,Eigen::Dynamic,1> betahat(1+int(constant)+ncontrols);
    if (constant) betahat(0) = alpha_ols(h);
    betahat.segment(int(constant),1+ncontrols) = beta_hj.row(h);
    eps = YY - XX * betahat;

    Omega.setZero();

    // this is Equation 10 in LLSW JBES
    // note the plus in the cosine -- this is because we start at tt=0
    for (int j=1; j <= B; j++) {
      Lambda.setZero();
      for (int tt=0; tt < (T-h); tt++) { 
        Eigen::VectorXd zt = (XX.row(tt).array() * eps(tt)).matrix(); 
        Eigen::VectorXd cosine_j_t = (std::sqrt(2./(T-h))*zt.array()*std::cos(3.141592653589793* j * (tt + 0.5)/(T-h))).matrix();
        for (int i=0; i<(ncontrols+1+int(constant)); i++) Lambda(i,0) += cosine_j_t(i);

      }
      Omega += 1./B * Lambda * Lambda.transpose();
    }

    Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> invxprimex(1+int(constant)+ncontrols,1+int(constant)+ncontrols);
    invxprimex = (XX.transpose() * XX).inverse();

    return (T-h) * invxprimex * Omega * invxprimex; 
  }


};
}
}
#endif
