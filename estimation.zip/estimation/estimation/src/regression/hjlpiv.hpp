#ifndef ESTIMATION_REGRESSION_HJLPIV_HPP
#define ESTIMATION_REGRESSION_HJLPIV_HPP
#include <Eigen/Dense>
#include <Eigen/Sparse>
namespace estimation {
namespace regression {
/** Ordinary-least-squared model.
 */
class hjlpiv {
private:
  void _remove_missing_data() {
    auto bad_y = y.array().isNaN().template cast<int>();
    auto bad_x = x.array().isNaN().template cast<int>().rowwise().sum();
    auto bad_any = (bad_y + bad_x) > 0;
    int newT = T-bad_any.count(); 

    Eigen::Matrix<double, Eigen::Dynamic,1> y_with_no_missing;
    Eigen::Matrix<double, Eigen::Dynamic,Eigen::Dynamic> x_with_no_missing;
    
    y_with_no_missing.resize(newT);
    x_with_no_missing.resize(newT,nx);

    int j = 0;
    for (int i=0;i<T;i++) {
      if (not(bad_any(i))) {
        y_with_no_missing(j,0) = y(i,0);
        x_with_no_missing.row(j) = x.row(i);
        j++;
        }
    }
    T = newT;
    y.resize(T); x.resize(T,nx);
    y = y_with_no_missing;
    x = x_with_no_missing;
   
  }
public:                         
  int T;
  int maxh;
  int nx;
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> x;
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> z;
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> g;
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> beta_ols;
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> beta_hj;
  Eigen::Matrix<double,Eigen::Dynamic,1> y;
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> invzprimex;

  Eigen::Matrix<double,Eigen::Dynamic,1> eps;
  hjlpiv() { }
  /** Constructor for lp-iv model with HJ bias correction.
   *
   * \param ydata dependent data
   * \param xdata exogenous data
   * \param zdata instruments
   * \param maxhdata maximum numberof horizons of LP to consider
   * \param niter number of iterations of HJ bias correction
   * \param pooled_gamma_estimation controls how Psi is calculated
   */
  hjlpiv(const Eigen::Matrix<double,Eigen::Dynamic,1>& ydata, 
         const Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic>& xdata, 
         const Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic>& zdata, 
         int maxhdata, 
         int niter = 1, bool pooled_gamma_estimation=true,
         bool use_NW_dof=false) {
    T = ydata.rows();
    nx = xdata.cols();
    maxh = maxhdata;
    beta_ols.resize(maxh+1,xdata.cols());
    beta_hj.resize(maxh+1,xdata.cols());
    y.resize(T);
    y = ydata;
    x.resize(T,xdata.cols());
    x = xdata;
    z.resize(T,zdata.cols());
    z = zdata;
    Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> lps(xdata.cols(),maxh*2+1);
    for (int h=(-maxh); h<=maxh; h++) {
      Eigen::Matrix<double,Eigen::Dynamic,1> YY(T-std::abs(h));
      Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> XX(T-std::abs(h),x.cols());
      Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> ZZ(T-std::abs(h),z.cols());
      YY = y.segment(std::max(0,h),T-std::abs(h));
      XX = x.block(std::max(0,-h),0,T-std::abs(h),x.cols());
      ZZ = z.block(std::max(0,-h),0,T-std::abs(h),z.cols());
      estimation::regression::iv lpivh(YY,XX,ZZ);
      lps.col(maxh+h) = lpivh.beta.segment(1,x.cols());
    }
    beta_ols = lps.block(0,maxh,x.cols(),maxh+1).transpose();
    /* Construct Psi */
    Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> Psi(x.cols(),x.cols()*(1+2*maxh));
    Eigen::MatrixXd* Gammaj = new Eigen::MatrixXd[1+2*maxh];
    Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> Gammaj_bc(x.cols(),x.cols()*(1+2*maxh));
    Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> Gamma0(x.cols(),x.cols());
    Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> Gamma0_inverse(x.cols(),x.cols());
    Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> rhsx(T,x.cols());
    Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> rhsx_mean0(T,x.cols());
    Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> rhsz(T,x.cols());
    Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> rhsz_mean0(T,x.cols());
    for (int h=-maxh;h<=maxh;h++) {
      int Th;
      if (pooled_gamma_estimation) {
        Th=T;
        rhsx = x;
        rhsz = z;
      }
      else {
        Th = T-std::abs(h);
        rhsx.resize(Th,x.cols());
        rhsx_mean0.resize(Th,x.cols());
        rhsx = x.block(std::max(0,-h),0,Th,x.cols());
        rhsz.resize(Th,z.cols());
        rhsz_mean0.resize(Th,z.cols());
        rhsz = z.block(std::max(0,-h),0,Th,z.cols());
      }
      for (int j=0; j<x.cols(); j++) {
        rhsx_mean0.col(j) = rhsx.col(j) - Eigen::MatrixXd::Ones(Th,1) * rhsx.col(j).mean();
      }
      for (int j=0; j<z.cols(); j++) {
        rhsz_mean0.col(j) = rhsz.col(j) - Eigen::MatrixXd::Ones(Th,1) * rhsz.col(j).mean();
      }
      Gamma0 = rhsz_mean0.transpose() * rhsx_mean0 / ((double)rhsx_mean0.rows());
      Gamma0_inverse = Gamma0.inverse();
      for (int j=0;j<=maxh;j++) {
        Gammaj[maxh+j].resize(x.cols(), x.cols());
        Gammaj[maxh-j].resize(x.cols(), x.cols());
        if ((j+std::abs(h))<(Th-3)) {
          Gammaj[maxh+j] = rhsz_mean0.block(0,0,Th-j,x.cols()).transpose() * rhsx_mean0.block(j,0,Th-j,x.cols()) / ((double)(Th-j));
          Gammaj[maxh-j] = rhsz_mean0.block(j,0,Th-j,x.cols()).transpose() * rhsx_mean0.block(0,0,Th-j,x.cols()) / ((double)(Th-j));
          if (use_NW_dof) {
            Gammaj[maxh+j] *= ((double)(Th-j))/((double)(T));
            if (j != 0) {
              Gammaj[maxh-j] *= ((double)(Th-j))/((double)(T));
            }
          }
        } else {
          Gammaj[maxh+j].setZero();
          Gammaj[maxh-j].setZero();
        }
      }
      Psi.block(0,(x.cols())*(maxh+h),x.cols(),x.cols()) = Eigen::MatrixXd::Identity(x.cols(),x.cols());
      for (int j=1;j<=maxh;j++) {
        Psi.block(0,(x.cols())*(maxh+h),x.cols(),x.cols()) -= ((double)(T-std::abs(h)-j))/((double)((T-std::abs(h)-1)*(T-std::abs(h)))) * Gamma0_inverse * (Gammaj[maxh+j] + Gammaj[maxh-j]);
      }
    }
    /* Do the HJ bias correction */
    Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> lps_bc(x.cols(),2*maxh+1);
    Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> lps_updated(x.cols(),2*maxh+1);
    lps_bc = lps;
    for (int iter=0;iter<niter;iter++) {
      for (int h=-maxh;h<=maxh;h++) {
        lps_updated.col(h+maxh) = Psi.block(0,(x.cols())*(maxh+h),x.cols(),x.cols()) * lps.col(h+maxh);
        for (int j=1;j<=(maxh-h);j++) {
          lps_updated.col(h+maxh) += 1.0/((double)(T-std::abs(h))*(T-std::abs(h)-1))*std::max(0.0,(double)(T-std::abs(h)-j))*lps_bc.col(maxh+h+j);
        }
        for (int j=1;j<=(maxh+h);j++) {
          lps_updated.col(h+maxh) += 1.0/((double)(T-std::abs(h))*(T-std::abs(h)-1))*std::max(0.0,((double)(T-std::abs(h)-j)))*lps_bc.col(maxh+h-j);
        }
        lps_bc = lps_updated;
      }
    }
    beta_hj = lps_bc.block(0,maxh,x.cols(),maxh+1).transpose();
    delete[] Gammaj;
  }
};
}
}
#endif
