#ifndef ESTIMATION_REGRESSION_FGLS_HPP
#define ESTIMATION_REGRESSION_FGLS_HPP
#include <Eigen/Dense>
#include <Eigen/Sparse>
namespace estimation {
namespace regression {
class fgls {
public:                         
  int T;
  int nx;
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> x;
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> g;
  Eigen::Matrix<double,Eigen::Dynamic,1> y;
  Eigen::Matrix<double,Eigen::Dynamic,1> beta;
  Eigen::Matrix<double,Eigen::Dynamic,1> eps;
  fgls() { }
  fgls(const Eigen::Matrix<double,Eigen::Dynamic,1>& ydata, const Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic>& xdata, const Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic>& Omega,bool addconstant = true) {
    T = xdata.rows();
    nx = xdata.cols();
    if (addconstant) {
      nx += 1;
    }
    x.resize(T,nx);
    if (addconstant) {
      for (int i=0;i<T;i++) {
	x(i,0) = 1.0;
      }
      x.block(0,1,T,nx-1) = xdata;
    } else {
      x = xdata;
    }
    y.resize(T);
    y = ydata;
    beta.resize(nx);
    beta = (x.transpose() * Omega.inverse() * x).inverse() * x.transpose() * Omega.inverse() * y;
    eps.resize(T);
    eps = y - x * beta;
  }
};
}
}
#endif
