#ifndef ESTIMATION_REGRESSION_OLS_HPP
#define ESTIMATION_REGRESSION_OLS_HPP
#include <Eigen/Dense>
#include <Eigen/Sparse>
#include <iostream>
namespace estimation {
namespace regression {
/** Ordinary-least-squared model.
 */
class ols {
private:
  void _remove_missing_data() {
    auto bad_y = y.array().isNaN().template cast<int>();
    auto bad_x = x.array().isNaN().template cast<int>().rowwise().sum();
    auto bad_any = (bad_y + bad_x) > 0;
    int newT = T-bad_any.count(); 

    Eigen::Matrix<double, Eigen::Dynamic,1> y_with_no_missing;
    Eigen::Matrix<double, Eigen::Dynamic,Eigen::Dynamic> x_with_no_missing;
    
    y_with_no_missing.resize(newT);
    x_with_no_missing.resize(newT,nx);

    int j = 0;
    for (int i=0;i<T;i++) {
      if (not(bad_any(i))) {
        y_with_no_missing(j,0) = y(i,0);
        x_with_no_missing.row(j) = x.row(i);
        j++;
        }
    }
    T = newT;
    y.resize(T); x.resize(T,nx);
    y = y_with_no_missing;
    x = x_with_no_missing;
   
  }

  void _remove_linear_trend() {
  Eigen::MatrixXd trend(T,1);
  Eigen::MatrixXd trendi(1,1);
  for (int i=0; i < T; i++) trend(i,0) = double(i);
  trendi = (trend.transpose() * trend).inverse();
  y = y - trend * trendi * trend.transpose() * y;
  x = x - trend * trendi * trend.transpose() * x;

  }
public:                         
  int T;
  int nx;
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> x;
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> g;
  Eigen::Matrix<double,Eigen::Dynamic,1> y;

  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> invxprimex;
  /** Regression coefficients.
   */
  Eigen::Matrix<double,Eigen::Dynamic,1> beta;
  /** Regression errors.
   */
  Eigen::Matrix<double,Eigen::Dynamic,1> eps;
  ols() { }
  /** Constructor for ols model.
   *
   * \param ydata dependent data
   * \param xdata exogenous data
   * \param addconstant should a constant be added to the exogenous data?
   * \param sparseinverse should we calculate the sparse inverse?
   */
  ols(const Eigen::Matrix<double,Eigen::Dynamic,1>& ydata, const Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic>& xdata, bool addconstant = true, bool sparseinverse = false, bool preremovelineartrend = false) {
    T = xdata.rows();
    nx = xdata.cols();
    if (addconstant) {
      nx += 1;
    }
    x.resize(T,nx);
    if (addconstant) {
      for (int i=0;i<T;i++) {
	x(i,0) = 1.0;
      }
      x.block(0,1,T,nx-1) = xdata;
    } else {
      x = xdata;
    }
    y.resize(T);
    y = ydata;
    _remove_missing_data();
    if (preremovelineartrend) _remove_linear_trend();
    invxprimex.resize(nx,nx);
    if (sparseinverse) {
      Eigen::SparseMatrix<double> xpx(nx,nx);
      invxprimex = x.transpose() * x;
      for (int i = 0; i<nx; i++) {
	for (int j=0; j<nx; j++) {
	  if (abs(invxprimex(i,j)) > 0.00000001) {
	    xpx.insert(i,j) = invxprimex(i,j);
	  }
	}
      }
      Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> I_nx(nx,nx);
      I_nx.setIdentity();
      xpx.makeCompressed();
      Eigen::SimplicialLLT<Eigen::SparseMatrix<double>> solverxpx;
      solverxpx.compute(xpx);
      invxprimex = solverxpx.solve(I_nx);
    } else {
      invxprimex = (x.transpose() * x).inverse();
    }
    beta.resize(nx);
    beta = x.bdcSvd(Eigen::ComputeThinU | Eigen::ComputeThinV).solve(y);//x.fullPivHouseholderQr().solve(y);
    eps.resize(T);
    eps = y - x * beta;
  }

  /** Computes variance/covariance matrix for beta with homoskedastic standard errors.
   */
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> cov() {
    return (eps.transpose()*eps)*invxprimex*(1.0/(T-nx));
  }

  /** Computes Newey-West standard errors.
   *
   * \param lags number of lags to use.
   */
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> hac(int lags) {
    Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> S(nx,nx);
    if (g.rows() < T) {
      g.resize(T,nx);
      for (int j=0;j<x.cols();j++) {
	g.col(j) = x.col(j).array() * eps.array();
      }
    }
    S = g.transpose() * g;
    for (int i=1;i<=lags;i++) {
      S += ((g.block(i,0,T-i,nx).transpose()*g.block(0,0,T-i,nx)) + (g.block(0,0, T-i, nx).transpose()*g.block(i,0,T-i,nx)))*(1.0-((double)i)/((double)lags+1.0));
    }
    return  invxprimex * S * invxprimex;
  }

  /* Computes Equally-Weighted-Cosine Standard Errors
   *
   * \param B number of cosine terms to include
   *          rule of thumb = floor(0.41 * T^(2/3))
   */
  Eigen::Matrix<double, Eigen::Dynamic, Eigen::Dynamic> ewc(int B) {
    Eigen::Matrix<double, Eigen::Dynamic, Eigen::Dynamic> Lambda(nx,1), Omega(nx,nx); 
    
    Omega.setZero();
    
    // this is Equation 10 in LLSW JBES
    // note the plus in the cosine -- this is because we start at tt=0
    for (int j=1; j <= B; j++) {
      Lambda.setZero();
      for (int tt=0; tt < T; tt++) { 
        Eigen::VectorXd zt = (x.row(tt).array() * eps(tt)).matrix(); 
        Eigen::VectorXd cosine_j_t = (std::sqrt(2./T)*zt.array()*std::cos(3.141592653589793* j * (tt + 0.5)/T)).matrix();
        for (int i=0; i<nx; i++) Lambda(i,0) += cosine_j_t(i);
    
      }
      Omega += 1./B * Lambda * Lambda.transpose();
    }
    
    return T * invxprimex * Omega * invxprimex; 
  }

};
}
}
#endif
