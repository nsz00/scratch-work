#ifndef ESTIMATION_REGRESSION_IV_HPP
#define ESTIMATION_REGRESSION_IV_HPP
#include <Eigen/Dense>
#include <Eigen/Sparse>
namespace estimation {
namespace regression {
/** Ordinary-least-squared model.
 */
class iv {
private:
  void _remove_missing_data() {
    auto bad_y = y.array().isNaN().template cast<int>();
    auto bad_x = x.array().isNaN().template cast<int>().rowwise().sum();
    auto bad_any = (bad_y + bad_x) > 0;
    int newT = T-bad_any.count(); 

    Eigen::Matrix<double, Eigen::Dynamic,1> y_with_no_missing;
    Eigen::Matrix<double, Eigen::Dynamic,Eigen::Dynamic> x_with_no_missing;
    
    y_with_no_missing.resize(newT);
    x_with_no_missing.resize(newT,nx);

    int j = 0;
    for (int i=0;i<T;i++) {
      if (not(bad_any(i))) {
        y_with_no_missing(j,0) = y(i,0);
        x_with_no_missing.row(j) = x.row(i);
        j++;
        }
    }
    T = newT;
    y.resize(T); x.resize(T,nx);
    y = y_with_no_missing;
    x = x_with_no_missing;
   
  }
public:                         
  int T;
  int nx;
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> x;
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> z;
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> g;
  Eigen::Matrix<double,Eigen::Dynamic,1> y;

  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> invzprimex;
  /** Regression coefficients.
   */
  Eigen::Matrix<double,Eigen::Dynamic,1> beta;
  /** Regression errors.
   */
  Eigen::Matrix<double,Eigen::Dynamic,1> eps;
  iv() { }
  /** Constructor for iv model.
   *
   * \param ydata dependent data
   * \param xdata exogenous data
   * \param zdata instrument data
   * \param addconstant should a constant be added to the exogenous data?
   * \param sparseinverse should we calculate the sparse inverse?
   */
  iv(const Eigen::Matrix<double,Eigen::Dynamic,1>& ydata, const Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic>& xdata, const Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic>& zdata,bool addconstant = true, bool sparseinverse = false) {
    T = xdata.rows();
    nx = xdata.cols();
    if (addconstant) {
      nx += 1;
    }
    x.resize(T,nx);
    z.resize(T,nx);
    if (addconstant) {
      for (int i=0;i<T;i++) {
	x(i,0) = 1.0;
        z(i,0) = 1.0;
      }
      x.block(0,1,T,nx-1) = xdata;
      z.block(0,1,T,nx-1) = zdata;
    } else {
      x = xdata;
      z = zdata;
    }
    y.resize(T);
    y = ydata;
    _remove_missing_data();
    invzprimex.resize(nx,nx);
    if (sparseinverse) {
      Eigen::SparseMatrix<double> zpx(nx,nx);
      invzprimex = z.transpose() * x;
      for (int i = 0; i<nx; i++) {
	for (int j=0; j<nx; j++) {
	  if (abs(invzprimex(i,j)) > 0.00000001) {
	    zpx.insert(i,j) = invzprimex(i,j);
	  }
	}
      }
      Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> I_nx(nx,nx);
      I_nx.setIdentity();
      zpx.makeCompressed();
      Eigen::SimplicialLLT<Eigen::SparseMatrix<double>> solverzpx;
      solverzpx.compute(zpx);
      invzprimex = solverzpx.solve(I_nx);
    } else {
      invzprimex = (z.transpose() * x).inverse();
    }
    beta.resize(nx);
    beta = invzprimex * z.transpose() * y;
    eps.resize(T);
    eps = y - x * beta;
  }

  ///** Computes variance/covariance matrix for beta with homoskedastic standard errors.
  // */
  //Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> cov() {
  //  return (eps.transpose()*eps)*invxprimex*(1.0/(T-nx));
  //}
  //
  ///** Computes Newey-West standard errors.
  // *
  // * \param lags number of lags to use.
  // */
  //Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> hac(int lags) {
  //  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> S(nx,nx);
  //  if (g.rows() < T) {
  //    g.resize(T,nx);
  //    for (int j=0;j<x.cols();j++) {
  //      g.col(j) = x.col(j).array() * eps.array();
  //    }
  //  }
  //  S = g.transpose() * g;
  //  for (int i=1;i<=lags;i++) {
  //    S += ((g.block(i,0,T-i,nx).transpose()*g.block(0,0,T-i,nx)) + (g.block(0,0, T-i, nx).transpose()*g.block(i,0,T-i,nx)))*(1.0-((double)i)/((double)lags+1.0));
  //  }
  //  return  invxprimex * S * invxprimex;
  //}

};
}
}
#endif
