#ifndef ESTIMATION_REGRESSION_VAR_HPP
#define ESTIMATION_REGRESSION_VAR_HPP
#include <Eigen/Dense>
#include <Eigen/Sparse>
#include <estimation/src/toolchain/lag.hpp>

namespace estimation {
namespace regression {
/** Vector Autoregression model.
 */
class var : public estimation::regression::sur {
private:
  int lag_p;
public:
  var() { }
  /** Constructor for var model
   *
   * \param var_data dataset 
   * \param p number of lags
   * \param var_addconstant should a constant be added to the exogenous data?  
   */
  var(const Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic>& var_data, int p, bool var_addconstant = true) :
      estimation::regression::sur(estimation::toolchain::y_build(var_data, p),     
                                  estimation::toolchain::x_build(var_data, p),
                                  var_addconstant) { 
    lag_p = p;
  }

  /* Computes the log likehood of a VAR
  * 
  * \param 
  */ 
  double loglik(const Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic>& Phi, 
                const Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic>& Sigma) {

  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> resid;
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> Sigma_i = Sigma.inverse();
  double l;

  resid.resize(T, ny);
  resid = y - x * Phi;

  l = (-(1.0*T)*ny/2.0 * std::log(2*3.141592653589793)  
       -T/2.0*Sigma.colPivHouseholderQr().logAbsDeterminant()
       -0.5*(Sigma_i * resid.transpose() * resid).trace() );

  return l;


  }

};
}}
#endif
