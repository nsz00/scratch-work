#ifndef ESTIMATION_REGRESSION_SUR_HPP
#define ESTIMATION_REGRESSION_SUR_HPP
#include <Eigen/Dense>
#include <Eigen/KroneckerProduct>
namespace estimation {
namespace regression {
/** Seemingly-unrelated-regression model.
 */
class sur {
protected:
  int T;
  int nx;
  int ny;
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> x;
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> invxprimex;
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> g;
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> y;
public:
  /** Regression coefficients.
   */
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> beta;
  /** Regression errors.
   */
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> eps;
  sur() { }
  /** Constructor for sur model.
   *
   * \param ydata dependent data
   * \param xdata exogenous data
   * \param addconstant should a constant be added to the exogenous data?
   */
  sur(const Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic>& ydata, const Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic>& xdata, bool addconstant = true) {
    T = xdata.rows();
    nx = xdata.cols();
    if (addconstant) {
      nx += 1;
    }
    x.resize(T,nx);
    if (addconstant) {
      for (int i=0;i<T;i++) {
	x(i,0) = 1.0;
      }
      x.block(0,1,T,nx-1) = xdata;
    } else {
      x = xdata;
    }
    ny = ydata.cols();
    y.resize(T,ny);
    y = ydata;
    invxprimex.resize(nx,nx);
    invxprimex = (x.transpose() * x).inverse();
    beta.resize(nx,ny);
    beta = invxprimex * x.transpose() * y;
    eps.resize(T,ny);
    eps = y - x * beta;
  }

  
  /** Computes Newey-West standard errors of vec(beta).
   *
   * \param lags number of lags to use.
   */
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> hac(int lags) {
    Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> S(nx*ny,nx*ny);
    if (g.rows() < T) {
      g.resize(T,nx*ny);
      for (int i=0;i<y.cols();i++) {
	for (int j=0;j<x.cols();j++) {
	  g.col(i*x.cols()+j) = x.col(j).array() * eps.col(i).array();
	}
      }
    }
    S = g.transpose() * g;
    for (int i=1;i<=lags;i++) {
      S +=((g.block(i,0,T-i,nx*ny).transpose()*g.block(0,0,T-i,nx*ny)) + (g.block(0,0, T-i, nx*ny).transpose()*g.block(i,0,T-i,nx*ny)))*(1.0-((double)i)/((double)lags+1.0));
           
    }
    Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> I_ny(ny,ny);
    I_ny.setIdentity();
    Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> tmp(ny*nx,ny*nx);
    tmp = Eigen::kroneckerProduct(I_ny, invxprimex);
    return  tmp * S * tmp;
  }
};
}
}
#endif
