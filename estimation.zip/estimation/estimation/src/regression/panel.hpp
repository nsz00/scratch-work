#ifndef ESTIMATION_REGRESSION_PANEL_HPP
#define ESTIMATION_REGRESSION_PANEL_HPP
#include <Eigen/Dense>
#include <Eigen/Sparse>
namespace estimation {
namespace regression {
/** Panel regression model.
 */
class panel {
private:
  int T;
  int nx;
  int ngroupings;
  int nuniquegroups;
  Eigen::Matrix<int,Eigen::Dynamic,Eigen::Dynamic> groupings;
  Eigen::Matrix<int,Eigen::Dynamic,1> uniquegroups;
  estimation::regression::ols olsmodel;
public:
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> x;
  /** Regression coefficients.
   */
  Eigen::Matrix<double,Eigen::Dynamic,1> beta;
  /** Regression errors.
   */
  Eigen::Matrix<double,Eigen::Dynamic,1> eps;
  /** Constructor for panel model.
   *
   * \param ydata dependent data
   * \param xdata exogenous data
   * \param groupingsdata defines panel by groupings
   */
  panel(const Eigen::Matrix<double,Eigen::Dynamic,1>& ydata, const Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic>& xdata, const Eigen::Matrix<int,Eigen::Dynamic,Eigen::Dynamic>& groupingsdata) {
    groupings.resize(groupingsdata.rows(),groupingsdata.cols());
    groupings = groupingsdata;
    ngroupings = groupings.cols();
    T = xdata.rows();
    uniquegroups.resize(T);
    for (int i=0;i<T;i++) {
      uniquegroups(i,0) = -1;
    }
    nuniquegroups = 0;
    for (int i=0;i<T;i++) {
      if (uniquegroups(i,0) == -1) {
	nuniquegroups += 1;
	uniquegroups(i,0) = nuniquegroups;
	for (int j=(i+1);j<T;j++) {
	  if (uniquegroups(j,0) == -1) {
	    if ((groupings.row(i) - groupings.row(j)).array().abs().maxCoeff() == 0) {
	      uniquegroups(j,0) = nuniquegroups;
	    }
	  }
	}
      }
    }
    nx = xdata.cols();
    nx += nuniquegroups;
    x.resize(T,nx);
    x.setZero();
    x.block(0,0,T,nx-nuniquegroups) = xdata;
    for (int i=0;i<T;i++) {
      x(i,xdata.cols()+uniquegroups(i,0)-1) = 1.0;
    }
    estimation::regression::ols mod(ydata,x,false,true);
    olsmodel = mod;
    beta.resize(nx,1);
    beta = olsmodel.beta;
    eps.resize(T,1);
    eps = olsmodel.eps;
  }

  /** Computes clustered standard errors.
   *
   * \param clusterbygroups index of the groupings to use for clustering.
   * \param dfadjust should we perform a degrees of freedom adjustment?
   */
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> cluster(const Eigen::Matrix<int,Eigen::Dynamic,1> clusterbygroups, bool dfadjust=true) {
    Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> middle(nx,nx);
    middle.setZero();
    for (int i=0;i<T;i++) {
      middle += x.row(i).transpose() * x.row(i) * eps(i,0) * eps(i,0);
      for (int j=i+1;j<T;j++) {
    	bool ingroup {false};
        for (int k=0;k<clusterbygroups.rows();k++) {
          if (groupings(i,clusterbygroups(k,0))==groupings(j,clusterbygroups(k,0))) {
            ingroup = true;
          }
        }
    	if (ingroup) {
    	  middle += x.row(i).transpose() * x.row(j) * eps(i,0) * eps(j,0) + x.row(j).transpose() * x.row(i) * eps(j,0) * eps(i,0);
    	}
      }
    }
    double adj {1.0};
    if (dfadjust) {
      int neffectivegroups = 0;
      Eigen::Matrix<int,Eigen::Dynamic,1> eg(T);
      for (int i=0;i<T;i++) {
	eg(i,0) = -1;
      }
      for (int i=0;i<T;i++) {
	if (eg(i,0) == -1) {
	  neffectivegroups += 1;
	  eg(i,0) = neffectivegroups;
	  for (int j=(i+1);j<T;j++) {
	    if (eg(j,0) == -1) {
	      for (int k=0;k<clusterbygroups.rows();k++) {
		if (groupings(i,clusterbygroups(k,0))==groupings(j,clusterbygroups(k,0))) {
		  eg(j,0) = neffectivegroups;
		}
	      }
	    }
	  }
	}
      }
      adj = ((double) neffectivegroups) / ((double) neffectivegroups - 1.0);
    }
    return adj * olsmodel.invxprimex * middle * olsmodel.invxprimex;
  }
};



class panelgmm {
private:
  int T;
  int nx;
  int I;
  estimation::regression::ols olsmodel;
public:
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> x;
  Eigen::Matrix<double,Eigen::Dynamic,1> beta;
  Eigen::Matrix<double,Eigen::Dynamic,1> eps;
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> g;
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> Ggmm;
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> invGgmm;
  panelgmm(const Eigen::Matrix<double,Eigen::Dynamic,1>& ydata, const Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic>& xdata, const int Iin) {
    I = Iin;
    T = xdata.rows()/I;
    nx = xdata.cols();
    nx += I;
    x.resize(T*I,nx);
    x.setZero();
    x.block(0,0,xdata.rows(),xdata.cols()) = xdata;
    for (int ii=0;ii<I;ii++) {
      x.col(xdata.cols()+ii).segment(ii*T,T).setConstant(1.0);
    }
    estimation::regression::ols mod(ydata,x,false,true);
    olsmodel = mod;
    beta.resize(nx,1);
    beta = olsmodel.beta;
    eps.resize(T*I,1);
    eps = olsmodel.eps;
    g.resize(T,nx);
    g.col(0).setZero();
    Ggmm.resize(nx,nx);
    Ggmm.setZero();
    for (int ii=0;ii<I;ii++) {
      Ggmm(ii+xdata.cols(),ii+xdata.cols()) = 1.0;
      g.col(ii+xdata.cols()) = eps.segment(ii*T,T);
      for (int jj=0; jj<xdata.cols(); jj++) {
        g.col(jj) += (eps.segment(ii*T,T).array() * xdata.col(jj).segment(ii*T,T).array() / ((double)I)).matrix();
      }
    }
    Ggmm.block(0,0,xdata.cols(),xdata.cols()) = xdata.transpose() * xdata / ((double)xdata.rows());
    invGgmm.resize(nx,nx);
    invGgmm = Ggmm.inverse();
  }
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> hac(int lags) {
    Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> S(nx,nx);
    S = g.transpose() * g / ((double)T);
    for (int i=1;i<=lags;i++) {
      S += ((g.block(i,0,T-i,nx).transpose()*g.block(0,0,T-i,nx)) + (g.block(0,0, T-i, nx).transpose()*g.block(i,0,T-i,nx)))*(1.0-((double)i)/((double)lags+1.0)) / ((double)T);
    }
    return  invGgmm * S * invGgmm / ((double)T);
  }
};
}
}
#endif
