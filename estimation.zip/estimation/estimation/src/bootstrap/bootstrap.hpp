#ifndef ESTIMATION_BOOTSTRAP_BOOTSTRAP_HPP
#define ESTIMATION_BOOTSTRAP_BOOTSTRAP_HPP
#include <Eigen/Dense>

namespace estimation{
namespace bootstrap {
/** Creates a distribution of statistics from the bootstrap.
 *
 * \param nboot number of boostrap draws to perform.
 * \param data Eigen::Matrix of data.
 * \param estimate object that takes the data as an input and returns estimates parameters.
 * \param generate object that takes estimated parameters, the data, and the random number generator as input and returns a bootstrap sample.
 * \param statistics object that takes the estimated parameters from the data, the estimated parameters from the bootstrap sample, and the bootstrap sample as arguments and returns the statistics of interest in a format that can be stored as a column of an Eigen::Matrix.
 * \param rng a boost::random random number generator.
 */
template <typename dataT, typename paramestT, typename datagenT, typename statisticsT, typename rngengine>
Eigen::MatrixXd bootstrap(int nboot, const Eigen::MatrixBase<dataT>& data, const paramestT& estimate, const datagenT& generate, statisticsT& statistics, rngengine& rng) {
  auto theta_hat = estimate(data);
  auto stats = statistics(theta_hat,theta_hat,data);
  Eigen::MatrixXd output(stats.size(),nboot);
  for (int i = 0; i < nboot; i++) {
    auto data_star = generate(theta_hat, data, rng);
    auto theta_star = estimate(data_star);
    output.col(i) = statistics(theta_hat,theta_star,data_star);
  }
  return output;
}
/** Creates a distribution of statistics from the bootstrap and pre-pivots.  Pre-pivot quantiles are stored in the second half of the rows of the output.
 *
 * \param nboot number of boostrap draws to perform.
 * \param nprepivot number of bootstrap draws to perform when pre-pivoting.
 * \param data Eigen::Matrix of data.
 * \param estimate object that takes the data as an input and returns estimates parameters.
 * \param generate object that takes estimated parameters, the data, and the random number generator as input and returns a bootstrap sample.
 * \param statistics object that takes the estimated parameters from the data, the estimated parameters from the bootstrap sample, and the bootstrap sample as arguments and returns the statistics of interest in a format that can be stored as a column of an Eigen::Matrix.
 * \param rng a boost::random random number generator.
 */
template <typename dataT, typename paramestT, typename datagenT, typename statisticsT, typename rngengine>
Eigen::MatrixXd bootstrap_prepivot(int nboot, int nprepivot, const Eigen::MatrixBase<dataT>& data, const paramestT& estimate, const datagenT& generate, statisticsT& statistics, rngengine& rng) {
  auto theta_hat = estimate(data);
  auto stats = statistics(theta_hat,theta_hat,data);
  Eigen::MatrixXd output(stats.size()*2,nboot);
  for (int i = 0; i < nboot; i++) {
    auto data_star = generate(theta_hat, data, rng);
    auto theta_star = estimate(data_star);
    auto stats_star = statistics(theta_hat,theta_star,data_star);
    output.block(0,i,stats.size(),1) = stats_star;
    auto stats_star_star = bootstrap(nprepivot, data_star, estimate, generate, statistics, rng);
    for (int j = 0; j < stats.size(); j++) {
      output(stats.size()+j,i) = (stats_star_star.row(j).array() < stats_star(j,0)).template cast<double>().matrix().mean();
    }  
  }
  return output;
}

/** Creates a distribution of statistics from the bootstrap and pre-pivots.  Pre-pivot quantiles are stored in the second two-thirds of the rows of the output.
 *
 * \param nboot number of boostrap draws to perform.
 * \param nprepivot number of bootstrap draws to perform when pre-pivoting.
 * \param data Eigen::Matrix of data.
 * \param estimate object that takes the data as an input and returns estimates parameters.
 * \param generate object that takes estimated parameters, the data, and the random number generator as input and returns a bootstrap sample.
 * \param statistics object that takes the estimated parameters from the data, the estimated parameters from the bootstrap sample, and the bootstrap sample as arguments and returns the statistics of interest in a format that can be stored as a column of an Eigen::Matrix.
 * \param rng a boost::random random number generator.
 */
template <typename dataT, typename paramestT, typename datagenT, typename statisticsT, typename rngengine>
Eigen::MatrixXd bootstrap_prepivot2(int nboot, int nprepivot, const Eigen::MatrixBase<dataT>& data, const paramestT& estimate, const datagenT& generate, statisticsT& statistics, rngengine& rng) {
  auto theta_hat = estimate(data);
  auto stats = statistics(theta_hat,theta_hat,data);
  Eigen::MatrixXd output(stats.size()*3,nboot);
  for (int i = 0; i < nboot; i++) {
    auto data_star = generate(theta_hat, data, rng);
    auto theta_star = estimate(data_star);
    auto stats_star = statistics(theta_hat,theta_star,data_star);
    output.block(0,i,stats.size(),1) = stats_star;
    Eigen::MatrixXd Z(stats_star.size(),nprepivot);
    Eigen::MatrixXd tmp(stats.size(),nprepivot);
    for (int k = 0; k < nprepivot; k++) {
      auto data_star_star = generate(theta_star, data_star, rng);
      auto theta_star_star = estimate(data_star);
      auto stats_star_star = statistics(theta_star,theta_star_star,data_star_star);
      Z.col(k) = stats_star_star;
      auto stats_star_star_star = bootstrap(nprepivot, data_star_star, estimate, generate, statistics, rng);
      for (int j = 0; j<stats.size(); j++) {
        tmp(j,k) = (stats_star_star_star.row(j).array() < stats_star_star(j,0)).template cast<double>().matrix().mean();
      }
    }
    for (int j = 0; j < stats.size(); j++) {
      output(stats.size()+j,i) = (Z.row(j).array() < stats_star(j,0)).template cast<double>().matrix().mean();
      output(stats.size()*2+j,i) = (tmp.row(j).array() < output.row(stats.size()+j).array()).template cast<double>().matrix().mean();
    }  
  }
  return output;
}

}
}
#endif
