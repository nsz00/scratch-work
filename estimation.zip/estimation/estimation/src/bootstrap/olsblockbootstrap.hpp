#ifndef ESTIMATION_BOOTSTRAP_OLSBLOCKBOOTSTRAP_HPP
#define ESTIMATION_BOOTSTRAP_OLSBLOCKBOOTSTRAP_HPP
#include <Eigen/Dense>
#include <estimation/regression>

namespace estimation{
namespace bootstrap {
/** Creates a distribution of ols regression statistics from the bootstrap.
 *
 * \param nboot number of bootstrap draws to perform.
 * \param blocksize block length for the block bootstrap.
 * \param Y left-hand-side data.
 * \param X right-hand-side data.
 * \param rng a boost::random random number generator.
 * \param addconstant should a constant be added to the exogenous data?
 */
template <typename dataYT, typename dataXT, typename rngengine>
Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> olsblockbootstrap(int nboot, int blocksize, const Eigen::MatrixBase<dataYT>& Y, const Eigen::MatrixBase<dataXT>& X, rngengine& rng, bool addconstant = true) {
  int nout = X.cols();
  if (addconstant) {
    nout += 1;
  }
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> data(Y.rows(),Y.cols()+X.cols());
  data.block(0,0,Y.rows(),Y.cols()) = Y;
  data.block(0,Y.cols(),X.rows(),X.cols()) = X;
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> output(nout,nboot);
  /** Generate sample blocks
   */
  class sample_blocks {
  public:
    /*  Block length for the block bootstrap.
     */
    int blocksize;
    /* Constructor for sample blocks
     *
     * \param blocksize_ block size.
     */
    sample_blocks(int blocksize_) : blocksize(blocksize_) { }

    /* Sample blocks functor 
     *
     * \param theta_hat data estimate.
     * \param data right-hand-side and left-hand-side data.
     * \param rng a boost::random random number generator.
     */
    Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> operator () (const Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic>& theta_hat, const Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic>& data, rngengine& rng) const {
      int T = data.rows();
      int ndraw = std::ceil(((double)T)/((double)blocksize));
      boost::random::uniform_int_distribution<>iididx(0,T-blocksize-1);
      Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> output(T,data.cols());
      for (int i=0;i<(ndraw-1);i++) {
        output.block(i*blocksize,0,blocksize,data.cols()) = data.block(iididx(rng),0,blocksize,data.cols());
      }
      output.block((ndraw-1)*blocksize,0,T-(ndraw-1)*blocksize,data.cols()) = data.block(iididx(rng),0,T-(ndraw-1)*blocksize,data.cols());
      return output;
    }
  };
  sample_blocks generate(blocksize);

  /** Estimate OLS
   */
  class estimate_ols {
  public:
    /* \param addconstant should a constant be added to the exogenous data?
     */
    bool addconstant;
    /* Constructor for estimate OLS
     *
     * \param addconstant_ should a constant be added to the exogenous data?.
     */
    estimate_ols(bool addconstant_) : addconstant(addconstant_) { }
    /* Estimate OLS functor
     *
     * \param data right-hand-side and left-hand-side data.
     */
    Eigen::Matrix<double,Eigen::Dynamic,1> operator () (const Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic>& data) const {
      int T = data.rows();
      Eigen::Matrix<double,Eigen::Dynamic,1> Y(T);
      Y = data.col(0);
      Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> X(T,data.cols()-1);
      X = data.block(0,1,T,data.cols()-1);
      estimation::regression::ols lp(Y, X, addconstant);
      int nbeta = data.cols()-1;
      if (addconstant) {
        nbeta += 1;
      }
      Eigen::Matrix<double,Eigen::Dynamic,1> output(nbeta);
      output = lp.beta;
      return output;
    }
  };
  estimate_ols estimate(addconstant);

  /** Perform bootstrap draws
   */
  class bootstrap_draw {
  public:
    /** Constructor for bootstrap draws
     */
    bootstrap_draw() { }
    /* Bootstrap draws functor
     *
     * \param theta_hat data estimate.
     * \param theta_star bootstrap estimate.
     * \param data_star bootstrap sample.
     */
    Eigen::Matrix<double,Eigen::Dynamic,1> operator () (const Eigen::Matrix<double,Eigen::Dynamic,1>& theta_hat, const Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic>& theta_star, const Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic>& data_star) const {
      Eigen::Matrix<double,Eigen::Dynamic,1> output(theta_star.rows());
      output = theta_star;
      return output;
    }
  };
  bootstrap_draw statistics;
  int nbeta = X.cols();
  if (addconstant) {
    nbeta += 1;
  }
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> bootstrap_output(nbeta,nboot);
  bootstrap_output = estimation::bootstrap::bootstrap(nboot, data, estimate, generate, statistics, rng);
  return bootstrap_output;
}


}
}
#endif
