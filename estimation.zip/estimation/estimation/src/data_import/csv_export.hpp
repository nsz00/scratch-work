#ifndef CSV_EXPORT_HPP
#define CSV_EXPORT_HPP
#include <iostream>
#include <fstream>
#include <vector>
#include <set>
#include <iterator>
#include <string>
#include <algorithm>
#include <boost/algorithm/string.hpp>
#include <Eigen/Dense>

/** CSV exporter.
 */
class csv_exporter
{
  /** CSV file name.
   */
  std::string file_name;
  /** CSV delimiter
   */
  std::string delimiter;
  /** CSV line counter
   */
  int linesCount;
  /** Eigen Matrix to be exported.
  */
  Eigen::Matrix<double, Eigen::Dynamic, Eigen::Dynamic> matrix_data;
  /**Matrix Data rows
  */
  int T;
  /**Matrix Data columns
  */
  int nx;
 
public:
  /** Constructor for csv exporter.
   *
   * \param filename csv filename
   * \param delim delimiter used to separate data
   */
	csv_exporter(std::string filename, const Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic>& data, std::string delim = ",") :
			file_name(filename), matrix_data(data), delimiter(delim), linesCount(0), T(data.rows()), nx(data.cols())
	{ }
 
	void storeEigen();
};

  /** Exports and returns csv data.
   */ 
void csv_exporter::storeEigen()
{
  std::fstream file;
  file.open(file_name, std::ios::out | (linesCount ? std::ios::app : std::ios::trunc));
  for(int i = 0; i < T; i++){
    for(int j = 0; j < nx; j++){
      file << matrix_data(i, j);
      if(j != nx){
	file << delimiter;
      }
    }
    file << "\n";
    linesCount++; 
  }
  file.close();
}
#endif
