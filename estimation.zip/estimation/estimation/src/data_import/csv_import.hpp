#ifndef CSV_IMPORT_HPP
#define CSV_IMPORT_HPP
#include <iostream>
#include <fstream>
#include <vector>
#include <iterator>
#include <string>
#include <algorithm>
#include <boost/algorithm/string.hpp>

/** CSV importer.
 */
class csv_import
{
  /** CSV file name.
   */
  std::string file_name;
  /** CSV delimiter.
   */
  std::string delimiter;
 
public:
  /** Constructor for csv importer.
   *
   * \param filename csv filename
   * \param delim delimiter used to separate data
   */
	csv_import(std::string filename, std::string delim = ",") :
			file_name(filename), delimiter(delim)
	{ }
	std::vector<std::vector<std::string> > get_data();
};

  /** Imports and returns csv data.
   */ 
std::vector<std::vector<std::string> > csv_import::get_data()
{
	std::ifstream file(file_name);
 
	std::vector<std::vector<std::string> > data_vec;
 
	std::string line = "";
	while (getline(file, line))
	{
		std::vector<std::string> vec;
		boost::algorithm::split(vec, line, boost::is_any_of(delimiter));
		data_vec.push_back(vec);
	}
	file.close();
 
	return data_vec;
}

#endif
