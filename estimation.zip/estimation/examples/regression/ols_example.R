library(sandwich)
library(lmtest)
x <- 0:9
y <- (0:9)^2
print(summary(lm(y~x)))
print(coeftest(lm(y~x), vcov=NeweyWest(lm(y~x), lag = 0, prewhite = FALSE), df=Inf))
g <- c(rep(1,5),rep(2,5))
print(summary(lm(y~x+factor(g)-1)))
