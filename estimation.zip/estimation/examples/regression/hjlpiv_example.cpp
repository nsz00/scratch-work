#include <Eigen/Dense>
#include <iostream>
#include <estimation/regression>
int main () {
  int T {10};
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> x(T,2);
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> y(T,1);
  for (int i=0;i<T;i++) {
    x(i,0) = (double) i;
    x(i,1) = (double) ((i-1)*(i-1));
    y(i,0) = (double) (i*i);
  }

  estimation::regression::hjlp model3(y.block(1,0,9,1),x.block(1,0,9,1),y.block(0,0,9,1),3);
  std::cout << model3.beta_hj << std::endl;

  estimation::regression::hjlpiv model4(y.block(1,0,9,1),x.block(1,0,9,2),x.block(1,0,9,2),3);
  std::cout << model4.beta_hj << std::endl;

  return 0;
}
