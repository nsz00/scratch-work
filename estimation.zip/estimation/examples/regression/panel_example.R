library(sandwich)
library(lmtest)
library(clubSandwich)
x <- 0:19
y <- (0:19)^2
g1 <- c(rep(1,10),rep(2,10))
g2 <- c(rep(1,5),rep(2,15))
print(summary(lm(y~x+factor(g1)+factor(g2)-1)))
print(coef_test(lm(y~x+factor(g1)+factor(g2)-1), vcov = "CR1", 
                cluster = g1, test = "naive-t"))
