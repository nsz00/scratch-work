#include <Eigen/Dense>
#include <iostream>
#include <estimation/regression>
int main () {
  int T {20};
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> x(T,1);
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> y(T,1);
  Eigen::Matrix<int,Eigen::Dynamic,Eigen::Dynamic> groups(T,2);
  for (int i=0;i<T;i++) {
    x(i,0) = (double) i;
    y(i,0) = (double) (i*i);
    if (i < T/2) {
      groups(i,0) = 1;
    } else {
      groups(i,0) = 2;
    }
    if (i < T/4) {
      groups(i,1) = 1;
    } else {
      groups(i,1) = 2;
    }
  }
  estimation::regression::panel model(y,x,groups);
  std::cout << model.beta << std::endl;
  Eigen::Matrix<int,Eigen::Dynamic,1> cby(0);
  std::cout << model.cluster(cby) << std::endl;
  estimation::regression::ols olsmodel(y,model.x,false);
  std::cout << olsmodel.hac(0) << std::endl;
  cby.resize(1,1);
  cby(0,0) = 0;
  std::cout << model.cluster(cby) << std::endl;
  return 0;
}
