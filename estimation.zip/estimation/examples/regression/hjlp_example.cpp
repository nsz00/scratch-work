#include <Eigen/Dense>
#include <iostream>
#include <estimation/regression>
int main () {
  int T {10};
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> x(T,1);
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> y(T,1);
  for (int i=0;i<T;i++) {
    x(i,0) = (double) i;
    y(i,0) = (double) (i*i);
  }
  estimation::regression::ols model1(y,x);
  std::cout << model1.beta << std::endl;
  estimation::regression::hjlp model2(y,x,3);
  std::cout << model2.beta_ols(3) << std::endl;
  std::cout << model2.hac(3,2) << std::endl;

  estimation::regression::hjlp model3(y.block(1,0,9,1),x.block(1,0,9,1),y.block(0,0,9,1),3);
  std::cout << model3.beta_ols(3) << std::endl;
  std::cout << model3.hac(3,2) << std::endl;
  return 0;
}
