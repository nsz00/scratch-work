#include <Eigen/Dense>
#include <iostream>
#include <estimation/regression>
int main () {
  int T {10};
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> x(T,1);
  Eigen::Matrix<double,Eigen::Dynamic,Eigen::Dynamic> y(T,1);
  for (int i=0;i<T;i++) {
    x(i,0) = (double) i;
    y(i,0) = (double) (i*i);
  }
  estimation::regression::ols model(y,x);
  std::cout << model.beta << std::endl;
  std::cout << model.hac(0) << std::endl;
  return 0;
}
