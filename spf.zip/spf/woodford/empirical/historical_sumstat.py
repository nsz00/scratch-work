#Title: Historical Data Summary Statistics - "historical_sumstat.py"
#Description: This python script calculates summary statistics for each macrovariable the SPF forecasts. For each SPF variable, we produce summary statistics for the most recent vintage of data (rather than using real-time values). 
#Date Created: 02/09/2021

#Load packages and data
import numpy as np
import pandas as pd
from load_and_treat_spf_data import wd
from IPython.display import display
from statistics import mode
import pandas_datareader as pdr
import datetime
import statsmodels.formula.api as sm
import matplotlib.pyplot as plt

#use_historical() - Define function to produce a given SPF variable's most recent vintage data at a quarterly frequency; all data comes from the Philadelphia Fed            
def use_historical(series, growth_rate = False, monthly_hist = False, monthly_period = "mid", monthly_hybrid = False):
    '''
    Imports historical data of a given SPF variable and returns the Philadelphia Fed's most recent vintage data at a quarterly freuqnecy.
    - series = abbreviated SPF variable
    - growth_rate = return growth rate version of the SPF series
    - If monthly_hist = True, then the function treats the real-time historical data as monthly as opposed to quarterly values. This argument is necessary because the Philadelphia Fed reports only monthly - not quarterly- real-time data for some series. 
    - The argument monthly_period can take on three values: "start", "mid", and "end." If monthly_hist = True, then the function defines the quarter's real-time historical value using the first month in the quarter when monthly_period = "start". If monthly_period = "mid" or monthly_period = "end", the function defines the quarter's real-time historical value using the second or final month in the quarter, respectively. 
    - If monthly_hybrid = True, then the function assumes that the real-time historical data has monthly row values (release date) but quarterly column values (vintage date). This argument is necessary because for some series the Philadelphia Fed reports real-time data in this format. 
    '''

    #Because the Philadelphia Fed does not provide real-time historical data for the 3-month Treasury bill rate, we handle T-bill data separately from the other SPF series. First, consider non-T-bill SPF series.
    if (series != 'TBILL'):
        
        #Import SPF variable of interest's Philadelphia Fed real-time historical data
        historical = pd.read_excel(wd + 'Historical_{}.xlsx'.format(series))
        
        #The Philadelphia Fed reports the real-time data of some SPF variables at a quarterly frequency; others at a monthly frequency; and yet others at mixed frequency (i.e. a hybrid between monthly and quarterly frequencies). For consistency, we ensure all real-time data is quarterly. To do this, here we handle the case where the real-time data includes monthly values.
        if monthly_hist == True:
            
            #If the real-time dataset includes monthly release dates (rows), we convert the monthly release dates to a quarterly frequency by defining the SPF variable's value in a given release quarter as its value during the first month of that quarter if monthly_period = "start" (or second month of that quarter if monthly_period = "mid" or third month of the quarter if monthly_period = "end"). 
            historical['date_end'] = historical.DATE.str[-2:]
            if monthly_period == "start":
                month_pull = 1
            if monthly_period == "mid":
                month_pull = 2
            if monthly_period == "end":
                month_pull = 3
            historical = historical[(historical.date_end == str(month_pull).zfill(2)) | (historical.date_end == str(3 + month_pull).zfill(2)) | (historical.date_end == str(6 + month_pull).zfill(2)) | (historical.date_end == str(9 + month_pull).zfill(2))]
         
            #Next, we ensure that the real-time data's vintage dates (columns) follow a quarterly frequency.  
            if monthly_hybrid == False:
                #If the real-time data's rows and columns both originally follow a monthly frequency, we convert the monthly vintage dates to a quarterly frequency by (similar to above) defining the SPF variable's time series in a given vintage quarter as the time series corresponding to the first month of that quarter when monthly_period = "start" (or second month of that quarter when monthly_period = "mid" or third month of the quarter when monthly_period = "end"). Keep just these extracted monthly vintage dates and the release date variable.
                historical = historical[historical.columns[(historical.columns.str.endswith('M' + str(month_pull))) | (historical.columns.str.endswith('M' + str(3 + month_pull))) | (historical.columns.str.endswith('M' + str(6 + month_pull))) | (historical.columns.str.endswith('M' + str(9 + month_pull))) | (historical.columns.str.endswith('DATE'))]]
                
            else:
                #As mentioned above, some of the real-time data follows a hybrid format that includes release dates (rows) at a monthly frequency but vintage dates (columns) at a quarterly frequency. In the special case that the variable's real-time data follows this hybrid format, the real-time data's vintage dates (columns) already follow a quarterly frequency, and we simply drop the unnecessary "date_end" variable.  
                historical.drop(['date_end'], axis=1, inplace=True)
            
            #Define quarterly date variable
            historical['DATE'] = historical.DATE.str[:5] + 'Q' + ((((historical.DATE.str[-2:]).astype('int') + (3 - month_pull))/3).astype('str')).str[:1]
         
            #If the real-time data's columns also originally followed a monthly frequency, rename the columns from a monthly to quarterly string format
            if monthly_hybrid == False:
                nondate_col = historical.columns[~historical.columns.str.endswith('DATE')]
                for nondate in nondate_col:
                    series_len = nondate.rfind('M')
                    historical.rename(columns={nondate: (nondate[:series_len] + 'Q' + str((int(nondate[(series_len + 1):]) + (3 - month_pull))/3)[:1])}, inplace=True)
        
        #Reset dataframe index and extract only date column and most recent vintage
        historical = historical.reset_index(drop=True)
        hist_series = historical.iloc[:,np.r_[0, -1]]

    #Now, handle the case of the 3-month Treasury bill. Because the Philadelphia Fed does not provide real-time historical data for the 3-month Treasury bill rate, we pull the most recent vintage series from Fred. 
    else:
        #Pull most recent 3-month Treasury bill vintage from Fred
        TBILL = (pdr.DataReader('TB3MS', "fred", start = datetime.datetime(1934, 1,1), end = datetime.datetime.now())).reset_index()
        
        #Re-format Fred date
        TBILL['DATE'] = TBILL.DATE.astype('str')
        TBILL['DATE'] = TBILL.DATE.str[:4] + ':' + TBILL.DATE.str[-5:-3]
        
        #Because Fred's 3-month Treasury bill series exists at a monthly frequency, we convert (as above) the monthly release dates to a quarterly frequency by the 3-month Treasury bill value in a given release quarter as its value during the first month of that quarter if monthly_period = "start" (or second month of that quarter if monthly_period = "mid" or third month of the quarter if monthly_period = "end"). 
        historical = TBILL
        historical['date_end'] = historical.DATE.str[-2:]
        if monthly_period == "start":
            month_pull = 1
        if monthly_period == "mid":
            month_pull = 2
        if monthly_period == "end":
            month_pull = 3
        historical = historical[(historical.date_end == str(month_pull).zfill(2)) | (historical.date_end == str(3 + month_pull).zfill(2)) | (historical.date_end == str(6 + month_pull).zfill(2)) | (historical.date_end == str(9 + month_pull).zfill(2))]
        
        #Define quarterly date variable, reset index, and drop the now unnecessary "date_end" variable.  
        historical['DATE'] = historical.DATE.str[:5] + 'Q' + ((((historical.DATE.str[-2:]).astype('int') + (3 - month_pull))/3).astype('str')).str[:1]
        historical.drop(['date_end'], axis=1, inplace=True)
        historical = historical.reset_index(drop=True)
        hist_series = historical

    #If desired, convert non-date series to growth rate
    if (growth_rate == True):
        for col in hist_series.columns[1:]:
            hist_series['{}'.format(col)] = ((hist_series[col]/(hist_series[col].shift(periods=1))) - 1)*400
            
    #Rename vintage data variable
    hist_series.rename(columns={hist_series.columns[1]: '{}'.format(series)}, inplace=True)

    return hist_series    

def combine_historical():
    ##CPI Inflation
    cpi = use_historical("CPI", monthly_hist = True, monthly_hybrid = True, growth_rate = True)
    #3 month Treasury bill
    tbill = use_historical("TBILL")
    ##Unemployment rate
    unemp = use_historical("UNEMP", monthly_hist = True, monthly_hybrid = True)
    ##Real GDP growth
    rgdp = use_historical("RGDP", growth_rate = True)
    ##GDP deflator
    pgdp = use_historical("PGDP", growth_rate = True)
    ##Employment growth
    emp = use_historical("EMP", growth_rate = True, monthly_hist = True)
    ##Consumption growth
    rconsum = use_historical("RCONSUM", growth_rate = True)
    ##Residential structure growth
    rresinv = use_historical("RRESINV", growth_rate = True)
    ##Non-residential structure growth
    rnresin = use_historical("RNRESIN", growth_rate = True)

    #Merge together all historical dataframes
    merge_dfs = [cpi, tbill, unemp, rgdp, pgdp, emp, rconsum, rresinv, rnresin] 
    for hist in range(len(merge_dfs)):
        if hist == 0:
            hist_full = merge_dfs[hist]
        else:
            hist_full = pd.merge(hist_full, merge_dfs[hist], on = ['DATE'], how = 'outer')
    hist_full['Year'] = (hist_full['DATE'].str[:4]).astype('int64') 
    hist_full['Quarter'] = (hist_full['DATE'].str[-1:]).astype('int64') 
    hist_full['DATE_New'] = hist_full.apply(lambda x: pd.Period('%dQ%d' %(x.Year, x.Quarter), freq='Q'), axis=1)
    hist_full = hist_full.sort_values(by = 'DATE_New') 
    hist_full.drop(['DATE_New', 'Year', 'Quarter'], axis=1, inplace=True)
    hist_full = hist_full.reset_index(drop=True)
    return hist_full

def lhs_sumstat(df, start = '1981Q4', end = '2018Q1'):
    
    #Generate empty table to fill with summary statistics
    sum_df_list = []
    
    #Subset data to period of interest
    data_subset = df
    data_subset['numeric_date'] = ((data_subset.DATE.astype('str')).str.strip().str[:4]).astype('int') + (((data_subset.DATE.astype('str')).str.strip().str[-1]).astype('int') -1)*.25
    start_numeric = int(start[:4]) +  (int(start[-1]) -1)*.25
    end_numeric = int(end[:4]) +  (int(end[-1]) -1)*.25
    data_subset = data_subset[(data_subset.numeric_date >= start_numeric) & (data_subset.numeric_date <= end_numeric)]

    #Generate summary statistics of each LHS variable and append to summary table
    for col in data_subset.columns[1:-1]:
        data_subset['lag'] = data_subset[col].shift(1)
        result = sm.ols(formula="{} ~ lag".format(col), data=data_subset).fit()
        lhs_sum_stat = pd.DataFrame({'variable': col,
                                      'mean': [round(data_subset[col].mean(),2)],
                                      'median': [round(data_subset[col].median(),2)],
                                      'sd': [round(data_subset[col].std(),2)],
                                      'min': [round(data_subset[col].min(),2)],
                                      'max': [round(data_subset[col].max(),2)],
                                      'rho': [round(result.params[1],2)]})    
        sum_df_list = sum_df_list + [lhs_sum_stat]
    lhs_sumstat_table = (pd.concat(sum_df_list, axis = 0)).set_index(['variable'])
    return lhs_sumstat_table

def lhs_histograms(df, start = '1981Q4', end = '2018Q1'):
    
    #Subset data to period of interest
    data_subset = df
    data_subset['numeric_date'] = ((data_subset.DATE.astype('str')).str.strip().str[:4]).astype('int') + (((data_subset.DATE.astype('str')).str.strip().str[-1]).astype('int') -1)*.25
    start_numeric = int(start[:4]) +  (int(start[-1]) -1)*.25
    end_numeric = int(end[:4]) +  (int(end[-1]) -1)*.25
    data_subset = data_subset[(data_subset.numeric_date >= start_numeric) & (data_subset.numeric_date <= end_numeric)]
    
    var_names = data_subset.columns[1:]
    fig, axs = plt.subplots(3, 3, sharey=True, tight_layout=True, figsize=(11,11))
    fig.suptitle('SPF Variable Historical Distributions',  fontsize=16,x = .15, y=1.025)
    binwidth = 15
    axs[0, 0].hist(data_subset[var_names[0]], bins=binwidth)
    axs[0, 0].set_title(var_names[0])
    axs[0,1].hist(data_subset[var_names[1]], bins=binwidth)
    axs[0,1].set_title(var_names[1])
    axs[0,2].hist(data_subset[var_names[2]], bins=binwidth)
    axs[0,2].set_title(var_names[2])
    axs[1,0].hist(data_subset[var_names[3]], bins=binwidth)
    axs[1,0].set_title(var_names[3])    
    axs[1,1].hist(data_subset[var_names[4]], bins=binwidth)
    axs[1,1].set_title(var_names[4])    
    axs[1,2].hist(data_subset[var_names[5]], bins=binwidth)
    axs[1,2].set_title(var_names[5])    
    axs[2,0].hist(data_subset[var_names[6]], bins=binwidth) 
    axs[2,0].set_title(var_names[6])    
    axs[2,1].hist(data_subset[var_names[7]], bins=binwidth)
    axs[2,1].set_title(var_names[7])
    axs[2,2].hist(data_subset[var_names[8]], bins=binwidth)
    axs[2,2].set_title(var_names[8])
    return fig

historical_spf_var = combine_historical() 
lhs_sumstat_output = lhs_sumstat(historical_spf_var)
display(lhs_sumstat_output)      
lhs_hist_fig = lhs_histograms(historical_spf_var)

