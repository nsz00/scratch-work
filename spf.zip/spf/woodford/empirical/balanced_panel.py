#Title: Balanced Panel Results and Summary Statistics - "balanced_panel.py"
#Description: The dataset that we use to replicate Table 16 and Nordhaus is an unbalanced panel. This python script accomplishes two tasks. First, it attempts to replicate Table 16 and Nordhaus (focusing on t+3) using only a balanced panel. That is, we restrict our SPF panel to include just forecasters who report values for all four main variables of interest (CPI, TBILL, RGDP, UNEMP forecasts) in all periods. We show that no forecasters satisfy this condition, preventing us form replicating Table 16 and Nordhaus using an unbalanced panel. Second, we present summary statistics on the number of forecasts forecasters submit for various horizons and variables.
#Date Created: 02/09/2021


#Load packages and data
import numpy as np
import pandas as pd
import re
import scipy.stats as stats
import statsmodels.tools.tools as sm
from linearmodels import PanelOLS
from load_and_treat_spf_data import spf_full, wd
from IPython.display import display
import warnings
from statistics import mode
import datetime as dt
import pandas_datareader as pdr
import datetime
warnings.filterwarnings('ignore')


#####################################################################
#####################################################################
########################## Balanced Panel ###########################
#####################################################################
#####################################################################
#First, we attempt to replicate Table 16 and Nordhaus (focusing on t+3) using only a balanced panel. That is, we restrict our SPF panel to include just forecasters who report values for ALL four main variables of interest (CPI, TBILL, RGDP, and UNEMP forecasts) in ALL periods. 

#To do this, restrict our dataset to just horizon h=3 AND observations for which CPI, unemployment, 3-month Tbill, and real GDP growth rate forecasts are all non-missing.
spf_t3_4var = spf_full[(spf_full.hor == 3) & (spf_full.for_CPI.notnull()) & (spf_full.for_TBILL.notnull()) & (spf_full.for_RGDP.notnull()) & (spf_full.for_UNEMP.notnull())]

#Loop through all survey dates in our dataset. If a forecaster does not have a forecast for a given survey date, we drop them from the dataset. Iterating through all survey dates leaves us with just forecasters who forecast CPI, TBILL, RGDP, and UNEMP at h+3 in all periods, i.e. a balanced panel.
spf_t3_4var['balanced'] = 0
start_date = spf_t3_4var.survey_date.min()
end_date = spf_t3_4var.survey_date.max()
spf_t3_4var_dates = pd.period_range(start_date.to_timestamp(), end_date.to_timestamp(),freq='Q')
for single_date in range(len(spf_t3_4var_dates)):
    spf_t3_4var.loc[spf_t3_4var.survey_date == spf_t3_4var_dates[single_date], 'balanced'] =1
    spf_t3_4var['max_balanced'] = spf_t3_4var.groupby(['ID'])['balanced'].transform('max')
    spf_t3_4var = spf_t3_4var[spf_t3_4var.max_balanced == 1]
    spf_t3_4var['balanced'] = 0

#Print the number of forecasters that satisfy our balanced panel requirement. We see that the answer is zero.  
print("There are {} forecasters who provide t+3 CPI, TBILL, RGDP, and UNEMP forecasts for all survey dates.".format(spf_t3_4var.shape[0]))


#####################################################################
#####################################################################
#######################Forecaster Summary Stats######################
#####################################################################
#####################################################################
#We have seen that no forecasters satisfy our balanced panel requriment. To better understand the frequency of forecaster participation in our dataset, we now produce summary statistics on the number of forecasts forecasters submit for various horizons and variables. We begin by enumerating several combinations of horizons and variables. For each forecaster, we then calculate the number of non-missing observations the forecaster submits for that combination of horizons and variables. We call this number Z_i,c (representing the number of forecasts by forecaster i for horizon-variable combination c). Finally, we generate summary statistics of Z_i,c for each c and present the results in a table. 

#Fill the following dictionary with the horizon and variable combinations of interest. If we are interest in all horizons, set the dictionary entry to np.nan. Horizon-variable combination c refers to the cth horizon element in 'hor' and cth variable list in 'var'. 
balanced_dict = {
  'hor': [3,0,1,2,np.nan,3,3,3,3,3,0,0,0,0,0,np.nan],
  'var': [['CPI', 'TBILL', 'RGDP', 'UNEMP'],
          ['CPI', 'TBILL', 'RGDP', 'UNEMP'],
          ['CPI', 'TBILL', 'RGDP', 'UNEMP'],
          ['CPI', 'TBILL', 'RGDP', 'UNEMP'],
          ['CPI', 'TBILL', 'RGDP', 'UNEMP'],
          ['CPI'],
          ['TBILL'],
          ['RGDP'],
          ['UNEMP'],
          ['CPI', 'TBILL', 'RGDP', 'UNEMP','PGDP', 'EMP','RCONSUM','RRESINV','RNRESIN'],
          ['CPI'],
          ['TBILL'],
          ['RGDP'],
          ['UNEMP'],
          ['CPI', 'TBILL', 'RGDP', 'UNEMP','PGDP', 'EMP','RCONSUM','RRESINV','RNRESIN'],
          ['CPI', 'TBILL', 'RGDP', 'UNEMP','PGDP', 'EMP','RCONSUM','RRESINV','RNRESIN']]
}

#Generate empty table to fill with summary statistics
sum_df_list = []

#Loop through each horizon-variable combination. 
for spec in range(len(balanced_dict['hor'])):
    
    #If a combination's horizon is missing, set the horizon of interest to all horizons. Otherwise, set the horizon of interest to the combination's horizon and restrict the data to just the combination's horizon of interest. 
    if np.isnan(balanced_dict['hor'][spec]):
        hor_of_interest = 'All'
        spf_t3_4var = spf_full
    else:
        hor_of_interest = '{}'.format(balanced_dict['hor'][spec])
        spf_t3_4var = spf_full[spf_full.hor == balanced_dict['hor'][spec]] 
        #If a forecaster does not forecast the combination's horizon of interest but does forecast other horizons, we want their Z_i,c to be zero. To ensure this, we identify all forecasters who appear in our full dataset but do not forecast the combination's horizon of interest. For these forecasters, we create an observation for the first available survey date in the combination's horizon-restricted dataset, set their forecasts to missing, and set the survey horizon to the combination's horizon of interest. Next, we append these manufactured observations to the combination's horizon-restricted dataset. 
        unique_ID_list = spf_full[spf_full.groupby('ID').cumcount() == 0]
        merged_IDs = pd.merge(unique_ID_list, spf_t3_4var[['ID']], on = ['ID'], how = 'outer', indicator = True)
        non_h_IDS = merged_IDs[merged_IDs._merge == 'left only'] 
        non_h_IDS['CPI', 'TBILL', 'RGDP', 'UNEMP','PGDP', 'EMP','RCONSUM','RRESINV','RNRESIN'] = np.nan
        non_h_IDS.drop(columns=['_merge'])
        non_h_IDS.survey_date = spf_t3_4var.survey_date.min()
        non_h_IDS.hor = balanced_dict['hor'][spec]
        spf_t3_4var = spf_t3_4var.append(non_h_IDS)
        spf_t3_4var = spf_t3_4var.reset_index(drop=True)

        
    #Generate a string that when evaluated as code below conditions the dataset to just observations with non-missing forecasts for the variables of interest at a specific date 
    restrict_of_interest = '(spf_t3_4var.survey_date == spf_t3_4var_dates[single_date])'        
    for var in range(len(balanced_dict['var'][spec])):
        restrict_of_interest = restrict_of_interest + ' & (spf_full.for_{}.notnull())'.format(balanced_dict['var'][spec][var])             
    
    #Loop through all survey dates in our restricted dataset (i.e. the dataset restricted to include just the combination's horizons of interest). For each survey date, set the variable "complete_for" equal to one if a forecaster submits non-missing values for all of the combination's variables of interest. 
    spf_t3_4var['complete_for'] = 0
    start_date = spf_t3_4var.survey_date.min()
    end_date = spf_t3_4var.survey_date.max()
    spf_t3_4var_dates = pd.period_range(start_date.to_timestamp(), end_date.to_timestamp(),freq='Q')
    for single_date in range(len(spf_t3_4var_dates)):
        exec('spf_t3_4var.loc[({}), "complete_for"] = 1'.format(restrict_of_interest))
    
    #Create "variable of interest" string for summary stats table
    if balanced_dict['var'][spec] == ['CPI', 'TBILL', 'RGDP', 'UNEMP','PGDP', 'EMP','RCONSUM','RRESINV','RNRESIN']:
        var_of_interest = "All"
    else:
        var_of_interest = ", ".join(balanced_dict['var'][spec])
    
    #By summing variable "complete_for", calculate the number of forecasted dates statisfying combination c for each forecaster i (i.e. Z_i,c)
    for_by_ID = spf_t3_4var.groupby(['ID']).agg(total_forecasted_dates = pd.NamedAgg(column = 'complete_for', aggfunc='sum'))
    #In order to determine the total number of forecasters who submit non-missing forecasts for combination c, initalize variable "non_zero_for" so that it equals zero if the forecaster did not submit a forecast statisfying combination c and 1 otherwise. 
    for_by_ID['non_zero_for'] = 0
    for_by_ID.loc[(for_by_ID.total_forecasted_dates > 0), 'non_zero_for'] = 1
    
    #Generate summary statistics of Z_i,c and append to summary table
    for_by_ID_sum = pd.DataFrame({'horizon': hor_of_interest, 
                                  'variable': var_of_interest,
                                  'mean': [round(for_by_ID.total_forecasted_dates.mean(),2)],
                                  'median': [round(for_by_ID.total_forecasted_dates.median(),2)],
                                  'mode': [round(mode(for_by_ID.total_forecasted_dates),2)],
                                  'sd': [round(for_by_ID.total_forecasted_dates.std(),2)],
                                  'min': [for_by_ID.total_forecasted_dates.min()],
                                  'max': [for_by_ID.total_forecasted_dates.max()],
                                  'N Forecasts': [for_by_ID.total_forecasted_dates.sum()],
                                  'N Forecasters': [for_by_ID.non_zero_for.sum()],
                                  'Total Forecasters': [for_by_ID.total_forecasted_dates.count()]})    
    sum_df_list = sum_df_list + [for_by_ID_sum]

#Display Z_i summary table     
forecast_period_sample = (pd.concat(sum_df_list, axis = 0)).set_index(['horizon','variable'])
display(forecast_period_sample)