import numpy as np
import pandas as pd
import re
import scipy.stats as stats
import statsmodels.tools.tools as sm
from linearmodels import PanelOLS
from load_and_treat_spf_data import spf_full 

def reg_table2(data, series, h = 0, table = True, start = '1981Q4', end = '2018Q1', fe = True, constant = True, se_type = 'kernel', remove_var = ['lag_for_PGDP', 'lag_for_EMP', 'lag_for_RCONSUM', 'lag_for_RRESINV', 'lag_for_RNRESIN']):
    '''
    Using SPF data, runs regressions and produces output for Fuhrer (2018) Table 2.
    - h represents the desired forecast horizon
    - If table = True, the function returns a dataframe of relevant Table 2 statistics as opposed to the standard linearmodels output 
    - By default, the regression computes Driscoll and Kraay standard errors. 
    - The argument remove_var includes the names of variables to remove from the regression model. When remove_var is empty, the regressions control for the lagged values of all nine macrovariables. By default, we only control for lagged unemployment, output growth, and the Treasury bill rate. 
    '''
    #Identify columns in our data that include the forecaster's real-time lagged forecast of each macrovariable besides our series of interest
    non_series_col = data.columns[data.columns.str.startswith('lag_for_') & ~data.columns.str.endswith('lag_for_{}'.format(series))]
    #Of these, only keep columns of real-time lagged forecasts from macrovariables not in array remove_var
    non_series_col = [i for i in non_series_col.values.tolist() if i not in remove_var]
    #Indicate whether any real-time lagged forecasts of macrovariables besides our series of interest will enter into the regression 
    if len(non_series_col) > 0:
        other_var = "Y"
    else:
        other_var = ""

    #Define exogenous variables: previous forecast, median of the previous forecast, real-time lagged forecast, and optional controls
    exog_vars = ['prev_for_{}'.format(series),'median_prev_for_{}'.format(series),'lag_for_{}'.format(series)] + non_series_col
    #Remove variables in array remove_var from exogenous variables
    exog_vars = [i for i in exog_vars if i not in remove_var]

    #Subset the data to the period and horizon of interest
    data_subset = data
    data_subset['numeric_date'] = ((data_subset.survey_date.astype('str')).str.strip().str[:4]).astype('int') + (((data_subset.survey_date.astype('str')).str.strip().str[-1]).astype('int') -1)*.25
    start_numeric = int(start[:4]) +  (int(start[-1]) -1)*.25
    end_numeric = int(end[:4]) +  (int(end[-1]) -1)*.25
    data_subset = data_subset[(data_subset.numeric_date >= start_numeric) & (data_subset.numeric_date <= end_numeric) & (data_subset.hor == h)]

    #Set multi-level index 
    data_subset = data_subset.set_index(['ID', 'numeric_date'])
    
    #If desired, add constant
    if constant:
        exog = sm.add_constant(data_subset[exog_vars])
    else: 
        exog = data_subset[exog_vars]

    #Specify regression model, adding fixed effects if desired	
    if fe:
        mod = PanelOLS(data_subset['for_{}'.format(series)], exog, entity_effects=True)
    else: 
        mod = PanelOLS(data_subset['for_{}'.format(series)], exog, entity_effects=False)
    reg = mod.fit(cov_type=se_type)

    #If table=True, return the output as a dataframe rather than a linearmodels object
    if table:
        if constant:
            param_start = 1
        else: 
            param_start = 0

	#Set variable names
        formal_series = {
            "CPI": "CPI Inflation",
            "UNEMP": "Unemployment Rate",
            "TBILL": "3-mo. Tbill Rate",
            "RGDP": "Real GDP Growth",
            "PGDP": "GDP Deflator",
            "EMP": "Payroll Employment Growth",
            "RCONSUM": "Consumption Growth",
            "RRESINV": "Nonresidential Structures Growth",
            "RNRESIN": "Residential Structures Growth"}

	#Collect coefficients of interest, their p-values, and the number of observations
	#If producing univariate regression results, use the following table
        if (('median_prev_for_{}'.format(series) in remove_var) & ('lag_for_{}'.format(series) in remove_var) & (other_var == '')):
            coef1 = reg.params[(0 + param_start)] 
            p1 = reg.pvalues[(0 + param_start)] 
            n = reg.nobs

	    #Calculate p-value for Table 2 efficiency test
            se1 = reg.std_errors[(0 + param_start)] 
            tt1 = (coef1 - 1)/se1
            eff_test1 = stats.t.sf(np.abs(tt1), n-1)*2

            #Create regression table
            reg_data = {'entry':['', r'$x^i_{t+k,t-1}$', '',
                         r'Test: $a=1 (p)$', 
                         'Observations'],
                    formal_series[series]:[ r'$k={}$'.format(str(int(h))),
                        r'{}'.format(str(round(coef1, 2)).ljust(4,'0')),
                        r'{}'.format('(' + str(round(p1, 3)).ljust(5,'0') + ')'),
                        '{}'.format(str(round(eff_test1, 3)).ljust(5,'0')),
                        str(int(n))]
                   }

	#If producing multivariate regression results, use the following table		   
        else: 
            coef1 = reg.params[(0 + param_start)] 
            coef2 = reg.params[(1 + param_start)] 
            coef3 = reg.params[(2 + param_start)] 
            p1 = reg.pvalues[(0 + param_start)] 
            p2 = reg.pvalues[(1 + param_start)] 
            p3 = reg.pvalues[(2 + param_start)] 
            n = reg.nobs

	    #Calculate p-value for Table 2 efficiency test
            se1 = reg.std_errors[(0 + param_start)] 
            tt1 = (coef1 - 1)/se1
            eff_test1 = stats.t.sf(np.abs(tt1), n-1)*2

            #Create regression table
            reg_data = {'entry':['', r'$x^i_{t+k,t-1}$', 
                         '',
                         r'$Median(x^i_{t+k,t-1})$',
                         '',
                         r'$x^i_{t-1}$', '', 'Other vbls.', r'Test: $a=1 (p)$', 
                         'Observations'],
                    formal_series[series]:[ r'$k={}$'.format(str(int(h))),
                        r'{}'.format(str(round(coef1, 2)).ljust(4,'0')),
                        r'{}'.format('(' + str(round(p1, 3)).ljust(5,'0') + ')'),
                        r'{}'.format(str(round(coef2, 2)).ljust(4,'0')),
                        r'{}'.format('(' + str(round(p2, 3)).ljust(5,'0') + ')'),
                        r'{}'.format(str(round(coef3, 2)).ljust(4,'0')),
                        r'{}'.format('(' + str(round(p3, 3)).ljust(5,'0') + ')'),
                        other_var,
                        '{}'.format(str(round(eff_test1, 3)).ljust(5,'0')),
                        str(int(n))]
                   }
        reg = pd.DataFrame(reg_data) 
        return reg
    else:
        return reg


def make_table2_univariate(data, fe = True, add_comment = ' (univariate)'):
    '''
    Using the SPF data, generates latex table for univariate version of Fuhrer (2018) Table 2.
    '''
    #Specify series of interest and which variables to remove when no additional controls are included
    frames_col = []
    macro_list = ["CPI", "TBILL", "RGDP", "RGDP"]
    no_var_list = ['lag_for_CPI', 'lag_for_TBILL', 'lag_for_RGDP','lag_for_RGDP']

    #Set variable names
    formal_series = {
        "CPI": "CPI Inflation",
        "UNEMP": "Unemployment Rate",
        "TBILL": "3-mo. Tbill Rate",
        "RGDP": "Real GDP Growth",
        "PGDP": "GDP Deflator",
        "EMP": "Payroll Employment Growth",
        "RCONSUM": "Consumption Growth",
        "RRESINV": "Nonresidential Structures Growth",
        "RNRESIN": "Residential Structures Growth"}

    #Set table title	
    title = r'\captionsetup{justification=centering}' + '\n' + r'\caption*{\normalsize \textbf{Table 2' + add_comment + r': Test of revision efficiency, all variables, all horizons}\\' + '\n' + r'$x^i_{t+k,t} = ax^i_{t+k,t-1}$}'

    #Loop through each series of interest
    for var in range(0, len(macro_list)):
        macro = macro_list[var]
        no_var = ['median_prev_for_{}'.format(macro)] + no_var_list
	
	#Column 1 regression
        if (var % 2) == 0:
            frames_col = frames_col + [reg_table2(data, macro, h=0, fe = fe, constant = False, remove_var = no_var).rename(columns={'entry': ''}), 
            reg_table2(data, macro, h=1, fe = fe, constant = False, remove_var = no_var).drop(columns = ['entry']).rename(columns={formal_series[macro]: ''}), 
            reg_table2(data, macro, h=2, fe = fe, constant = False, remove_var = no_var).drop(columns = ['entry']).rename(columns={formal_series[macro]: ''}), 
            reg_table2(data, macro, h=3, fe = fe, constant = False, remove_var = no_var).drop(columns = ['entry']).rename(columns={formal_series[macro]: ''})]
	#Column 2 regression
        else: 
            frames_col = frames_col + [reg_table2(data, macro, h=0, fe = fe, constant = False, remove_var = no_var).drop(columns = ['entry']), 
            reg_table2(data, macro, h=1, fe = fe, constant = False, remove_var = no_var).drop(columns = ['entry']).rename(columns={formal_series[macro]: ''}), 
            reg_table2(data, macro, h=2, fe = fe, constant = False, remove_var = no_var).drop(columns = ['entry']).rename(columns={formal_series[macro]: ''}), 
            reg_table2(data, macro, h=3, fe = fe, constant = False, remove_var = no_var).drop(columns = ['entry']).rename(columns={formal_series[macro]: ''})]
	    #Produce latex output
            if (var == (len(macro_list) -1)) & (var == 1):
                frames_row = (pd.concat(frames_col, axis = 1)).to_latex(index=False, escape=False, column_format='lcccccccc', multicolumn_format = 'c', bold_rows = True).replace(r'\begin{tabular}{lcccccccc}',r'\begin{footnotesize}' +'\n' + r'\setlength{\tabcolsep}{1pt}' +'\n' + r'\begin{longtable}{lcccccccc}' + '\n' + title + '\n' + r'\endfirsthead' + '\n' + '\endhead' + '\n' + '\endfoot' + '\n' + '\endlastfoot').replace(r'\end{tabular}',r'\end{longtable}' + '\n' + r'\end{footnotesize}')
            elif var == 1:
                frames_row = (pd.concat(frames_col, axis = 1)).to_latex(index=False, escape=False, column_format='lcccccccc', multicolumn_format = 'c', bold_rows = True).replace(r'\bottomrule',r'\midrule').replace(r'\end{tabular}','').replace(r'\begin{tabular}{lcccccccc}',r'\begin{footnotesize}' +'\n' + r'\setlength{\tabcolsep}{1pt}' +'\n' + r'\begin{longtable}{lcccccccc}' + '\n' + title + '\n' + r'\endfirsthead' + '\n' + '\endhead' + '\n' + '\endfoot' + '\n' + '\endlastfoot')
            elif var == (len(macro_list) -1):
                frames_row = frames_row + (pd.concat(frames_col, axis = 1)).to_latex(index=False, escape=False, column_format='lcccccccc', multicolumn_format = 'c', bold_rows = True).replace(r'\begin{tabular}{lcccccccc}',r'').replace(r'\toprule','').replace(r'\end{tabular}',r'\end{longtable}' + '\n' + r'\end{footnotesize}')           
            else: 
                frames_row = frames_row + (pd.concat(frames_col, axis = 1)).to_latex(index=False, escape=False, column_format='lcccccccc', multicolumn_format = 'c', bold_rows = True).replace(r'\bottomrule',r'\midrule').replace(r'\end{tabular}','').replace(r'\begin{tabular}{lcccccccc}',r'').replace(r'\toprule','')
            frames_col = []
    return frames_row

tb2_univariate = make_table2_univariate(spf_full)
print(tb2_univariate)