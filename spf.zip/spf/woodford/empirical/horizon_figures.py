#Title: Horizon Figures - "horizon_figures.py"
#Description: This python script creates figures that display Fuhrer Table 16 and Nordhaus regression coefficients across horizons.
#Date Created: 03/12/2021

import numpy as np
import pandas as pd
import re
import scipy.stats as stats
import statsmodels.tools.tools as sm
from linearmodels import PanelOLS
from load_and_treat_spf_data import spf_full
from IPython.display import display
from table_16 import reg_table16
from table_nordhaus import reg_nordhaus
import warnings
import matplotlib.pyplot as plt
warnings.filterwarnings('ignore')


#horizon_coef() - Function to produce a dataframe of regression coefficients for Fuhrer Table 16 and Nordhaus. Note: To allow h=3, we also produce a version of Nordhaus with only the forecaster's previous forecast (as opposed to also including the forecaster's previous forecaster two periods ago); to indicate a univariate Nordhaus regression (as opposed to bivariate), we create a dataframe column "coef" which we set to 1 in the univariate case and 2 in the bivariate case.
def horizon_coef():
    #Initialize empty dataframe to fill with regression coefficients
    reg_col = ['reg', 'var', 'num_regressors', 'coef', 'hor', 'point', 'lower', 'upper']
    reg_output = pd.DataFrame(columns= reg_col)
    
    #For both Fuhrer Table 16 and Nordhaus, generate coefficients at all horizons for CPI and RGDP SPF variables. For Nordhaus, we consider both univariate and bivariate regressions. 
    for reg in ['table16', 'nordhaus']:
        for var in ['CPI', 'RGDP']:
            for hor in [0, 1, 2, 3]:
                for coef_num in [2,1]: 
                    
                    #Add controls
                    col_list = ['for_TBILL', 'for_UNEMP']  
                    if var == 'CPI':
                        col_list = col_list + ['for_RGDP']
                    elif var == 'RGDP':
                        col_list = col_list + ['for_CPI']
                        
                    #Run regressions    
                    if reg == 'table16':
                        #In the case of Table 16, we only consider the bivariate regression, so skip if in univariate loop iteration.
                        if coef_num == 1:
                            continue
                        else:
                            #Run Fuhrer Table 16 regression with controls and fixed effects
                            full_output = reg_table16(spf_full, var, h=hor, constant = False, fe_controls_row = False, fe = True , include_var = col_list, return_se_point = True)
                    
                    #
                    elif reg == 'nordhaus':
                        #Because the bivariate Nordhaus specification includes the forecaster's forecast from two periods ago, the data only allows regressions for horizons 0-2. Accordingly, skip if horizon = 3 and in bivariate Nordhaus loop iteration. 
                        if ((hor == 3) & (coef_num == 2)):
                            continue
                        else:
                            #Run Nordhaus bivariate regression with controls and fixed effects
                            if coef_num == 2:
                                full_output = reg_nordhaus(spf_full, var, h=hor, constant = False, fe_controls_row = False, fe = True, include_var = col_list, return_se_point = True)
                            #Run Nordhaus univariate regression with controls and fixed effects
                            elif coef_num == 1:
                                full_output = reg_nordhaus(spf_full, var, h=hor, constant = False, fe_controls_row = False, fe = True, include_var = col_list, return_se_point = True, remove_var = ['prev2_for_{}'.format(var)])  
                                
                    #Collect standard errors/point estimates and calculate 90% confidence intervals  
                    #Append the results to the coefficent dataframe, ignoring the second coefficient when considering the univariate case
                    std_errors = full_output[1]
                    std_error_a = std_errors[0]
                    points = full_output[2]
                    point_a = points[0]
                    lower_a = point_a - std_error_a*1.645
                    upper_a = point_a + std_error_a*1.645
                    a_row = np.array([reg, var, coef_num, 'a', hor, point_a, lower_a, upper_a])
                    reg_output = reg_output.append(pd.DataFrame(a_row.reshape(1,len(reg_col)), columns = reg_col), ignore_index=True)
                    if coef_num == 2:
                        std_error_b = std_errors[1]
                        point_b = points[1]   
                        lower_b = point_b - std_error_b*1.645
                        upper_b = point_b + std_error_b*1.645                    
                        b_row = np.array([reg, var, coef_num, 'b', hor, point_b, lower_b, upper_b])
                        reg_output = reg_output.append(pd.DataFrame(b_row.reshape(1,len(reg_col)), columns = reg_col), ignore_index=True)
    #Convert dataframe variables to numeric and calculate one-sided error band length
    reg_output['num_regressors'] = pd.to_numeric(reg_output['num_regressors']) 
    reg_output['point'] = pd.to_numeric(reg_output['point'])
    reg_output['lower'] = pd.to_numeric(reg_output['lower'])
    reg_output['upper'] = pd.to_numeric(reg_output['upper'])
    reg_output['error_length'] = (reg_output['upper'] - reg_output['lower'])/2
    return reg_output

#Table 16
#horizon_table16() - Function to plot Fuhrer Table 16 coefficients by horizon. 
'''
    - reg_output = dataframe of Fuhrer Table 16 and Nordhaus coefficients in the format produced by horizon_coef() 
    - to_pdf  = when True saves plot as pdf; default is False
    - file = name for pdf if to_pdf == True; default is "table16_coef.pdf" 
'''
def horizon_table16(reg_output, to_pdf = False, file = "table16_coef.pdf"):
    #Create 2 x 2 grid
    fig, axs = plt.subplots(2, 2, figsize=(9,9))
    fig.suptitle('Fuhrer (2019) Table 16',  fontsize=16,x = .15, y=1.025)
    
    #Subplot 1 - CPI coefficent 'a'
    reg_sample = reg_output[(reg_output['reg'] == 'table16') & (reg_output['coef'] == 'a') & (reg_output['var'] == 'CPI') & (reg_output['num_regressors'] == 2)]
    axs[0, 0].axhline(y=0, color='r', linestyle=':')
    axs[0, 0].errorbar(reg_sample['hor'], reg_sample['point'], yerr= reg_sample['error_length'], fmt="o")
    axs[0, 0].set_title('$x^i_{t+k,t}(a)$')
    
    #Subplot 2 - CPI coefficent 'b'
    reg_sample = reg_output[(reg_output['reg'] == 'table16') & (reg_output['coef'] == 'b') & (reg_output['var'] == 'CPI') & (reg_output['num_regressors'] == 2)]
    axs[0, 1].axhline(y=0, color='r', linestyle=':')
    axs[0, 1].errorbar(reg_sample['hor'], reg_sample['point'], yerr= reg_sample['error_length'], fmt="o")
    axs[0, 1].set_title('$x^i_{t+k,t-1}(b)$')
    
    #Subplot 3- RGDP coefficent 'a'
    reg_sample = reg_output[(reg_output['reg'] == 'table16') & (reg_output['coef'] == 'a') & (reg_output['var'] == 'RGDP') & (reg_output['num_regressors'] == 2)]
    axs[1, 0].axhline(y=0, color='r', linestyle=':')
    axs[1, 0].errorbar(reg_sample['hor'], reg_sample['point'], yerr= reg_sample['error_length'], fmt="o")
    axs[1, 0].set_title('$x^i_{t+k,t}(a)$')
    
    #Subplot 4- RGDP coefficent 'b'
    reg_sample = reg_output[(reg_output['reg'] == 'table16') & (reg_output['coef'] == 'b') & (reg_output['var'] == 'RGDP') & (reg_output['num_regressors'] == 2)]
    axs[1, 1].axhline(y=0, color='r', linestyle=':')
    axs[1, 1].errorbar(reg_sample['hor'], reg_sample['point'], yerr= reg_sample['error_length'], fmt="o")
    axs[1, 1].set_title('$x^i_{t+k,t-1}(b)$')
    
    #Add subtitles and adjust spacing
    plt.figtext(0.5 +.02,0.98, "CPI Inflation", ha="center", va="top", fontsize=14)
    plt.figtext(0.5 + .023,0.4875, "RGDP Growth", ha="center", va="top", fontsize=14)
    fig.tight_layout()
    fig.subplots_adjust(top = .93, hspace = .25, wspace = .3)
    #Save and plot
    if to_pdf == True:
        plt.savefig(file, bbox_inches='tight')
    return fig


#Nordhaus
#horizon_nordhaus() - Function to plot bivariate nordhaus by horizon. 
'''
    - reg_output = dataframe of Fuhrer Table 16 and Nordhaus coefficients in the format produced by horizon_coef() 
    - to_pdf  = when True saves plot as pdf; default is False
    - file = name for pdf if to_pdf == True; default is "nordhaus_coef.pdf" 
'''
def horizon_nordhaus(reg_output, to_pdf = False, file = "nordhaus_coef.pdf"):
    #Create 2 x 2 grid    
    fig, axs = plt.subplots(2, 2, figsize=(9,9))
    fig.suptitle('Nordhaus (1987) Table',  fontsize=16,x = .15, y=1.025)
    
    #Subplot 1 - CPI coefficent 'a'
    reg_sample = reg_output[(reg_output['reg'] == 'nordhaus') & (reg_output['coef'] == 'a') & (reg_output['var'] == 'CPI') & (reg_output['num_regressors'] == 2)]
    axs[0, 0].axhline(y=0, color='r', linestyle=':')
    axs[0, 0].errorbar(reg_sample['hor'], reg_sample['point'], yerr= reg_sample['error_length'], fmt="o")
    axs[0, 0].set_title('$x^i_{t+k,t-1}(a)$')
    
    #Subplot 2 - CPI coefficent 'b'
    reg_sample = reg_output[(reg_output['reg'] == 'nordhaus') & (reg_output['coef'] == 'b') & (reg_output['var'] == 'CPI') & (reg_output['num_regressors'] == 2)]
    axs[0, 1].axhline(y=0, color='r', linestyle=':')
    axs[0, 1].errorbar(reg_sample['hor'], reg_sample['point'], yerr= reg_sample['error_length'], fmt="o")
    axs[0, 1].set_title('$x^i_{t+k,t-2}(b)$')
    
    #Subplot 3 - RGDP coefficent 'a'
    reg_sample = reg_output[(reg_output['reg'] == 'nordhaus') & (reg_output['coef'] == 'a') & (reg_output['var'] == 'RGDP') & (reg_output['num_regressors'] == 2)]
    axs[1, 0].axhline(y=0, color='r', linestyle=':')
    axs[1, 0].errorbar(reg_sample['hor'], reg_sample['point'], yerr= reg_sample['error_length'], fmt="o")
    axs[1, 0].set_title('$x^i_{t+k,t-1}(a)$')
    
    #Subplot 4 - RGDP coefficent 'b'
    reg_sample = reg_output[(reg_output['reg'] == 'nordhaus') & (reg_output['coef'] == 'b') & (reg_output['var'] == 'RGDP') & (reg_output['num_regressors'] == 2)]
    axs[1, 1].axhline(y=0, color='r', linestyle=':')
    axs[1, 1].errorbar(reg_sample['hor'], reg_sample['point'], yerr= reg_sample['error_length'], fmt="o")
    axs[1, 1].set_title('$x^i_{t+k,t-2}(b)$')
    
    #Add subtitles and adjust spacing    
    plt.figtext(0.5 +.02,0.98, "CPI Inflation", ha="center", va="top", fontsize=14)
    plt.figtext(0.5 + .023,0.4875, "RGDP Growth", ha="center", va="top", fontsize=14)
    fig.tight_layout()
    fig.subplots_adjust(top = .93, hspace = .25, wspace = .3)
    
    #Save and plot
    if to_pdf == True:
        plt.savefig(file, bbox_inches='tight')
    return fig

#Nordhaus Univariate 
#horizon_nordhaus_uni() - Function to plot bivariate nordhaus by horizon. 
'''
    - reg_output = dataframe of Fuhrer Table 16 and Nordhaus coefficients in the format produced by horizon_coef() 
    - to_pdf  = when True saves plot as pdf; default is False
    - file = name for pdf if to_pdf == True; default is "nordhaus_uni_coef.pdf" 
'''
def horizon_nordhaus_uni(reg_output, to_pdf = False, file = "nordhaus_uni_coef.pdf"):
    #Create 1 x 2 grid        
    fig, axs = plt.subplots(1, 2, figsize=(9,9/2 + .5))
    fig.suptitle('Nordhaus (1987) Table - $x^i_{t+k,t-1}(a)$ Regressor Only',  fontsize=16,x = .15, y=1.025)
    
    #Subplot 1 - CPI coefficent 'a'
    reg_sample = reg_output[(reg_output['reg'] == 'nordhaus') & (reg_output['coef'] == 'a') & (reg_output['var'] == 'CPI') & (reg_output['num_regressors'] == 1)]
    axs[0].axhline(y=0, color='r', linestyle=':')
    axs[0].errorbar(reg_sample['hor'], reg_sample['point'], yerr= reg_sample['error_length'], fmt="o")
    axs[0].set_title('$x^i_{t+k,t-1}(a)$')
    
    #Subplot 2 - RGDP coefficent 'a'
    reg_sample = reg_output[(reg_output['reg'] == 'nordhaus') & (reg_output['coef'] == 'a') & (reg_output['var'] == 'RGDP') & (reg_output['num_regressors'] == 1)]
    axs[1].axhline(y=0, color='r', linestyle=':')
    axs[1].errorbar(reg_sample['hor'], reg_sample['point'], yerr= reg_sample['error_length'], fmt="o")
    axs[1].set_title('$x^i_{t+k,t-1}(a)$')
    
    #Add subtitles and adjust spacing    
    plt.figtext(0.25 +.02,0.92, "CPI Inflation", ha="center", va="top", fontsize=14)
    plt.figtext(0.75 + .023,0.92, "RGDP Growth", ha="center", va="top", fontsize=14)
    fig.tight_layout()
    fig.subplots_adjust(top = .82, hspace = .25, wspace = .3)
    
    #Save and plot
    if to_pdf == True:
        plt.savefig(file, bbox_inches='tight')
    return fig

#Create plots
horizon_df = horizon_coef()
table16_fig = horizon_table16(horizon_df, to_pdf = True)
table16_fig.show()
nordhaus_fig = horizon_nordhaus(horizon_df, to_pdf = True)
nordhaus_fig.show()
nordhaus_uni_fig = horizon_nordhaus_uni(horizon_df, to_pdf = True)
nordhaus_uni_fig.show()