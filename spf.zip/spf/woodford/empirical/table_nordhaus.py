import numpy as np
import pandas as pd
import re
import scipy.stats as stats
import statsmodels.tools.tools as sm
from linearmodels import PanelOLS
from load_and_treat_spf_data import spf_full
from IPython.display import display
import warnings
warnings.filterwarnings('ignore')

def reg_nordhaus(data, series, h = 0, table = True, start = '1981Q4', end = '2018Q1', fe = True, constant = True, se_type = 'kernel', include_var = [], remove_var = [], fe_controls_row = False, return_se_point = False):
    '''
    Using SPF data, runs regressions and produces output for replicating Nordhaus regressions.
    - h represents the desired forecast horizon
    - If table = True, the function returns a dataframe of relevant Nordhaus statistics as opposed to the standard linearmodels output 
    - By default, the regression computes Driscoll and Kraay standard errors. 
    - The argument include_var specifies the names of variables to add as additional controls. 
    '''
    #Define exogenous variables: current forecast and  previous forecast
    exog_vars = ['prev_for_{}'.format(series), 'prev2_for_{}'.format(series)] + include_var
    #Remove variables in array remove_var from exogenous variables
    exog_vars = [i for i in exog_vars if i not in remove_var]

    #Subset the data to the period and horizon of interest
    data_subset = data
    data_subset['numeric_date'] = ((data_subset.survey_date.astype('str')).str.strip().str[:4]).astype('int') + (((data_subset.survey_date.astype('str')).str.strip().str[-1]).astype('int') -1)*.25
    start_numeric = int(start[:4]) +  (int(start[-1]) -1)*.25
    end_numeric = int(end[:4]) +  (int(end[-1]) -1)*.25
    data_subset = data_subset[(data_subset.numeric_date >= start_numeric) & (data_subset.numeric_date <= end_numeric) & (data_subset.hor == h)]
    
    #Set multi-level index 
    data_subset = data_subset.set_index(['ID', 'numeric_date'])
    
    #If desired, add constant
    if constant:
        exog = sm.add_constant(data_subset[exog_vars])
    else: 
        exog = data_subset[exog_vars]

    #Specify regression model, adding fixed effects if desired
    if fe:
        mod = PanelOLS(data_subset['revision_{}'.format(series)], exog, entity_effects=True)
    else: 
        mod = PanelOLS(data_subset['revision_{}'.format(series)], exog, entity_effects=False)
    reg = mod.fit(cov_type=se_type)

    #If table=True, return the output as a dataframe rather than a linearmodels object
    if table:
        if constant:
            param_start = 1
        else: 
            param_start = 0

    #Set variable names
        formal_series = {
            "CPI": "CPI Inflation",
            "UNEMP": "Unemployment Rate",
            "TBILL": "3-mo. Tbill Rate",
            "RGDP": "Real GDP Growth",
            "PGDP": "GDP Deflator",
            "EMP": "Payroll Employment Growth",
            "RCONSUM": "Consumption Growth",
            "RRESINV": "Nonresidential Structures Growth",
            "RNRESIN": "Residential Structures Growth"}

        if ((fe == True) & (len(include_var) > 0)):
            fc = 'Y'
        elif ((fe == True) & (len(include_var) == 0)):
            fc = 'FE Only'
        elif ((fe == False) & (len(include_var) > 0)):
            fc = 'Ctrls Only'
        else:
            fc = 'N'

    #If both prev_for and prev2_for regressors included, use the following table
        if 'prev2_for_{}'.format(series) in exog_vars:
           if fe_controls_row == False:
                #Collect coefficients of interest, their p-values, their standard errors, and the number of observations
                coef1 = reg.params[(0 + param_start)] 
                coef2 = reg.params[(1 + param_start)] 
                se1 = reg.std_errors[(0 + param_start)]
                se2 = reg.std_errors[(1 + param_start)] 
                p1 = reg.pvalues[(0 + param_start)] 
                p2 = reg.pvalues[(1 + param_start)] 
                n = reg.nobs
                r2 = reg._r2
                cov = reg.cov.iloc[(0 + param_start),(1 + param_start)]
                std_errors = [se1, se2]
                points = [coef1, coef2]
                
        #Calculate p-value for the Nordhaus efficiency test
                tt1 = (coef1 + coef2)/(((se1**2) + (se2**2) + 2*cov)**(.5))
                eff_test1 = stats.t.sf(np.abs(tt1), n-2)*2

        #Create regression table
                reg_data = {'entry':['', r'$x^i_{t+k,t-1}(a)$', 
                         '',
                         r'$x^i_{t+k,t-2}(b)$',
                         '', r'Test: $a+b=0?$',
                         'Observations',
                         r'$R^2$'],
            formal_series[series]:[ r'$t+{}$'.format(str(int(h))),
                         r'{}'.format(str(round(coef1, 2)).ljust(4,'0')),
                         r'{}'.format('(' + str(round(p1, 3)).ljust(5,'0') + ')'),
                         r'{}'.format(str(round(coef2, 2)).ljust(4,'0')),
                         r'{}'.format('(' + str(round(p2, 3)).ljust(5,'0') + ')'),
                         '{}'.format(str(round(eff_test1, 3)).ljust(5,'0')),
                         str(int(n)), r'{}'.format(str(round(r2, 2)).ljust(4,'0'))]
            }
           else:
                #Collect coefficients of interest, their p-values, their standard errors, and the number of observations
                coef1 = reg.params[(0 + param_start)] 
                coef2 = reg.params[(1 + param_start)] 
                se1 = reg.std_errors[(0 + param_start)]
                se2 = reg.std_errors[(1 + param_start)] 
                p1 = reg.pvalues[(0 + param_start)] 
                p2 = reg.pvalues[(1 + param_start)] 
                n = reg.nobs
                r2 = reg._r2
                cov = reg.cov.iloc[(0 + param_start),(1 + param_start)]
                std_errors = [se1, se2]
                points = [coef1, coef2]
                
        #Calculate p-value for the Nordhaus efficiency test
                tt1 = (coef1 + coef2)/(((se1**2) + (se2**2) + 2*cov)**(.5))
                eff_test1 = stats.t.sf(np.abs(tt1), n-2)*2

        #Create regression table
                reg_data = {'entry':['', r'$x^i_{t+k,t-1}(a)$', 
                         '',
                         r'$x^i_{t+k,t-2}(b)$',
                         '', r'Test: $a+b=0?$', 'FE + controls', 
                         'Observations', r'$R^2$'],
            formal_series[series]:[ r'$t+{}$'.format(str(int(h))),
                         r'{}'.format(str(round(coef1, 2)).ljust(4,'0')),
                         r'{}'.format('(' + str(round(p1, 3)).ljust(5,'0') + ')'),
                         r'{}'.format(str(round(coef2, 2)).ljust(4,'0')),
                         r'{}'.format('(' + str(round(p2, 3)).ljust(5,'0') + ')'),
                         '{}'.format(str(round(eff_test1, 3)).ljust(5,'0')), fc,
                         str(int(n)), r'{}'.format(str(round(r2, 2)).ljust(4,'0'))]
            }
        else:
           if fe_controls_row == False:
                #Collect coefficients of interest, their p-values, their standard errors, and the number of observations
                coef1 = reg.params[(0 + param_start)] 
                se1 = reg.std_errors[(0 + param_start)]
                p1 = reg.pvalues[(0 + param_start)] 
                n = reg.nobs
                r2 = reg._r2
                std_errors = [se1]
                points = [coef1]
                
        #Create regression table
                reg_data = {'entry':['', r'$x^i_{t+k,t-1}(a)$', 
                         '', 'Observations',
                         r'$R^2$'],
            formal_series[series]:[ r'$t+{}$'.format(str(int(h))),
                         r'{}'.format(str(round(coef1, 2)).ljust(4,'0')),
                         r'{}'.format('(' + str(round(p1, 3)).ljust(5,'0') + ')'),
                         str(int(n)), r'{}'.format(str(round(r2, 2)).ljust(4,'0'))]
            }
           else:
                #Collect coefficients of interest, their p-values, their standard errors, and the number of observations
                coef1 = reg.params[(0 + param_start)] 
                se1 = reg.std_errors[(0 + param_start)]
                p1 = reg.pvalues[(0 + param_start)] 
                n = reg.nobs
                r2 = reg._r2
                std_errors = [se1]
                points = [coef1]                

        #Create regression table
                reg_data = {'entry':['', r'$x^i_{t+k,t-1}(a)$', 
                         '', 'FE + controls', 'Observations',
                         r'$R^2$'],
             formal_series[series]:[ r'$t+{}$'.format(str(int(h))),
                         r'{}'.format(str(round(coef1, 2)).ljust(4,'0')),
                         r'{}'.format('(' + str(round(p1, 3)).ljust(5,'0') + ')'), fc,
                         str(int(n)),
                         r'{}'.format(str(round(r2, 2)).ljust(4,'0'))]
            }
        reg = pd.DataFrame(reg_data) 
        if return_se_point == True:
            return [reg, std_errors, points]
        else: 
            return reg
    else:
        if return_se_point == True:
            return [reg, std_errors, points]
        else: 
            return reg

    
def make_nordhaus_t3(data, add_controls = True, add_fe = True):
    '''
    Using the SPF data, generates Nordhaus table, focusing on horizon t+3.
    '''
    frames_col = []
    #Specify series of interest
    macro_list = ["CPI", "UNEMP", "TBILL","RGDP"]
    #Set variable names
    formal_series = {
        "CPI": "CPI Inflation",
        "UNEMP": "Unemployment Rate",
        "TBILL": "3-mo. Tbill Rate",
        "RGDP": "Real GDP Growth"}
    
    first = 0
    for hor in [0,3]:
        if add_controls == True:
                frames_col = frames_col + [reg_nordhaus(data, macro_list[0], h=hor, constant = False, fe_controls_row = True, fe = False, remove_var = ['prev2_for_{}'.format(macro_list[0])]).rename(columns={'entry': ''}), 
                reg_nordhaus(data, macro_list[0], h=hor, constant = False, fe_controls_row = True, fe = add_fe, remove_var = ['prev2_for_{}'.format(macro_list[0])]).drop(columns = ['entry']).rename(columns={formal_series[macro_list[0]]: ''}),
                reg_nordhaus(data, macro_list[0], h=hor, constant = False, fe_controls_row = True, fe = add_fe, include_var = ['for_UNEMP', 'for_TBILL','for_RGDP'], remove_var = ['prev2_for_{}'.format(macro_list[0])]).drop(columns = ['entry']).rename(columns={formal_series[macro_list[0]]: ''}),                        
            reg_nordhaus(data, macro_list[1], h=hor, constant = False, fe_controls_row = True, fe = False, remove_var = ['prev2_for_{}'.format(macro_list[1])]).drop(columns=['entry']), 
                reg_nordhaus(data, macro_list[1], h=hor, constant = False, fe_controls_row = True, fe = add_fe, remove_var = ['prev2_for_{}'.format(macro_list[1])]).drop(columns = ['entry']).rename(columns={formal_series[macro_list[1]]: ''}),
                reg_nordhaus(data, macro_list[1], h=hor, constant = False, fe_controls_row = True, fe = add_fe, include_var = ['for_CPI', 'for_TBILL','for_RGDP'], remove_var = ['prev2_for_{}'.format(macro_list[1])]).drop(columns = ['entry']).rename(columns={formal_series[macro_list[1]]: ''}),
            reg_nordhaus(data, macro_list[2], h=hor, constant = False, fe_controls_row = True, fe = False, remove_var = ['prev2_for_{}'.format(macro_list[2])]).drop(columns=['entry']), 
                reg_nordhaus(data, macro_list[2], h=hor, constant = False, fe_controls_row = True, fe = add_fe, remove_var = ['prev2_for_{}'.format(macro_list[2])]).drop(columns = ['entry']).rename(columns={formal_series[macro_list[2]]: ''}),  
                reg_nordhaus(data, macro_list[2], h=hor, constant = False, fe_controls_row = True, fe = add_fe, include_var = ['for_CPI', 'for_UNEMP', 'for_RGDP'], remove_var = ['prev2_for_{}'.format(macro_list[2])]).drop(columns = ['entry']).rename(columns={formal_series[macro_list[2]]: ''}),                
            reg_nordhaus(data, macro_list[3], h=hor, constant = False, fe_controls_row = True, fe = False, remove_var = ['prev2_for_{}'.format(macro_list[3])]).drop(columns=['entry']), 
                reg_nordhaus(data, macro_list[3], h=hor, constant = False, fe_controls_row = True, fe = add_fe, remove_var = ['prev2_for_{}'.format(macro_list[3])]).drop(columns = ['entry']).rename(columns={formal_series[macro_list[3]]: ''}),
                reg_nordhaus(data, macro_list[3], h=hor, constant = False, fe_controls_row = True, fe = add_fe, include_var = ['for_CPI', 'for_UNEMP', 'for_TBILL'], remove_var = ['prev2_for_{}'.format(macro_list[3])]).drop(columns = ['entry']).rename(columns={formal_series[macro_list[3]]: ''})]
        else:
                frames_col = frames_col + [reg_nordhaus(data, macro_list[0], h=hor, constant = False, fe_controls_row = True, fe = False, remove_var = ['prev2_for_{}'.format(macro_list[0])]).rename(columns={'entry': ''}), 
                reg_nordhaus(data, macro_list[0], h=hor, constant = False, fe_controls_row = True, fe = add_fe, remove_var = ['prev2_for_{}'.format(macro_list[0])]).drop(columns = ['entry']).rename(columns={formal_series[macro_list[0]]: ''}), 
            reg_nordhaus(data, macro_list[1], h=hor, constant = False, fe_controls_row = True, fe = False, remove_var = ['prev2_for_{}'.format(macro_list[1])]).drop(columns=['entry']), 
                reg_nordhaus(data, macro_list[1], h=hor, constant = False, fe_controls_row = True, fe = add_fe, remove_var = ['prev2_for_{}'.format(macro_list[1])]).drop(columns = ['entry']).rename(columns={formal_series[macro_list[1]]: ''}),
            reg_nordhaus(data, macro_list[2], h=hor, constant = False, fe_controls_row = True, fe = False, remove_var = ['prev2_for_{}'.format(macro_list[2])]).drop(columns=['entry']), 
                reg_nordhaus(data, macro_list[2], h=hor, constant = False, fe_controls_row = True, fe = add_fe, remove_var = ['prev2_for_{}'.format(macro_list[2])]).drop(columns = ['entry']).rename(columns={formal_series[macro_list[2]]: ''}), 
            reg_nordhaus(data, macro_list[3], h=hor, constant = False, fe_controls_row = True, fe = False, remove_var = ['prev2_for_{}'.format(macro_list[3])]).drop(columns=['entry']), 
                reg_nordhaus(data, macro_list[3], h=hor, constant = False, fe_controls_row = True, fe = add_fe, remove_var = ['prev2_for_{}'.format(macro_list[3])]).drop(columns = ['entry']).rename(columns={formal_series[macro_list[3]]: ''})]

        if first == 0:
            frames_row = (pd.concat(frames_col, axis = 1))
            first = 1
        else:    
            frames_row = (pd.concat([frames_row,(pd.concat(frames_col, axis = 1))], axis = 0))
        frames_col = []
    return frames_row

tbnord_t3 = make_nordhaus_t3(spf_full)
display(tbnord_t3)