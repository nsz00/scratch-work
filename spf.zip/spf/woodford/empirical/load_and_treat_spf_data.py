wd = 'data/'
import numpy as np
import pandas as pd
import re
import scipy.stats as stats
import statsmodels.tools.tools as sm
from linearmodels import PanelOLS

def load_spf(series, growth_rate = False, monthly_hist = False, monthly_period = "mid", rename_col = True, max_lag = 1, monthly_hybrid = False, max_prev_for = 2, hist_growth_rate = False):
    '''
    Imports individual SPF forecasts, real-time estimates, and actual values for a series and returns data for running Fuhrer's Table 2, 15, and 16 regressions on the series.
    - If growth_rate = True, the function converts the series from levels to growth rates. 
    - If monthly_hist = True, then the function treats the real-time historical estimates as monthly as opposed to quarterly values. This argument is necessary because the Philadelphia Fed reports only monthly - not quarterly- real-time data for some series. 
    - The argument monthly_period can take on three values: "start", "mid", and "end." If monthly_hist = True, then the function defines the quarter's real-time historical value using the first month in the quarter when monthly_period = "start". If monthly_period = "mid" or monthly_period = "end", the function defines the quarter's real-time historical value using the second or final month in the quarter, respectively. 
    - If rename_col = True, the series name is appended to all of the returned dataframe's variables. 
    - If the historical data are in levels but the individual forecasts are in growth rates, set growth_rate = False and hist_growth_rate = True.
    '''
    #Import spf data
    spf = pd.read_excel(wd + 'Individual_{}.xlsx'.format(series))

    #Create "survey date" variable
    spf['survey_date'] = spf.apply(lambda x: pd.Period('%dQ%d' %(x.YEAR, x.QUARTER), freq='Q'), axis=1)

    #For series where we are converting levels to  growth rates, extract an extra lag
    if (growth_rate == True) & (series != 'TBILL'):
        max_lag = max_lag + 1

    if (max_lag > 1) & (series != 'TBILL'):
        #At each forecast date, the forecaster provides her estimates of the series' level at the t-1,t,t+1,t+2,t+3, and t+4 horizons. With this information, we can easily calculate the forecaster's estimate of the series' growth rate at the t, t+1, t+2, t+3, and t+4 horizons. To determine the forecaster's estimate of the t-1 growth rate, we must know the forecaster's estimate of the series' t-2 level. Because the SPF does not record the forecaster's t-2 level estimate, we assume that all forecasters' t-2 estimates of the series' level equal the survey date's real-time historical value of the series two quarters earlier. Accordingly, we load the series' real-time historical data. 
        historical = pd.read_excel(wd + 'Historical_{}.xlsx'.format(series))

        #If the real-time data is at a monthly frequency, use the nth (first/"start, second/"mid", or third/"end") month of the quarter as the quarter's real-time value. 
        if monthly_hist == True:
            historical['date_end'] = historical.DATE.str[-2:]
            if monthly_period == "start":
                month_pull = 1
            if monthly_period == "mid":
                month_pull = 2
            if monthly_period == "end":
                month_pull = 3
            historical = historical[(historical.date_end == str(month_pull).zfill(2)) | (historical.date_end == str(3 + month_pull).zfill(2)) | (historical.date_end == str(6 + month_pull).zfill(2)) | (historical.date_end == str(9 + month_pull).zfill(2))]
            if monthly_hybrid == False:
                historical = historical[historical.columns[(historical.columns.str.endswith('M' + str(month_pull))) | (historical.columns.str.endswith('M' + str(3 + month_pull))) | (historical.columns.str.endswith('M' + str(6 + month_pull))) | (historical.columns.str.endswith('M' + str(9 + month_pull))) | (historical.columns.str.endswith('DATE'))]]
            else:
                historical.drop(['date_end'], axis=1, inplace=True)
            historical['DATE'] = historical.DATE.str[:5] + 'Q' + ((((historical.DATE.str[-2:]).astype('int') + (3 - month_pull))/3).astype('str')).str[:1]
            if monthly_hybrid == False:
        #Rename the columns from a monthly to quarterly string format
                nondate_col = historical.columns[~historical.columns.str.endswith('DATE')]
                for nondate in nondate_col:
                    series_len = nondate.rfind('M')
                    historical.rename(columns={nondate: (nondate[:series_len] + 'Q' + str((int(nondate[(series_len + 1):]) + (3 - month_pull))/3)[:1])}, inplace=True)
            historical = historical.reset_index(drop=True)   


        hist_date = []
        hist_df_col = []
        for lag_val in range(1,max_lag):
            hist_df_col = hist_df_col + ['{}{}'.format(series, (1-lag_val))]
        hist_val_df = pd.DataFrame(columns=hist_df_col)

        #If historical data appears in levels but individual forecasts are in growth rates, we need to convert the historical data to growth rates before merging it with the individual forecasts. To conver the historical data from levels to growth rates, we need to pull an additional lag. 
        if hist_growth_rate == True:
            max_lag = max_lag + 1
            
        yr_start = '19'
        for column in historical.columns[1:]:
            date_str = column[-4:]
            if date_str == '00Q1':
                yr_start = '20'
            date_full = yr_start + date_str
            #Determine the date 2 quarters prior to the survey date
            if int(date_full[-1]) > 2:
                new_date_str = date_full[:-1] + str(int(date_full[-1]) - 2)
            else:
                new_date_str = str(int(date_full[:4]) - 1) + 'Q' + str(int(date_full[-1]) + 2)
            new_date_str = new_date_str[:4] + ':' + new_date_str[-2:]
            q2 = list(historical['DATE']).index(new_date_str)
            q_lag = q2 - max_lag + 2
            
            #Extract the series' 2nd through max_lag-th previous real-time values. Convert these values to growth rates if individual forecasts are already in growth rates but historical data is not.
            if hist_growth_rate == True:
                prev_val_col = ((historical.loc[q_lag:q2, column]).values)
                prev_val = ((np.true_divide(prev_val_col[1:], prev_val_col[:-1])) -1)*400 
                prev_val = prev_val.reshape(1,max_lag -2)
            else:    
                prev_val = ((historical.loc[q_lag:q2, column]).values).reshape(1,max_lag -1)

            hist_date.append(date_full)
            hist_val_df = hist_val_df.append(pd.DataFrame(prev_val, columns = hist_df_col), ignore_index=True)

        #Create dataframe of survey dates and their estimates of the series two quarters prior
        hist_date_df = pd.DataFrame(hist_date, columns =['survey_date_str']) 
        hist_df = pd.concat([hist_date_df, hist_val_df], axis=1)

        #Reset max_lag back to previous value if hist_growth_rate = True because now both historical and forecast data are in growth rates
        if hist_growth_rate == True:
            max_lag = max_lag - 1
            
        #Merge estimates of series two quarters prior with individual SPF data 
        spf['survey_date_str'] = spf.survey_date.astype(str)
        spf = pd.merge(spf, hist_df, on = ['survey_date_str'], how = 'left')
        spf.drop(['survey_date_str'], axis=1, inplace=True)


    if (growth_rate == True) & (series != 'TBILL'):
        #Identify columns containing SPF level forecasts that should be converted to growth rates
        r_growth = re.compile("^{}-?[0-9]$".format(series))
        col_growth = list(filter(r_growth.match, list(spf.columns)))
        #Create growth rate forecasts
        for col in col_growth:
            series_length = int(len(series))
            col_num = int(col[series_length:])
            if col_num != (2-max_lag):
                spf['{}_growth'.format(col)] = ((spf[col]/spf['{}{}'.format(series, (col_num-1))]) - 1)*400
        spf.drop(col_growth, axis=1, inplace=True)
        for col in col_growth:
            series_length = int(len(series))
            col_num = int(col[series_length:])
            if col_num != (2-max_lag):
                spf.rename(columns={'{}_growth'.format(col): col}, inplace=True)
        max_lag = max_lag - 1

    #Identify irrelevant columns to drop when reshaping
    r_drop = re.compile("^{}[A-Z]$".format(series))
    col_drop = list(filter(r_drop.match, list(spf.columns)))

    #Reshape the data into panel format
    spf = pd.melt(spf.drop(col_drop + ['INDUSTRY'], axis=1), id_vars=['survey_date', 'YEAR', 'QUARTER', 'ID'], var_name='spf_type', value_name='for')

    #Create "survey horizon" variable
    series_length = int(len(series))
    spf['hor'] = pd.to_numeric(spf['spf_type'].str.strip().str[series_length:]) - 2

    #Create "forecasted date", "forecasted quarter", and "forecasted year" variables
    spf['for_date'] = spf['YEAR'] + (spf['QUARTER'] - 1)/4 + (spf['hor']/4)
    spf['for_qtr'] = (spf['for_date']-spf['for_date'].astype('int64') +.25)*4
    spf['for_yr'] = (spf['for_date'].astype('int64'))

    #Create "real-time estimate of kth-lagged macrovariable", and keep only positive horizons
    spf = spf.sort_values(by=['ID', 'survey_date', 'hor'],  ascending=[True, True, True])
    if series == 'TBILL':
        set_lag = 1
    else:
        set_lag = max_lag
    track_lag = set_lag
    for lag_val in range(0,set_lag):
        n = lag_val
        def nth_obs(df):
            return df.iloc[n]
        spf['first_hor'] = spf.groupby(['ID', 'survey_date'])['hor'].transform(nth_obs)
        if track_lag == 1:
            spf['lag_for'] = spf.groupby(['ID', 'survey_date'])['for'].transform(nth_obs)
            spf.loc[spf['first_hor'] != -track_lag, 'lag_for'] =  np.nan 
        else:
            lag_var_name = 'lag{}_for'.format(track_lag)
            spf[lag_var_name] = spf.groupby(['ID', 'survey_date'])['for'].transform(nth_obs)
            spf.loc[spf['first_hor'] != -track_lag, lag_var_name] =  np.nan 
        track_lag = track_lag - 1
    spf = spf[spf.hor >= 0]

    #Sort the dataset by forecaster, forecasted date, and horizon
    spf = spf.sort_values(by=['ID', 'for_date', 'hor'],  ascending=[True, True, False])
    #For each forecaster-date pair, pull the forecaster's wth previous forecast for that period
    for prev_val in range(1,max_prev_for + 1):
        if prev_val == 1:
            spf['prev_for'] = spf.groupby(['ID', 'for_date'])['for'].shift(1)
            spf['prev_hor'] = spf.groupby(['ID', 'for_date'])['hor'].shift(1)
            spf.loc[(spf['prev_hor'] - spf['hor']) != 1, 'prev_for'] =  np.nan
        else:
            prev_var_name = 'prev{}_for'.format(prev_val)
            spf[prev_var_name] = spf.groupby(['ID', 'for_date'])['for'].shift(prev_val)
            spf['prev_hor'] = spf.groupby(['ID', 'for_date'])['hor'].shift(prev_val)
            spf.loc[(spf['prev_hor'] - spf['hor']) != prev_val, prev_var_name] =  np.nan
    
    #Create a variable equal to the median value of the previous forecast 
    spf['median_prev_for'] = spf.groupby(['for_date'])['prev_for'].transform('median')
    
    #Create a variable equal to the forecast revision
    spf['revision'] = spf['for'] - spf['prev_for']

    #Drop unnecessary columns
    spf['for_date'] = spf.apply(lambda x: pd.Period('%dQ%d' %(x.for_yr, x.for_qtr), freq='Q'), axis=1)
    spf.drop(['YEAR', 'QUARTER', 'spf_type', 'first_hor', 'prev_hor', 'for_yr', 'for_qtr'], axis=1, inplace=True)
    
    #Import actual or realized values for 5 time intervals (and calculate forecast errors
    actual_data = pd.read_excel(wd + 'Error_{}.xls'.format(series))
    actual_data = actual_data[['Unnamed: 0','Realiz1', 'Realiz2', 'Realiz3', 'Realiz4', 'Realiz5']]
    actual_data.rename(columns={'Unnamed: 0': 'for_date'}, inplace=True)
    #Merge actual values with individual SPF forecast data
    actual_data['for_yr'] = (actual_data['for_date'].str.strip().str[:4]).astype('int64')
    actual_data['for_qtr'] = (actual_data['for_date'].str.strip().str[-1]).astype('int64')
    actual_data['for_date'] = actual_data.apply(lambda x: pd.Period('%dQ%d' %(x.for_yr, x.for_qtr), freq='Q'), axis=1)
    actual_data.drop(['for_yr', 'for_qtr'], axis=1, inplace=True)

    #For the TBILL series, extract lags (greater than one) from the Philadelphia Fed SPF variable realizations (first release)
    if (series == 'TBILL') & (max_lag > 1):
        for lag_val in range(2,max_lag + 1):
            actual_data['lag{}_for'.format(lag_val)] = actual_data.Realiz1.shift(lag_val)

    spf = pd.merge(spf, actual_data, on = ['for_date'], how = 'left')
    #For each of the following 5 time intervals, calculate the individual's forecast error:
    #(1) The initial or first-release value
    #(2) The revised value as it appears one quarter after the initial release
    #(3) The revised value as it appears five quarters after the initial release
    #(4) The revised value as it appears nine quarters after the initial release
    #(5) The revised value as it appears today. 
    for act in range(1, 6):
        spf['error{}'.format(act)] = spf['Realiz{}'.format(act)] - spf['for']

    #Specify macroeconomic variable
    spf['var'] = series
    #Reset index
    spf = spf.reset_index(drop=True)
    
    #If desired, append the series name to all of the returned dataframe's variables
    if rename_col == True:
        spf.rename(columns={'for': 'for_{}'.format(series)}, inplace=True)
        spf.rename(columns={'lag_for': 'lag_for_{}'.format(series)}, inplace=True)
        if max_lag > 1:
            for lag_val in range(1, max_lag):
                lag_replace = lag_val + 1
                spf.rename(columns={'lag{}_for'.format(lag_replace): 'lag{}_for_{}'.format(lag_replace, series)}, inplace=True)
        spf.rename(columns={'prev_for': 'prev_for_{}'.format(series)}, inplace=True)
        if max_prev_for > 1:
            for prev_val in range(1, max_prev_for):
                prev_replace = prev_val + 1
                spf.rename(columns={'prev{}_for'.format(prev_replace): 'prev{}_for_{}'.format(prev_replace, series)}, inplace=True)
        spf.rename(columns={'median_prev_for': 'median_prev_for_{}'.format(series)}, inplace=True)
        spf.rename(columns={'revision': 'revision_{}'.format(series)}, inplace=True)
        spf.rename(columns={'Realiz1': 'actual1_{}'.format(series), 'Realiz2': 'actual2_{}'.format(series), 'Realiz3': 'actual3_{}'.format(series),'Realiz4': 'actual4_{}'.format(series), 'Realiz5': 'actual5_{}'.format(series)}, inplace=True)
        spf.rename(columns={'error1': 'error1_{}'.format(series), 'error2': 'error2_{}'.format(series), 'error3': 'error3_{}'.format(series),'error4': 'error4_{}'.format(series), 'error5': 'error5_{}'.format(series)}, inplace=True)
        spf.drop('var', axis=1, inplace=True)

    return(spf)

#Load the SPF Data 
##CPI Inflation
cpi = load_spf("CPI", monthly_hist = True, max_lag = 2, monthly_hybrid = True, hist_growth_rate = True)
##3-month T-bill
tbill = load_spf("TBILL", max_lag = 2)
##Unemployment rate
unemp = load_spf("UNEMP", monthly_hist = True, max_lag = 2, monthly_hybrid = True)
##Real GDP growth
rgdp = load_spf("RGDP", growth_rate = True, max_lag = 2)
##GDP deflator
pgdp = load_spf("PGDP", growth_rate = True, max_lag = 2)
##Employment growth
emp = load_spf("EMP", growth_rate = True, monthly_hist = True, max_lag = 2)
##Consumption growth
rconsum = load_spf("RCONSUM", growth_rate = True, max_lag = 2)
##Residential structure growth
rresinv = load_spf("RRESINV", growth_rate = True, max_lag = 2)
##Non-residential structure growth
rnresin = load_spf("RNRESIN", growth_rate = True, max_lag = 2)

#Merge together all SPF dataframes
merge_dfs = [cpi, tbill, unemp, rgdp, pgdp, emp, rconsum, rresinv, rnresin] 
for spf_merge in range(len(merge_dfs)):
    if spf_merge == 0:
        spf_full = merge_dfs[spf_merge]
    else:
        spf_full = pd.merge(spf_full, merge_dfs[spf_merge], on = ['survey_date', 'ID', 'hor', 'for_date'], how = 'outer')
spf_full = spf_full.reset_index(drop=True)