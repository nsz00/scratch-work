#Title: Set Paths - "set-paths.py"
#Description: This python script sets file paths for the "monetary-policy-heterogeneity" directory.

#Set location for CPS data files
cps_path = '/CPSPATH/monetary-policy-heterogeneity/cps_data/'
