#Title: Import CPS Data - "import-cps-data.py"
#Description: This python script imports CPS data from NBER in order to replicate CCS (2018). Run this script by executing "python data/import-cps-data.py" from the "monetary-policy-heterogeneity" directory.

'''
Data Sources:
CPS Unemployment & Earnings data: https://data.nber.org/cps-basic2/
   i) Under "Downloads," click "In csv format."
   ii) Download csv files for each month one-by-one.
    
   - Note: NBER has been redesigning its website. As a result, the CCS (2018) links are no longer maintained.
   - Previously, NBER provided STATA do-files (http://www.nber.org/data/cps basic progs.html) to clean the raw CPS files from the BLS (http://www.nber.org/data/cps basic.html). 
   - Now, they conveniently provide the ouput of these STATA files in csv format. 
'''

# Load packages
import pandas as pd
import urllib.request
import os

def pull_cps_data(start = '1989-01-01', end = '2021-03-01', directory_path = 'CPSPATH/monetary-policy-heterogeneity/cps_data/'):
    '''
    Imports CPS data
    - start = First CPS sample. 
    - end = Last CPS sample.
    - directory_path = Path to save CPS csv's. 
    '''
    cps_dates = pd.period_range(start, end,freq='M')
    for single_date in cps_dates:
        nber_url = "https://data.nber.org/cps-basic2/csv/cpsb{}.csv".format((single_date.strftime('%Y-%m')).replace('-', ''))
        urllib.request.urlretrieve(nber_url, '{}cps-{}.csv'.format(directory_path, single_date.strftime('%Y-%m').replace('-', '')))
        os.system('gzip {}cps-{}.csv'.format(directory_path, single_date.strftime('%Y-%m').replace('-', '')))
        print(nber_url)

#Pull CPS data (post 2005 and then pre 2005)
#pull_cps_data(start = '2005-01-01', end = '2021-03-01')
#pull_cps_data(start = '1989-01-01', end = '2004-12-01')
pull_cps_data(start = '1997-06-01', end = '2004-12-01')
os.system('chmod -R 550 CPSPATH/monetary-policy-heterogeneity/cps_data/')
