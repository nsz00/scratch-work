#Title: Import CCS Data - "import-ccs-data.py"
#Description: This python script imports and cleans the underlying data from CCS (2018). Run this script by executing "python data/import-ccs-data.py" from the "monetary-policy-heterogeneity" directory.

'''
Data Sources:
1) Real GDP per capita (A939RX0Q048SBEA), GDP Deflator (GDPDEF), and official unemployment rate (UNRATE): https://fred.stlouisfed.org

2) TFP: https://www.frbsf.org/economic-research/indicators-data/total-factor-productivity-tfp/ (Under "Download latest dataset")
    i) See 'quarterly' sheet, series 'dtfp'
    
3) Nonfarm business sector labor share: https://www.bls.gov/lpc/
    i) Go to LPC Overview >> Data (https://www.bls.gov/lpc/lpcover.htm#data)
    ii) Under the "Data Available Section", click "historical time series" under the "output per hour of all persons and related measures, for the business, nonfarm business, ...." bullet (https://data.bls.gov/cgi-bin/dsrv?pr).
    iii) Then, select "Nonfarm Business" >> "Labor share" >> "Index, base, year = 100" >> "Retreive data."
    iv) Proceed to "More formatting Options." Select "Column Format", unselect "Original Data Value", select "All years", select "All Time periods", and select "HTML Table."
    v) Click "Retrieve data." 
    vi) Finally, download the xlsx file.

    - Note: Nonfarm business sector labor share with Original Data Values and without Original Data Values are exactly the same.

4) CPS Unemployment & Earnings data: https://data.nber.org/cps-basic2/
    i) Under "Downloads," click "In csv format."
    ii) Download csv files for each month one-by-one.
    
    - Note: NBER has been redesigning its website. As a result, the CCS (2018) links are no longer maintained.
    - Previously, NBER provided STATA do-files (http://www.nber.org/data/cps basic progs.html) to clean the raw CPS files from the BLS (http://www.nber.org/data/cps basic.html). 
    - Now, they conveniently provide the ouput of these STATA files in csv format. 
'''

# Load packages
import os
import datetime
import pandas as pd
import urllib.request
from pandas_datareader import get_data_fred
from set_paths import cps_path

def pull_cps_data(start = '1989-01-01', end = '2021-03-01', directory_path = cps_path):
    '''
    Imports CPS data
    - start = First CPS sample. 
    - end = Last CPS sample.
    - directory_path = Path to save CPS csv's. 
    '''
    cps_dates = pd.period_range(start, end,freq='M')
    for single_date in cps_dates:
        nber_url = "https://data.nber.org/cps-basic2/csv/cpsb{}.csv".format((single_date.strftime('%Y-%m')).replace('-', ''))
        urllib.request.urlretrieve(nber_url, '{}cps-{}.csv'.format(directory_path, single_date.strftime('%Y-%m').replace('-', '')))
        os.system('gzip {}cps-{}.csv'.format(directory_path, single_date.strftime('%Y-%m').replace('-', '')))
        print('NBER CPS csv successfully imported: {}'.format(nber_url))


def combine_non_cps_data(fred, fred_unrate, tfp, ls):
    '''
    Combines non-CPS data into single dataframe
    - fred = Per capita GDP & GDP deflator Fred data. 
    - fred_unrate = Unemployment rate Fred data.
    - tfp = SF Fed TFP data.
    - ls = BLS labor share data.
    '''
    
    #Average monthly Fred unemployment rate to quarterly frequency 
    fred_unrate = fred_unrate.resample('QS').mean()
    
    #Reset Fred indices and rename columns
    fred_unrate.reset_index(inplace = True)
    fred.reset_index(inplace = True)
    fred_unrate.rename(columns={'DATE': 'date', 'UNRATE': 'unrate'}, inplace=True)
    fred.rename(columns={'DATE': 'date', 'GDPDEF': 'gdpdef', 'A939RX0Q048SBEA': 'pcgdp'}, inplace=True)
    
    #Drop rows in TFP data that correspond to empty rows and summary statistics
    tfp['row_is_none'] = tfp['date'].isna()
    tfp = tfp[(tfp['row_is_none']==0)]
    tfp['row_is_mean'] = (tfp['date'] == 'Full sample mean')
    tfp['row_sum'] = tfp['row_is_mean'].cumsum()
    tfp = tfp[(tfp['row_sum']==0)]
    
    #Create date variable for TFP data, reset index, and drop unnecessary variables
    tfp['year'] = tfp['date'].str[:4]
    tfp['quarter'] = ((((tfp['date'].str[-1:]).astype('int64'))*3 -2).astype(str)).str.zfill(2)
    tfp['date'] = tfp['year'] + '-' +  tfp['quarter'] + '-' +  '01'
    tfp['date'] = pd.to_datetime(tfp['date'], format='%Y-%m-%d')
    tfp.reset_index(inplace = True, drop=True)
    tfp.drop(['row_is_none', 'row_is_mean', 'row_sum', 'year', 'quarter'], axis=1, inplace=True)
    
    #Create date variable for the labor share data, rename variable, and drop unnecessary variables
    ls['date'] = ls['Year'].astype(str) + '-' +  ((((ls['Period'].str[2:]).astype('int64'))*3 -2).astype(str)).str.zfill(2) + '-' +  '01'
    ls['date'] = pd.to_datetime(ls['date'], format='%Y-%m-%d')
    ls.drop(['Year', 'Period'], axis=1, inplace=True)
    ls.rename(columns={'Value': 'labor_share'}, inplace=True) 
    
    #Combine non-CPS data into single dataframe
    merge_dfs = [fred, fred_unrate, tfp, ls] 
    for df in range(len(merge_dfs)):
        if df == 0:
            ccs = merge_dfs[df]
        else:
            ccs = pd.merge(ccs, merge_dfs[df], on = ['date'], how = 'outer')
            
    #Sort dataframe by date and return non-CPS dataframe        
    ccs = ccs.sort_values(by = 'date')
    return ccs
        
def pull_ccs_data(start = '1980-01-01', end = str(datetime.datetime.date(datetime.datetime.now())), import_cps = False):
    '''
    Imports CCS data
    - start = Date to start all series. 
    - end = Date to end all series
    - import_cps = When set to True, the script downloads all CPS data files available on NBER. Since this is a time consuming process that generates roughly .6GB of compressed csv files, import_cps = False  by default. 
    '''
    #Real per capita GDP, GDP deflator, and official unemployment rate
    fred_unrate_df = get_data_fred(['UNRATE'], datetime.datetime.strptime(start,'%Y-%m-%d'), datetime.datetime.strptime(end,'%Y-%m-%d'))
    fred_df = get_data_fred(['A939RX0Q048SBEA', 'GDPDEF'], datetime.datetime.strptime(start,'%Y-%m-%d'), datetime.datetime.strptime(end,'%Y-%m-%d'))    
    #TFP series
    tfp_df = pd.read_excel('./data/raw-ccs-data/quarterly_tfp.xlsx', sheet_name = 'quarterly', header = 1, usecols = ['date', 'dtfp'])
    #Labor share 
    ls_df = pd.read_excel('./data/raw-ccs-data/PRS85006173.xlsx', header = 10, usecols = ['Year', 'Period', 'Value'])
    #CPS data
    if import_cps:
        pull_cps_data()
        os.system('chmod -R 550 {}'.format(cps_path))

    #Combine non-CPS data
    ccs_df = combine_non_cps_data(fred_df, fred_unrate_df, tfp_df, ls_df)   
    ccs_df.reset_index(inplace = True, drop = True)
    print(ccs_df)

pull_ccs_data()
