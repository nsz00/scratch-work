#include <boost/serialization/serialization.hpp>
#include <boost/mpi.hpp>
#include <boost/random.hpp>
#include <iostream>
#include <fstream>
#include <Eigen/Dense>
#include <estimation/toolchain>

// LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/PATH/lib
// export LD_LIBRARY_PATH

int main () {
  boost::mpi::environment env;
  boost::mpi::communicator world;
  boost::random::mt19937 rng(12345);
  rng.discard(10e12 * world.rank());
  const int np = world.size();
  const int ndraw_per_proc = 100;
  boost::random::normal_distribution<>normal01(0.0, 1.0);
  Eigen::VectorXd draws(ndraw_per_proc);
  for (int j = 0; j < ndraw_per_proc; j++) {
    draws(j) = normal01(rng);
  }
  if (world.rank() > 0) {
    world.send(0, world.rank(), draws);
  } else {
    Eigen::MatrixXd alldraws(ndraw_per_proc,np);
    Eigen::VectorXd drawsi(ndraw_per_proc);
    alldraws.col(0) = draws;
    if (np > 1) {
      for (int j = 1; j < np; j++) {
	world.recv(j, j, drawsi);
	alldraws.col(j) = drawsi;
      }
    }
    std::cout << alldraws << std::endl;
  }
  return 0;
}
